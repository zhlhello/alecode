/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    create from NOE for AoM project.

  -----------------------------------------------------------------------------*/
  
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <errno.h>

#include "log.h"

#include "os_wrapper.h"
#include "keydrv.h"

static char *key_set_on = "/tmp/.key_set_on";
static char *fab_mode = "/fab/.fabmode";
static char *fab_prefix = "[DEBUG]#";
static char *dev_ttyGS0 = "/dev/ttyGS0";
    
const char* key_dev_name = "/dev/input/event0";

static keycode_t translateKeyCode(uint16_t key, uint16_t value)
{
    uint8_t KeyCode;
    int i=0;
    
    //keymap matrix is defined into platform/keymap.h
    while((keymap[i].code != key) && (keymap[i].code != KEY_RESERVED)) i++;
    
    if (access(key_set_on, R_OK) ==0)
    {
        if (access(fab_mode, R_OK) ==0)//fab mode
        {
            int fd = open(dev_ttyGS0, O_RDWR | O_NONBLOCK);

            if (fd > 0)
            {
                dup2(fd, 0);
                dup2(fd, 1);
                dup2(fd, 2);
                close(fd);
            }
            printf("%-14s %s\n", keymap[i].str, value ? "Press" : "Up");
            printf("%s ", fab_prefix);
        }
        else
            printf("%-14s %s\n", keymap[i].str, value ? "Press" : "Up");
    }
    
    KeyCode = keymap[i].keycode;
    KeyCode = value ? (KeyCode | MASK_UP2DOWN) : (KeyCode & ~MASK_UP2DOWN);

    return KeyCode;
}

static void keydrv_task_entry (void)
{
    static int key_fd = 0;
    struct input_event akey;
    int ret = 0;
    int count = 0;
                            
    fd_set fds;
    int maxfd;
    struct timeval tv;
    uint8_t theKey;
    msg_t msg_s;
    
    int goOn;

    LOGI("start aom_key_task_entry\n");

    key_fd = open(key_dev_name, O_RDONLY);
    if (key_fd < 0)
    {
        LOGE("can not open device keyboard");
    }
    else
    {
        goOn = 1;
        while (goOn)
        {
            FD_ZERO(&fds);
            FD_SET(key_fd, &fds);
            maxfd = key_fd + 1;

            tv.tv_sec = 10;
            tv.tv_usec = 0;

            while (((ret = select(maxfd, &fds, NULL, NULL, &tv)) < 0) && (errno == EINTR));

            if (ret == -1)
            {
                if (errno != EINTR) 
                {
                    LOGE("Keypad select error !!! \n");
                }
            }
            else if (ret)
            {
                if (FD_ISSET(key_fd, &fds))
                {      
                    ret = read(key_fd, &akey, sizeof(struct input_event));

                    if ((0x00 == akey.code) || (0x04 == akey.code))
                        continue;

                    LOGI("akey.code = %d, akey.value = %d", akey.code, akey.value);
                    
                    theKey = translateKeyCode(akey.code, akey.value);                    

                    //send to hid thread
                    msgS_allocate(msg_s, MSG_event_drv_keyb, theKey, THREAD_ID_keydrv);
                    aom_msgQ_send(QUEUE_ID_hidWt, msg_s);
                }
            }          
        } // *** while(goOn) end ***
        close(key_fd);
    }
    
    LOGI("Thread Keydrv Exit Gracefully!" );
    thread_set_status(THREAD_ID_keydrv, THREAD_IS_CLOSED);
    pthread_exit(NULL);    
}

void init_drvkeyb(void)
{
    aom_task_create(THREAD_ID_keydrv, keydrv_task_entry, NULL);
}

