/* ---------------------------------------------------------------
 *  COMPONENT :     NOE
 *
 *  MODULE:         gpio.c
 *
 *  DATED:          2015/11/10
 *
 *  AUTHOR:         michelsu
 *
 *  DESCRIPTION:    gpio access functions
 *
 *  HISTORY:
 *
 *
 */

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <pthread.h>

#include "gpio.h"

#define  USE_MUTEX  1

#if USE_MUTEX
  //use mutex to protect fd array
  static pthread_mutex_t mutexLib = PTHREAD_MUTEX_INITIALIZER;
# define MUTEX_LOCK      pthread_mutex_lock(&mutexLib)
# define MUTEX_UNLOCK    pthread_mutex_unlock(&mutexLib)
#else
# define MUTEX_LOCK      
# define MUTEX_UNLOCK    
#endif


#define DEBUG_MODE  0

#if DEBUG_MODE
# define LOG_DBG(fmt,...)     fprintf(stdout,fmt,##__VA_ARGS__)
#else
# define LOG_DBG(fmt,...) 
#endif

# define LOG_ERR(fmt,...)     fprintf(stderr,fmt,##__VA_ARGS__)

#define MAX_FILE_PATH  64

// array to keep open fd for each gpio value (if requested !)
static int gpio_setval_fd[MAX_GPIO] = { [0 ... MAX_GPIO-1] = -1 };

static int _gpio_open_value(unsigned int pin)
{
    int gpio_fd;
    char gpio_file_name[MAX_FILE_PATH];

    sprintf(gpio_file_name, "/sys/class/gpio/gpio%d", pin);
    if(access(gpio_file_name, F_OK) != 0)
    {
        LOG_ERR("gpio(%d): %s does not exist! \n", pin, gpio_file_name);
        return GPIO_ERR;
    }

    strcat(gpio_file_name, "/value");
    gpio_fd = open(gpio_file_name, O_RDWR);
    if(gpio_fd < 0)
    {
        LOG_ERR("gpio(%d): open %s failed \n", pin, gpio_file_name);
        return GPIO_ERR;
    }

    return gpio_fd;    
}


int gpio_export(unsigned int pin)
{
    int gpio_fd = -1;
    int ret = GPIO_ERR;
    char gpio_file_name[MAX_FILE_PATH];

    if (pin >= MAX_GPIO) return GPIO_ERR;

    sprintf(gpio_file_name, "/sys/class/gpio/gpio%d", pin);
    if(access(gpio_file_name, F_OK) == 0)
    {
        LOG_DBG("gpio(%d): %s already exported\n", pin, gpio_file_name);
        return GPIO_OK;
    }

    gpio_fd = open("/sys/class/gpio/export", O_WRONLY);
    if(gpio_fd < 0)
    {
        LOG_ERR("gpio(%d): open gpio/export failed \n", pin);
        return GPIO_ERR;
    }

    sprintf(gpio_file_name,"%d", pin);

    ret = write(gpio_fd, gpio_file_name, strlen(gpio_file_name));
    if(ret < 0)
    {
        LOG_ERR("gpio(%d): export gpio failed \n", pin);
        close(gpio_fd);
        return GPIO_ERR;
    }

    close(gpio_fd);

    return GPIO_OK;
}


int gpio_unexport(unsigned int pin)
{

    int gpio_fd = -1;
    int ret = GPIO_ERR;
    char gpio_file_name[MAX_FILE_PATH];
   
    if (pin >= MAX_GPIO) return GPIO_ERR;

    sprintf(gpio_file_name, "/sys/class/gpio/gpio%d", pin);
    if(access(gpio_file_name, F_OK) != 0)
    {
        LOG_ERR("gpio(%d):%s already unexported\n", pin, gpio_file_name);
        return GPIO_OK;
    }

    gpio_fd = open("/sys/class/gpio/unexport", O_WRONLY);
    if(gpio_fd < 0)
    {
        LOG_ERR("application/noemmi/NOE/noe_shared/mod/keyboard/keyb.cgpio(%d):open gpio/unexport failed \n", pin);
        return GPIO_ERR;
    }

    sprintf(gpio_file_name,"%d", pin);

    ret = write(gpio_fd, gpio_file_name, strlen(gpio_file_name));
    if(ret < 0)
    {
        LOG_ERR("gpio(%d):unexport gpio failed \n", pin);
        close(gpio_fd);
        return GPIO_ERR;
    }

    close(gpio_fd);

    return GPIO_OK;
}


int gpio_set_direction(unsigned int pin, int direction)
{
    int gpio_fd = -1;
    int ret = GPIO_ERR;
    char gpio_file_name[MAX_FILE_PATH];
    char *direction_str;

   
    if (pin >= MAX_GPIO) return GPIO_ERR;

    switch(direction)
    {
        case GPIO_IN:    direction_str = "in"; break;
        case GPIO_OUT:   direction_str = "out"; break;
        case GPIO_OUT_H: direction_str = "high"; break;
        default: return GPIO_ERR;
    }

    sprintf(gpio_file_name, "/sys/class/gpio/gpio%d", pin);
    if(access(gpio_file_name, F_OK) != 0)
    {
        LOG_ERR("gpio(%d): %s does not exist! \n", pin, gpio_file_name);
        return GPIO_ERR;
    }

    strcat(gpio_file_name, "/direction");
    gpio_fd = open(gpio_file_name, O_RDWR);
    if(gpio_fd < 0)
    {
        LOG_ERR("gpio(%d): open %s failed \n", pin, gpio_file_name);
        return GPIO_ERR;
    }

    ret = write(gpio_fd, direction_str, strlen(direction_str));
    if(ret < 0)
    {
        LOG_ERR("gpio(%d): set direction %s failed (%d)\n", pin, direction_str, ret);
        close(gpio_fd);
        return GPIO_ERR;
    }

    close(gpio_fd);

    return GPIO_OK;
}


int gpio_get_direction(unsigned int pin, int *direction)
{
    int gpio_fd = -1;
    int ret = -1;
    char gpio_file_name[MAX_FILE_PATH];
    char direction_str[16];
   
    if (pin >= MAX_GPIO) return GPIO_ERR;

    if (NULL == direction)
    {
        LOG_ERR("gpio(%d): get direction with NULL pointer\n", pin);
        return GPIO_ERR;
    }

    sprintf(gpio_file_name, "/sys/class/gpio/gpio%d", pin);
    if(access(gpio_file_name, F_OK) != 0)
    {
        LOG_ERR("gpio(%d): %s does not exist! \n", pin, gpio_file_name);
        return GPIO_ERR;
    }

    strcat(gpio_file_name, "/direction");
    gpio_fd = open(gpio_file_name, O_RDWR);
    if(gpio_fd < 0)
    {
        LOG_ERR("gpio(%d): open %s failed \n", pin, gpio_file_name);
        return GPIO_ERR;
    }

    memset(direction_str, 0, sizeof(direction_str));
    ret = read(gpio_fd, direction_str, sizeof(direction_str)-1);
    if (ret > 0)
    {
       int value;
       if (memcmp(direction_str, "out", 3) == 0) {
           gpio_get_value(pin, &value);
          *direction = (value) ? GPIO_OUT_H : GPIO_OUT;
       }
       else
       if (memcmp(direction_str, "in", 2) == 0)
          *direction = GPIO_IN;
       else
          ret = -1;
    }
    else ret = -1;

    if(ret < 0)
    {
        LOG_ERR("gpio(%d): read direction failed ([%s])\n", pin, direction_str);
        close(gpio_fd);
        return GPIO_ERR;
    }

    close(gpio_fd);
    return GPIO_OK;
}


int gpio_set_value_init(unsigned int pin)
{
    int gpio_fd = -1;
    int ret;

    if (pin >= MAX_GPIO) return GPIO_ERR;

    MUTEX_LOCK;

    // already opened ? */
    if (-1 == gpio_setval_fd[pin])
    {
       if ((gpio_fd = _gpio_open_value(pin)) == -1) 
       {
          MUTEX_UNLOCK;
          return GPIO_ERR;
       }
   
       //update value fd
       gpio_setval_fd[pin] = gpio_fd;
    }

    MUTEX_UNLOCK;

    return GPIO_OK;
}


int gpio_set_value_release(unsigned int pin)
{
    if (pin >= MAX_GPIO) return GPIO_ERR;

    MUTEX_LOCK;

    if (-1 != gpio_setval_fd[pin]) 
    {
       close(gpio_setval_fd[pin]);
       gpio_setval_fd[pin] = -1;
    }

    MUTEX_UNLOCK;

    return GPIO_OK;
}


int gpio_set_value(unsigned int pin, int value)
{
    int ret = -1;
    char *value_str = (value == GPIO_LOW) ? "0" : "1";
    int gpio_fd;

    if (pin >= MAX_GPIO) return GPIO_ERR;

    MUTEX_LOCK;

    if ((gpio_fd = gpio_setval_fd[pin]) == -1)
    {
       //not already opened
       gpio_fd = _gpio_open_value(pin);
       if (-1 == gpio_fd) 
       {
          MUTEX_UNLOCK;
          return GPIO_ERR;
       }
    }
 
    ret = write(gpio_fd, value_str, strlen(value_str));

    //close fd if not stored
    if (-1 == gpio_setval_fd[pin])
    { 
       close(gpio_fd);
       gpio_fd = -1;
    }

    MUTEX_UNLOCK;

    if(ret < 0)
    {
        LOG_ERR("gpio(%d): set value %s failed (%d)\n", pin, value_str, ret);
        return GPIO_ERR;
    }
    return GPIO_OK;
}


int gpio_get_value(unsigned int pin, int *value)
{
    int ret = -1;
    char value_str[16];
    int gpio_fd;

    if (pin >= MAX_GPIO) return GPIO_ERR;

    if (NULL == value)
    {
        LOG_ERR("gpio(%d): read value with NULL pointer\n", pin);
        return GPIO_ERR;
    }

    MUTEX_LOCK;

    if ((gpio_fd = gpio_setval_fd[pin]) == -1)
    {
       //not already opened
       gpio_fd = _gpio_open_value(pin);
       if (-1 == gpio_fd) 
       {
          MUTEX_UNLOCK;
          return GPIO_ERR;
       }
    }

    memset(value_str, 0, sizeof(value_str));
    if ((ret = read(gpio_fd, value_str, sizeof(value_str)-1)) > 0)
    {
       *value = (value_str[0] == '0') ? GPIO_LOW : GPIO_HIGH;
    }
    else ret = -1;

    //close fd if not stored
    if (-1 == gpio_setval_fd[pin])
    { 
       close(gpio_fd);
       gpio_fd = -1;
    }

    MUTEX_UNLOCK;

    if(ret < 0)
    {
        LOG_ERR("gpio(%d): read value failed \n", pin);
        return GPIO_ERR;
    }
    return GPIO_OK;
}
