/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/27 jerryzh
    Creation for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <getopt.h>
#include <sys/mman.h>
#include <string.h>

#include "stdinc.h"
#include "log.h"
#include "ticker.h"
#include "worker.h"
#include "timevt.h"

static volatile sig_atomic_t interrupted = 0;

static void interrupt_handler(int signum)
{
    interrupted = signum;
}

static int interrupt_on(const int signum)
{
    struct sigaction act;

    if (signum < 1 || signum > SIGRTMAX)
        return errno = EINVAL;

    sigemptyset(&act.sa_mask);
    act.sa_handler = (signum == SIGHUP) ? SIG_IGN : interrupt_handler;
    act.sa_flags = 0;
    if (sigaction(signum, &act, NULL))
        return errno;

    return 0;
}

extern int oswrapper_init(void);
extern void init_drvled(int max_led);
extern void init_drvkeyb(void);
extern void init_tskdisp(void);
extern void init_tskHID(void);

bool_t test_mode = FALSE;
bool_t paper_version = FALSE;

char A_version[33];
char A_pcms[33];
char A_sn[33];
char A_icons_md5[33];
          
static const char optionsstr[] =
"Usage:\n"
"-h, --help\tGet this help message\n"
"-T, --test\ttest mode\n"
"-P, --paper\tpaper module\n"
"-V, --verbose\tverbose mode, default NO\n"
"Example:\n" 
"aom --test --verbose\n" ;

static const struct option long_options[] = {
    { .name = "help",       .has_arg = 0, .flag = NULL, .val = 'h' },
    { .name = "test",        .has_arg = 0, .flag = NULL, .val = 'T' },
    { .name = "paper",     .has_arg = 0, .flag = NULL, .val = 'P' },    
    { .name = "verbose",  .has_arg = 0, .flag = NULL, .val = 'V' },
    { NULL, 0, NULL, 0}
};

/*****************************************************************
 * @Func
 *        parse_opt Function
 * @Param
 *        
 * @Retrun
 *        -1: Failure
 *         0: Success
******************************************************************/

static int parse_opt(int argc, char * const argv[])
{
    int key;
    
    if( argc <2 ){//no paramete, nomal start
        return 0;
    }

    while(-1!= (key = getopt_long(argc, argv, "hTPV", long_options, NULL))) 
    {
        switch (key) 
        {
            case 'V':
                SetLogLevel(LOG_DEBUG);
                break;

            case 'T':
                test_mode = TRUE;
                break;

            case 'P':
                paper_version = TRUE;
                break;
                
            default:
                fprintf(stderr, "Use -h for help\n");
                return -1;    
        }
    }
    return 0;
}

static void init_identity()
{
    char *version = getenv("VersionSoft");
    char *pcms = getenv("PCMS");
    char *sn= getenv("SerialNumber");
    char *icons_md5 = getenv("ICONS_MD5");
    int cp_size;
    
    if (version != NULL)
    {
        cp_size= (strlen(version) <= 32) ? strlen(version) : 32;
        memset(A_version, 0 ,33);
        strncpy(A_version, version, cp_size);
    }

    if (pcms != NULL)
    {
        cp_size= (strlen(pcms) <= 32) ? strlen(pcms) : 32;
        memset(A_pcms, 0 ,33);
        strncpy(A_pcms, pcms, cp_size);
    }

    if (sn != NULL)
    {
        cp_size= (strlen(sn) <= 32) ? strlen(sn) : 32;
        memset(A_sn, 0 ,33);
        strncpy(A_sn, sn, cp_size);
    }

    if (icons_md5 != NULL)
    {
        cp_size= (strlen(icons_md5) <= 32) ? strlen(icons_md5) : 32;
        memset(A_icons_md5, 0 ,33);
        strncpy(A_icons_md5, icons_md5, cp_size);
    }

    LOGI("\n version = %s\n pcms = %s\n sn = %s\n icons_md5 = %s", A_version, A_pcms, A_sn, A_icons_md5);
}

int main(int argc, char *argv[])
{
    int rc = 0;
    
    // set system signal handler
    if (interrupt_on(SIGINT) || interrupt_on(SIGHUP) || interrupt_on(SIGTERM)){
        LOGE("Cannot set interrupt handlers: %s.\n", strerror(errno));
        return -1;
    }

    // get & check input parameters 
    rc = parse_opt(argc, argv);
    if( -1 == rc )
    {
        return -1;
    }

    oswrapper_init();

    init_identity();
    init_ticker ();
    init_worker();
    init_timevt ();
    init_drvkeyb();

    init_drvled(23);

    LOGI("init tskdisp");
    init_tskdisp(); 
        
    LOGI("init tskHID");
    init_tskHID();

    while (!interrupted) sleep(1);

    return 0;
}

