#ifndef __USB_HID_H_
#define __USB_HID_H_

extern void init_tskHID(void);

#endif