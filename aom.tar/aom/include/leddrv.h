#ifndef __LED_DRV_H_
#define __LED_DRV_H_

#include "stdinc.h"

#define     LED_OFF                    0x00
#define     LED_ON                      0x01
#define     LED_FAST_BLINK       0x02
#define     LED_BLINK                 0x03
#define     LED_NOP                    0xff

#define LED_STATE_VALIDATE(s)         \
    ((((s)==LED_ON) ||((s)==LED_OFF) || ((s)==LED_BLINK) || ((s)==LED_FAST_BLINK) || ((s)==LED_NOP)) ? TRUE : FALSE)
                                                              
extern void init_drvled(int max_led);
extern void drvled_onoff(int ledId, bool_t onoff);
extern void drvled_blink(int ledId, bool_t fast);
#endif

