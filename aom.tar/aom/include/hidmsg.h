#ifndef __HID_EVT_H_
#define __HID_EVT_H_

#include "stdinc.h"

/************************
    MSG type definition
************************/
typedef enum
{
    //msg from slave to master
    HID_MSG_SLAVE                            = 0x00, //not used
    HID_MSG_KEY                                = 0x01,
    HID_MSG_INFO_VER                      = 0x02,
    HID_MSG_INFO_PCMS                   = 0x03,
    HID_MSG_INFO_SN                       = 0x04,
    HID_MSG_INFO_ICONS_MD5         = 0x05,

    //msg from master to slave
    HID_MSG_MASTER                       = 0x80, // not used
    HID_MSG_RESET                          = 0x81,
    HID_MSG_SCREENINFO                = 0x82,
    HID_MSG_SCREENINFO_DONE     = 0x83,
    HID_MSG_KEYINFO                      = 0x84, 
    HID_MSG_PAGEICON                    = 0x85,
    HID_MSG_UPG                              = 0x86,
    HID_MSG_CMD                              = 0x87,
    HID_MSG_SCREENSAVER              = 0x88,
    HID_MSG_LOGLEVEL                     = 0x89,
    HID_MSG_BACKLIGHT_LEVEL       = 0x8a,
    HID_MSG_SKIN_RELOAD              = 0x8b,
    HID_MSG_INFO_REQUEST            = 0x8c,
    
    HID_MSG_MAX                              = 0xff
} hidmsg_t;

/*************************************
    sub opcode definition for screen update
*************************************/
#define OP_ICON_SET         0x01
#define OP_LED_SET           0x02
#define OP_LABEL_SET       0x03

#define ICON_UNKOWN               0xffff
#define ICON_NO                        0x0fff

//page status, on/off/highlight
#define PAGE_NO            0x00
#define PAGE_ON            0x01
#define PAGE_OFF          0x02
#define PAGE_HIG          0x03
/*************************************
   typedef for key item
*************************************/
typedef uint16_t   keyInd_t;
typedef uint16_t   iconInd_t;
typedef uint8_t     ledSt_t;
typedef struct {
    uint8_t*    content;
    uint8_t    size;
} label_t;

/************************
    MSG header definition
************************/
typedef struct {
    hidmsg_t msg_type;
    uint16_t body_len;
}hid_msg_header;

/************************
    MSG body definition
************************/
// hid key msg
typedef struct
{
    keyInd_t key;
} hid_msg_body_key;

/************************
    screen key status definition
************************/
typedef struct key_disp_infor
{
    keyInd_t key_index; //key index
    iconInd_t icon_id; //icon id
    ledSt_t led_stat;       // led status
    label_t label;
    struct key_disp_infor *next;
} key_disp_infor_t;

#define HID_MSG_HEADER_SIZE                  sizeof(hid_msg_header);
#define KEY_INDEX_VALIDATE(s)                 ((((s) < 20) && ((s) >= 0)) ? TRUE : FALSE)
/***********************************************************
 screen msg format:
       1Byte       4Byte     1Byte
        KEY + <SubLength + OpCode + state> + ....
 ***********************************************************/
#define KEY_IND_SIZE                           sizeof(keyInd_t)
#define ICON_IND_SIZE                         sizeof(iconInd_t)
#define LED_STAT_SIZE                         sizeof(ledSt_t)

#define SEC_LENGHT_SIZE                    sizeof(uint16_t)
#define SUB_LENGHT_SIZE                    sizeof(uint8_t)
#define SUB_OPCODE_SIZE                    sizeof(uint8_t)

#define GET_HID_MSG_TYPE(m)                  (hidmsg_t)((m)->msg_type)
#define SET_HID_MSG_TYPE(m,t)                do {(m)->msg_type = (hidmsg_t)(t);} while (0)


extern key_disp_infor_t* init_key_disp_info(keyInd_t key_index, iconInd_t icon_id, ledSt_t led_stat, label_t* label);
extern bool_t destroy_key_disp_info(key_disp_infor_t** disp_item);
extern bool_t destroy_key_disp_list_info(key_disp_infor_t** disp_header);
extern bool_t insert_key_disp_info(key_disp_infor_t** disp_header, key_disp_infor_t* disp_item);
extern key_disp_infor_t* get_key_disp_info_by_index(key_disp_infor_t** disp_header, uint8_t key_index);
extern void print_key_disp_info(key_disp_infor_t* disp_header);
extern char *hidmsg2str(hidmsg_t msg);
#endif
