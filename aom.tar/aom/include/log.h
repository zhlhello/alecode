// Copyright 2013 Google Inc. All Rights Reserved.
//
// Log - Platform independent interface for a Logging class
//
#ifndef update_engine_CORE_LOG_H_
#define update_engine_CORE_LOG_H_

#include "syslog.h"

typedef unsigned char LogPriority;
// Simple logging class. The implementation is platform dependent.

void SetLogLevel(LogPriority level);
void Log(const char* file, int line, LogPriority level, const char* fmt, ...);

// Log APIs
#define LOGE(...) Log(__FILE__, __LINE__, LOG_ERR, __VA_ARGS__)
#define LOGW(...) Log(__FILE__, __LINE__, LOG_WARNING, __VA_ARGS__)
#define LOGI(...) Log(__FILE__, __LINE__, LOG_INFO, __VA_ARGS__)
#define LOGD(...) Log(__FILE__, __LINE__, LOG_DEBUG, __VA_ARGS__)
#define LOGV(...) Log(__FILE__, __LINE__, LOG_VERBOSE, __VA_ARGS__)

#endif  // update_engine_CORE_LOG_H_
