/* ---------------------------------------------------------------
 *  COMPONENT :     NOE
 *
 *  MODULE:         gpio.h
 *
 *  DATED:          2015/11/10
 *
 *  AUTHOR:         michelsu
 *
 *  DESCRIPTION:    gpio access functions
 *
 *  HISTORY:
 *
 *
 */

#ifndef _GPIO_H
#define _GPIO_H

#define MAX_GPIO    160

//status
#define GPIO_OK     0
#define GPIO_ERR    -1

//direction
#define GPIO_IN     0
#define GPIO_OUT    1
#define GPIO_OUT_H  2   // out high

//value
#define GPIO_LOW    0
#define GPIO_HIGH   1


/*
 * export gpio into sysfs
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_export(unsigned int pin);


/*
 * export gpio into sysfs
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_unexport(unsigned int pin);


/*
 * set gpio direction (GPIO_IN, GPIO_OUT, GPIO_OUT_H)
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_set_direction(unsigned int pin, int direction);


/*
 * get gpio direction (GPIO_IN, GPIO_OUT, GPIO_OUT_H)
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_get_direction(unsigned int pin, int *direction);


/*
 * open gpio file descriptor for value
 * will accelerate gpio_set_value() & gpio_get_value() treatment
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_set_value_init(unsigned int pin);


/*
 * release gpio file descriptor for value
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_set_value_release(unsigned int pin);


/*
 * set gpio value (GPIO_LOW, GPIO_HIGH)
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_set_value(unsigned int pin, int value);


/*
 * get gpio value (GPIO_LOW, GPIO_HIGH)
 * return GPIO_OK if 0K, GPIO_ERR if error
*/
extern int gpio_get_value(unsigned int pin, int *value);

#endif
