/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/10/21 jerryzh
    Creation for USB AOM support.

  -----------------------------------------------------------------------------*/
#ifndef AOM_COMMON_HEADER__
#define AOM_COMMON_HEADER__

#define AOM_MAX_LINE  10
#define ICON_NUM (AOM_MAX_LINE*2)
#define PKEY_NUM ICON_NUM
#define MAX_PAGES_CFG  10

//page icon start number
#define PAGE_ICON_HIG_BASE    97
#define PAGE_ICON_OFF_BASE    98
#define PAGE_ICON_ON_BASE      99  

#endif
