#ifndef __KEY_DRV_H_
#define __KEY_DRV_H_

#include <linux/input.h>

#include "stdinc.h"

/*-----------------------------------------------------------------------------
  keycodes for AOM
  ---------------------------------------------------------------------------*/
typedef enum
{
    // group: NUMPAD    
    K_PK0,
    K_PK1,
    K_PK2,
    K_PK3,
    K_PK4,
    K_PK5,
    K_PK6,
    K_PK7,
    K_PK8,
    K_PK9,
    K_PK10,
    K_PK11,
    K_PK12,
    K_PK13,
    K_PK14,
    K_PK15,
    K_PK16,
    K_PK17,
    K_PK18,
    K_PK19,
    K_LEFT,
    K_MIDDLE,
    K_RIGHT,
    KEYS_MAX,
    
    K_Empty      = 255
} keycode_t;


typedef struct {
    keycode_t     keycode;
    unsigned int   code;
    char             *str;
} key_info_t;

static key_info_t keymap[] = {
    {.keycode = K_PK0    , .code =  KEY_F1     , .str = "KEY_F1"},
    {.keycode = K_PK1    , .code =  KEY_F2     , .str = "KEY_F2"},
    {.keycode = K_PK2    , .code =  KEY_F3     , .str = "KEY_F3"},
    {.keycode = K_PK3    , .code =  KEY_F4     , .str = "KEY_F4"},
    {.keycode = K_PK4    , .code =  KEY_F5     , .str = "KEY_F5"},
    {.keycode = K_PK5    , .code =  KEY_F6     , .str = "KEY_F6"},
    {.keycode = K_PK6    , .code =  KEY_F7     , .str = "KEY_F7"},
    {.keycode = K_PK7    , .code =  KEY_F8     , .str = "KEY_F8"},
    {.keycode = K_PK8    , .code =  KEY_F9     , .str = "KEY_F9"},
    {.keycode = K_PK9    , .code =  KEY_F10   , .str = "KEY_F10"},
    {.keycode = K_PK10    , .code =  KEY_F11   , .str = "KEY_F11"},
    {.keycode = K_PK11    , .code =  KEY_F12   , .str = "KEY_F12"},
    {.keycode = K_PK12    , .code =  KEY_F13   , .str = "KEY_F13"},
    {.keycode = K_PK13    , .code =  KEY_F14   , .str = "KEY_F14"},
    {.keycode = K_PK14    , .code =  KEY_F15   , .str = "KEY_F15"},
    {.keycode = K_PK15    , .code =  KEY_F16   , .str = "KEY_F16"},
    {.keycode = K_PK16    , .code =  KEY_F17   , .str = "KEY_F17"},
    {.keycode = K_PK17    , .code =  KEY_F18   , .str = "KEY_F18"},
    {.keycode = K_PK18    , .code =  KEY_F19   , .str = "KEY_F19"},
    {.keycode = K_PK19    , .code =  KEY_F20   , .str = "KEY_F20"}, 
    {.keycode = K_LEFT    , .code =  BTN_LEFT   , .str = "BTN_LEFT"},
    {.keycode = K_MIDDLE    , .code =  BTN_MIDDLE   , .str = "BTN_MIDDLE"},
    {.keycode = K_RIGHT    , .code =  BTN_RIGHT   , .str = "BTN_RIGHT"}, 
    {.keycode = K_Empty    , .code =  KEY_RESERVED   , .str = "UNKNOWN"},
};

#define MASK_UP2DOWN   0x80

extern void init_drvkeyb(void);

#endif
