#ifndef __BACKLIGHT_H_
#define __BACKLIGHT_H_

#include "stdinc.h"

extern bool_t  set_backlight_level(uint8_t level);
extern uint8_t get_backlight_level();
extern void backlight_onoff(bool_t onoff);

#endif
