#ifndef _CONFIGS_H_
#define _CONFIGS_H_

#include "stdinc.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    L10n_TYPE_CHI = 0,
    L10n_TYPE_JPN = 1,
    L10n_TYPE_KOR = 2
} L10n_type_t;

extern bool_t CONFIG_get_use_customisation(void);
extern void CONFIG_set_use_customisation(bool_t use_customisation);

extern uint16_t CONFIG_get_skin_id();
extern void     CONFIG_set_skin_id(uint16_t skin_id);

extern uint16_t CONFIG_get_L10n_type();
extern void CONFIG_set_L10n_type(L10n_type_t type);
#ifdef __cplusplus
}
#endif


#endif /* _CONFIGS_H_ */

