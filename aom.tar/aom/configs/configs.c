/* Standard */
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <unistd.h>

#include "stdinc.h"
#include "skins.h"
#include "configs.h"

#define INVALID_SKIN_ID 0xffff
static uint16_t i_skin_id = 0;//default use skin 0

uint16_t CONFIG_get_skin_id()
{
    return i_skin_id;
}

void CONFIG_set_skin_id(uint16_t skin_id)
{
    //
    // If current skin_id value is invalid, do not attempt to reload the
    // skins because the module is not yet initialized (a protection has
    // been added). The skins will be initialized and loaded when the
    // display task is created.
    //
    bool_t fl_reload = (i_skin_id != INVALID_SKIN_ID);

    // check if skin_id is in range
    if (skin_id >= MAX_SKINSBASE)
        skin_id = ID_SKIN_DEFAULT;

    //
    // This must be done before reloading the skins to make sure
    // CONFIG_get_skin_id() returns the correct value!
    //
    i_skin_id = skin_id;

    if (fl_reload)
        skins_reload();
}

bool_t cust_flag = FALSE;
bool_t CONFIG_get_use_customisation(void)
{
    return cust_flag;
}
void CONFIG_set_use_customisation(bool_t use_customisation)
{
    cust_flag = use_customisation;
}

static L10n_type_t g_dwL10nType = L10n_TYPE_CHI;

uint16_t CONFIG_get_L10n_type()
{
    return g_dwL10nType;
}

void CONFIG_set_L10n_type(L10n_type_t type)
{
    g_dwL10nType = type;
}