#include <stdio.h>  
  
#include <stdlib.h>  
  
#include <string.h>  
#include <unistd.h>  
#include <fcntl.h>   //define O_WRONLY and O_RDONLY  

#include "log.h"
#include "backlight.h"

#include "gpio.h"

#define BL_MAX_LEVEL                               9
#define BL_MAX_BRIGHTNESS                    255
#define GPIO_BACKLIGHT_HIGH                64

//Temp: this brightness level just defined like 9000 phone.
static uint8_t bl_level[BL_MAX_LEVEL] = {198, 100, 6, 25, 45, 70, 100, 140, 190};

#define BRIGHTNESS_INTERFACE                          "/sys/class/backlight/backlight/brightness"
#define PWR_INTERFACE                                       "/sys/class/backlight/backlight/bl_power"

static bool_t gpio_init = FALSE;
void init_gpio()
{
    if (gpio_init == TRUE) return;
    
    if (-1 != GPIO_BACKLIGHT_HIGH)
    {
       gpio_export(GPIO_BACKLIGHT_HIGH);
       gpio_set_direction(GPIO_BACKLIGHT_HIGH, GPIO_OUT);
    }
}

void set_gpio_backlight(bool_t state)
{
    if (-1 != GPIO_BACKLIGHT_HIGH)
    {
       if (state == OFF)
       {
          gpio_set_value(GPIO_BACKLIGHT_HIGH, GPIO_LOW);
       }
       else
       {
          gpio_set_value(GPIO_BACKLIGHT_HIGH, GPIO_HIGH);
       }
    }

}
/*-----------------------------------------------------------------------------
    Set backlight bringnes level function: 
        @INPUT level: brightness level
        
  ---------------------------------------------------------------------------*/
bool_t set_backlight_level(uint8_t level)
{    
    FILE * fp = NULL;

    if ((level > BL_MAX_LEVEL) || (level < 1))
    {
        LOGE("Allowed Values are [1..9]");
        return FALSE;
    }
    
    init_gpio();

    if (level <= 2)
        set_gpio_backlight(OFF);
    else
        set_gpio_backlight(ON);
    
    fp =fopen(BRIGHTNESS_INTERFACE, "w");
    if (fp == NULL)
    {
        LOGE("open '%s' failed\n", BRIGHTNESS_INTERFACE);
        return FALSE;
    }

    fprintf(fp, "%d", bl_level[level-1]);
    fclose(fp);
    fp = NULL;

    return TRUE;
}

/*-----------------------------------------------------------------------------
    get backlight bringnes level function: 
        @RETURN level: brightness level
        
  ---------------------------------------------------------------------------*/
uint8_t get_backlight_level()
{    
    FILE * fp = NULL;
    int bl_brightness;
    uint8_t level = 0;
     
    fp =fopen(BRIGHTNESS_INTERFACE, "r");
    if (fp == NULL)
    {
        LOGE("open '%s' failed\n", BRIGHTNESS_INTERFACE);
        return -1;
    }
    
    fscanf(fp, "%ld", &bl_brightness);
    fclose(fp);
    fp = NULL;

    while ((level < BL_MAX_LEVEL) && ((bl_level[level]) < bl_brightness)) { level++; }

    return (level < BL_MAX_LEVEL) ? level : (BL_MAX_LEVEL-1);
}

/*-----------------------------------------------------------------------------
    baclight onoff contral function: 
        @onoff: state to be set

  ---------------------------------------------------------------------------*/
void backlight_onoff(bool_t onoff)
{
    FILE * fp = NULL;
    
    //set bl_power to control on/off
    fp =fopen(PWR_INTERFACE, "w");
    if (fp == NULL)
    {
        LOGE("open '%s' failed\n", PWR_INTERFACE);
        return;
    }

    fprintf(fp, "%s", onoff ? "0" : "1");
    fclose(fp);
    fp = NULL; 
}

