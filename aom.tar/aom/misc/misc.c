/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/11/13 jerryzh
    create from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include<unistd.h>
#include <errno.h>

#include "log.h"
#include "stdinc.h"
#include "hidmsg.h"

static bool_t do_upgrade()
{
    char upgrade_cmd[] = "/usr/sbin/upgrade.sh";  
    char *upgrade_argv[] = {"upgrade.sh", NULL};

    //execute upgrade command
    execv(upgrade_cmd, upgrade_argv);

    return TRUE;
}

static bool_t do_reset()
{
    char reboot_cmd[] = "/bin/busybox";
    char *reboot_argv[] = {"busybox", "reboot", NULL};

    execv(reboot_cmd, reboot_argv);

    return TRUE;
}


void misc_task_entry (void *data)
{
    hidmsg_t msg_type;

    msg_type = (hidmsg_t)data;
    LOGD("Enter misc_task_entry, msg_type = %d\n", msg_type);

    switch(msg_type)
    {
        case HID_MSG_RESET:
        {
            do_reset();
            break;
        }
        case HID_MSG_UPG:
        {
            do_upgrade();
            break;
        }
        case HID_MSG_SKIN_RELOAD:
        {
            //not implement
            break;
        }
        
        default:
            break;
    }
    //loop, wait reboot
    do {sleep(1);} while(1);
}
