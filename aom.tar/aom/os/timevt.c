/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdint.h>
#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"

#include "systime.h"

#include "ticker.h"
#include "worker.h"
#include "timevt.h"



/*-----------------------------------------------------------------------------
  la structure interne utilisee pour la gestion des timevt
  ---------------------------------------------------------------------------*/
//XTSce74136+
static struct
{
    int        worker_id;
    uint32_t   timeout  ;
    uint32_t   ms_ref   ;
} timevt_callbacks[MAX_TIMEVT_CALLBACKS];
//XTSce74136-



/*-----------------------------------------------------------------------------
  les variables privees
  ---------------------------------------------------------------------------*/
static uint32_t     registered_count;
static int          ticker_id;



/*-----------------------------------------------------------------------------
  ticker handler
  ---------------------------------------------------------------------------*/
static void timevt_ticker_callback(uint32_t ms, uint32_t tck, void *data)
{
    int i;

    for(i = 0 ; (i < MAX_TIMEVT_CALLBACKS) ; i++)
    {
//XTSce74136+
        if (timevt_callbacks[i].worker_id != -1)
        {
            uint32_t timeout = timevt_callbacks[i].timeout;
            uint32_t elapsed_time = ms - timevt_callbacks[i].ms_ref;

            if (timeout && (elapsed_time >= timeout) && (ms > timevt_callbacks[i].ms_ref))
            {
                /*
                if(timeout == 10*1000)
                {
                     syslog(FLUX_DISPLAY, LOG_ANOMALY, "elapsed_time=%d,%d,%d",elapsed_time,ms,timevt_callbacks[i].ms_ref);
                }*/
                
                timevt_callbacks[i].timeout = 0;
                worker_execute(timevt_callbacks[i].worker_id);
            }
        }
//XTSce74136-
    }
}



/*-----------------------------------------------------------------------------
  timevt restart (initial value is reloaded)
  ---------------------------------------------------------------------------*/
void timevt_restart(int id, uint32_t timeout)
{
    // est-ce que cet 'id' est correct ?
    if ((id < 0) || (id >= MAX_TIMEVT_CALLBACKS)) {
        LOGE("invalid id: %d", id);
        return;
    }
    // est-ce que ce 'timevt' est enregistre ?
    if (timevt_callbacks[id].worker_id == -1) {
        LOGW("id is %d", id);
    }

    // timeout valide ?
    if (timeout == 0) {
        LOGE("timeout is zero");
        return;
    }

    // on recharge le nouveau timeout 
    timevt_callbacks[id].timeout = timeout * 1000;
    // on memorise le tick de depart
    timevt_callbacks[id].ms_ref = get_milliseconds();
}



/*-----------------------------------------------------------------------------
  the specified callback is registered to the ticker only if an empty room
  is found (MAX_TICKER_CALLBACKS)
  ---------------------------------------------------------------------------*/
int timevt_register(timevt_callback_t f, void *d, uint32_t t)
{
    int i;

    // callback valide ?
    if (f == NULL) {
        LOGE("invalid callback function");
        return -1;
    }

    // timeout valide ?
    if (t == 0) {
        LOGE("timeout is zero");
        return -1;
    }

    // il faut rechercher une place libre
    for(i = 0 ; (i < MAX_TIMEVT_CALLBACKS) ; i++)
    {
        int worker_id = timevt_callbacks[i].worker_id;
        
        if (worker_id == -1)
        {
            worker_id = worker_register(f, d);
            if (worker_id >= 0)
            {
                timevt_callbacks[i].worker_id = worker_id;
//XTSce74136+
                timevt_callbacks[i].timeout   = t * 1000;
                timevt_callbacks[i].ms_ref    = get_milliseconds();
//XTSce74136-

                // si c'est le premier timevt, on s'enregistre aupres du ticker
                registered_count++;
                if (registered_count == 1)
                    ticker_id = ticker_register(timevt_ticker_callback, NULL);
                
                if (ticker_id >= 0)
                    return i;
            }
        }
    }
    LOGD("TIMEVT : failed to register callback %p", f);
    return -1;
}



/*-----------------------------------------------------------------------------
  the specified callback is unregistered from the ticker only if it is found
  in the callbacks list
  ---------------------------------------------------------------------------*/
void timevt_unregister(int id)
{
    // est-ce que cet 'id' est correct ?
    if ((id < 0) || (id >= MAX_TIMEVT_CALLBACKS)) {
        LOGE("invalid id: %d", id);
        return;
    }

    // est-ce qu'il y a au moins un 'timevt' enregistre
    if (registered_count == 0) {
        LOGE("registered timer count is 0; id: %d", id);
        return;
    }

    // est-ce que ce 'timevt' est enregistre ?
    if (timevt_callbacks[id].worker_id == -1) {
        LOGE("invalid id: %d", id);
        return;
    }

    // si le nouveau nombre de 'timevt' est zero, on se desenregistre du ticker
    registered_count--;
    if (registered_count == 0)
        ticker_unregister(ticker_id);

    worker_unregister(timevt_callbacks[id].worker_id);
    timevt_callbacks[id].worker_id = -1;
}



/*-----------------------------------------------------------------------------
  timevt initialization
  ---------------------------------------------------------------------------*/
void init_timevt(void)
{
    int i;

    for(i = 0 ; (i < MAX_TIMEVT_CALLBACKS) ; i++)
        timevt_callbacks[i].worker_id = -1;

    registered_count = 0;
}
