/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "mem_wrapper.h"
#include "log.h"


#ifdef MEMORY_CHECK

#define MAX_MEM_ALLOC_ARRAY_SIZE 300
#define MAX_FILE_NAME_LEN 100

typedef struct {
    void *addr;
    char filename[MAX_FILE_NAME_LEN+1];
    unsigned int line;
} MEM_ALLOC_SINGLE_T;

typedef struct {
    MEM_ALLOC_SINGLE_T array[MAX_MEM_ALLOC_ARRAY_SIZE];
    unsigned int count; //how many single alloc info
} MEM_ALLOC_T;

MEM_ALLOC_T mem_alloc_info;
pthread_mutex_t mem_mutex;
bool mem_check = false;

#endif


/**
 * GLOBAL FUNCTIONS DEFINITIONS
 */

/**
 * Reallocate memory
 */

void* pw_realloc_exec(void *ptr, unsigned int size, const char *file, const int line)
{
    void *newptr = NULL;
    newptr = pw_malloc_exec( size, file, line );

    //TODO: dangerous, i don't know the original memory size
    pw_memcpy_exec(newptr, ptr, size, file, line);
    pw_free_exec( ptr, file, line );

    return newptr;
}


/**
 * Allocate memory and Memset to 0
 */

void * pw_malloc_exec( unsigned int size, const char *file, const int line )
{
    if ( size <= 0 )
    {
        LOGD("Malloc size <= 0!\n");
        return NULL;
    }
    else
    {
        void *ptr = NULL;
        ptr = malloc(size);
        if ( ptr == NULL ){
            LOGD("Malloc error!\n");
        }
        else{
            memset( ptr, 0, size );

#ifdef MEMORY_CHECK
            if ( mem_check )
            {
                pthread_mutex_lock(&mem_mutex);

                if ( mem_alloc_info.count >= MAX_MEM_ALLOC_ARRAY_SIZE )
                {
                    LOGD("MAX_MEM_ALLOC_ARRAY_SIZE too small!!!\n");
                }
                else
                {
                    mem_alloc_info.array[mem_alloc_info.count].addr = ptr;
                    strncpy( mem_alloc_info.array[mem_alloc_info.count].filename, file, MAX_FILE_NAME_LEN );
                    mem_alloc_info.array[mem_alloc_info.count].line = line;
                    mem_alloc_info.count++;
                }

                pthread_mutex_unlock(&mem_mutex);
            }
#endif
        }

        return ptr;
    }
}


/**
 * Release memory
 */
void pw_free_exec( void *ptr, const char *file, const int line )
{
    if ( ptr == NULL )
    {
        LOGD("Free NULL pointer!\n");
    }
    else
    {
#ifdef MEMORY_CHECK
        if ( mem_check )
        {
            unsigned int i;

            pthread_mutex_lock( &mem_mutex );

            for ( i=0; i < mem_alloc_info.count; i++ )
            {
                if ( mem_alloc_info.array[i].addr == ptr )
                {
                    break;
                }
            }

            if ( mem_alloc_info.count == i )
            {
                LOGD("%p NOT FOUND!!!\n", ptr);
            }
            else
            {
                if (i != (mem_alloc_info.count - 1))
                {
                    memcpy(&mem_alloc_info.array[i], &mem_alloc_info.array[mem_alloc_info.count-1], sizeof(MEM_ALLOC_SINGLE_T));
                }

                mem_alloc_info.count--;
            }

            pthread_mutex_unlock(&mem_mutex);
        }
#endif
        free(ptr);
    }
}


/**
 * Copy memory
 */
void pw_memcpy_exec(void *dst, void *ori, unsigned int size, const char *file, const int line)
{
    if ( dst == NULL )
    {
        LOGD("DST NULL\n");
    }
    else if ( ori == NULL )
    {
        LOGD("ORI NULL\n");
    }
    else
    {
#ifdef MEMORY_CHECK
        LOGD("memcpy!\n");
#endif        
        memcpy(dst, ori, size);
    }
}


/**
 * Set memory
 */
void pw_memset_exec(void *dst, int c, unsigned int size, const char *file, const int line)
{
    if ( dst == NULL )
    {
        LOGD("DST NULL\n");
    }
    else
    {
#ifdef MEMORY_CHECK
        LOGD("memset!\n");
#endif        
        memset( dst, c, size );
    }
}


#ifdef MEMORY_CHECK
void pw_mem_check_start( void )
{
    pthread_mutex_init( &mem_mutex, NULL );
    mem_check = true;
    memset( &mem_alloc_info, 0, sizeof(mem_alloc_info) );
}


void pw_mem_check_stop( void )
{
    unsigned int i;

    LOGD("MEME LEAK check\n");

    mem_check = false;
    pthread_mutex_destroy(&mem_mutex);

    LOGD("MEME LEAK:count:%d\n", mem_alloc_info.count);

    for ( i = 0; i < mem_alloc_info.count; i++ )
    {
        LOGD("MEME LEAK::%p %s %d\n", 
               mem_alloc_info.array[i].addr, mem_alloc_info.array[i].filename, mem_alloc_info.array[i].line);
    }
}
#endif

