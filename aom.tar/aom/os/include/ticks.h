/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
  
#ifndef _TICKS_H_
#define _TICKS_H_

#  define UNIT_TIME_1us     (1)
#  define UNIT_TIME_10us    (10)
#  define UNIT_TIME_100us   (100)
#  define UNIT_TIME_1ms     (1000)
#  define UNIT_TIME_10ms    (UNIT_TIME_1ms   * 10)
#  define UNIT_TIME_100ms   (UNIT_TIME_10ms  * 10)
#  define UNIT_TIME_1s      (UNIT_TIME_100ms * 10)

#endif /* _TICKS_H_ */
