/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
  
/** @defgroup group3 OSWrapper
 *  This is the group of OS Wrapper Layer
 *  @{
 */

#ifndef _OS_WRAPPER_H_
#define _OS_WRAPPER_H_

#include <pthread.h>

#include "stdinc.h"
#include "byteorder.h"
#include "primitive.h"

//#include "ticks.h"
//#include "noeos_timer.h"

/*------------------------------------------------------------------
 * Module Macro and Type definitions
 * Module Variables Definitions
 *------------------------------------------------------------------*/

/*!
 * \def DONT_WAIT
 *  Semaphore use it as parameter to trigger a sem_trywait .
 */
#define DONT_WAIT   0

/*!
 * \def SUSPEND
 *  Semaphore use it as parameter to trigger a sem_wait .
 */
#define SUSPEND     -1

/*!
 * \def DECL_THREADS
 *  Thread declaration and definition .
 */
#define DECL_THREADS() \
        DECL_NORMAL(main),              /*!< NOEMMI Main Thread(Just an ID here)*/\
        DECL_NORMAL(timer),              /*!< Timer Thread                       */\
        DECL_NORMAL(worker),            /*!< Worker Thread                      */\
        DECL_NORMAL(display),           /*!< Display Thread                     */\
        DECL_NORMAL(dispevt),           /*!< Dispevt Thread                     */\
        DECL_NORMAL(keydrv),            /*!< Keydrv Thread                      */\       
        DECL_NORMAL(hidRd),             /*!< HID read Thread                     */\
        DECL_NORMAL(hidWt),              /*!< HID write Thread                     */ \
        DECL_NORMAL(misc),               /*!< other Thread                     */ 
/*!
 * \def DECL_MSGQUES
 *  Message Queue declaration and definition .
 */
#define DECL_MSGQUES() \
        DECL_NORMAL(dummy),              /*!< Dummy ID, not used, don't remove       */\
        DECL_NORMAL(worker),               /*!< Message Queue for Worker               */\
        DECL_NORMAL(display),               /*!< Message Queue for Display              */\
        DECL_NORMAL(hidWt),                 /*!< Message Queue for hid to be output    */
/*-------------------------------------------------------------------
  Threads
  -------------------------------------------------------------------*/

/*!
 * \enum thread_id_t
 *      The Thread IDs
 */
#define MAP_THREADS
#define DECL_NORMAL(name) THREAD_ID_##name
typedef enum {
    DECL_THREADS()
    THREAD_ID_MAX,			//!< Thread Number
    eCOMPONENT_UNKNOWN,			//!< Unknown Thread
    TASK_ID_UNKNOWN			//!< Unknown Thread
} thread_id_t;
#undef DECL_NORMAL
#undef MAP_THREADS

/*!
 * Creates a type name for thread entry point function type
 */
typedef void thread_entry_t(void);

/*------------------------------------------------------------------
  Queues
  ------------------------------------------------------------------*/
/*!
 * \enum msgQ_id_t
 * The Message Queue IDs
 */
#define MAP_MSGQUES
#define DECL_NORMAL(name) QUEUE_ID_##name
typedef enum {
    DECL_MSGQUES()
    QUEUE_ID_MAX
} msgQ_id_t;
#undef DECL_NORMAL
#undef MAP_MSGQUES

/*! Creates a type msg_t name for S_PRIMITIVE */
typedef S_PRIMITIVE msg_t;

/*------------------------------------------------------------------
  Semaphore
  ------------------------------------------------------------------*/

/*!
 * \enum sem_id_t
 * The User Semaphore IDs
 */
typedef enum {
    SEM_ID_user       	= 0, /*!< User Semaphore for use */
    SEM_ID_objmgr_list	= 1,/*!< imagebox fetch Semaphore */
    SEM_ID_MAX
} sem_id_t;

/*-----------------------------------------------------------------------------
  error status in NOE software
  -------------------------------------------------------------------------- */
typedef enum noe_status_e
{
    SUCCESS           = 1,
    FAILURE              ,               // general value, non specific
    QUEUE_FULL           ,
    TIMEOUT              ,
    NOT_AVAILABLE
} noe_status_t;

/*!
 * \enum thread_status_t
 * The Thread Status IDs
 */
typedef enum {
    THREAD_IS_CLOSED    = 0, /*!< Closed */
    THREAD_IS_RUNNING	= 1, /*!< Running */
    THREAD_STATUS_MAX
} thread_status_t;


#ifdef __cplusplus
extern "C" {
#endif

/*------------------------------------------------------------------
 * Module External functions Declaration
 *------------------------------------------------------------------*/

int     oswrapper_init  (void);
void    oswrapper_term  (void);

/*------------------------------------------------------------------
 * Thread
 *------------------------------------------------------------------*/

/*!
 * \def thread_create(id,entry)
 *  Create thread with \a id and function \a entry.
 */
#define thread_create(id,entry) _thread_create(__FILE__, __LINE__, id, entry, NULL)

/*!
 * \def thread_create_ex(id,entry,arg)
 *  Create thread with \a id and function \a entry, and argument \a arg
 */
#define thread_create_ex(id,entry,arg) _thread_create(__FILE__, __LINE__, id, entry, arg)

/*!
 * \def thread_delete(id)
 *  Delete thread which has \a id.
 */
#define thread_delete(id)       _thread_delete(__FILE__, __LINE__, id)

extern int _thread_create(const char *filename, int linenum,
         thread_id_t id, thread_entry_t entry, void* arg);

extern int _thread_delete(const char *filename, int linenum,
         thread_id_t id);

/*!
 * \def thread_get_status(id), thread_set_status(id,status), thread_set_tid(id)
 */
#define thread_get_status(id) 			_thread_get_status(__FILE__, __LINE__, id)
#define thread_set_status(id,status) 	_thread_set_status(__FILE__, __LINE__, id, status)
#define thread_set_tid(id) 				_thread_set_tid(__FILE__, __LINE__, id)


extern thread_status_t _thread_get_status(const char *filename, int linenum,
		thread_id_t id);
extern thread_status_t _thread_set_status(const char *filename, int linenum,
		thread_id_t id, thread_status_t status);

/*!
 * \brief Inquiry the thread Unique TID. Must be called in thread internal context.
 */
extern void _thread_set_tid(const char *filename, int linenum,
		thread_id_t id);
#if !defined(DBG_DW_N)
extern void        _thread_get_tid_me(void);
extern thread_id_t _thread_get_id(void);
#endif

//2013.06.12, gary.yu+
extern bool_t check_if_all_threads_exited(void);
extern void printf_all_alive_threads(void);
extern void request_all_threads_exit(void);
//2013.06.12, gary.yu-

/*------------------------------------------------------------------
 * Message Queue
 *------------------------------------------------------------------*/

/*!
 * \def msgQ_send(id, msg)
 *  Send a message into a message queue.
 */
#define msgQ_send(id, msg)    _msgQ_send(__FILE__, __LINE__, id, msg)

/*!
 * \def msgQ_recv(id, msg)
 *  Receive a message from a message queue.
 */
#define msgQ_recv(id, msg)    	     _msgQ_recv(__FILE__, __LINE__, id, &msg, FALSE)
#define msgQ_recv_nowait(id, msg)    _msgQ_recv(__FILE__, __LINE__, id, &msg, TRUE )

extern int _msgQ_send(const char *filename, int linenum,
   msgQ_id_t            id,
   msg_t                msg
);

extern int _msgQ_recv(const char *filename, int linenum,
   msgQ_id_t            id,
   msg_t               *ptr_msg,
   bool_t		nowait
);

extern msg_t _msgL_allocate(const char *filename, int linenum,
	msg_opcode_t        opcode,
	thread_id_t      	srcid ,
	uint32_t            data_length,
	const unsigned char *p_data
);


/*------------------------------------------------------------------
 * Semaphore
 *------------------------------------------------------------------*/

/*!
 * \def sem_create(id, ini_val)
 *  Create a semaphore.
 */
#define sem_create(id, ini_val) \
                            _sem_create(__FILE__, __LINE__, id, ini_val)

/*!
 * \def sem_delete(id)
 *  Delete a semaphore.
 */
#define sem_delete(id)      _sem_delete(__FILE__, __LINE__, id)

/*!
 * \def sem_give(id)
 *  Giving a semaphore.
 */
#define sem_give(id)        _sem_give(__FILE__, __LINE__, id)

/*!
 * \def sem_get(id,timeout)
 *  Getting a semaphore.
 */
#define sem_get(id,timeout) _sem_get (__FILE__, __LINE__, id, timeout)

/*!
 * \def sem_reset(id)
 *  Reset a semaphore.
 */
#define sem_reset(id)       _sem_reset(__FILE__, __LINE__, id)

/*!
 * \def sem_getval(id)
 *  Reset a semaphore.
 */
#define sem_getval(id)       _sem_getval(__FILE__, __LINE__, id)

extern bool_t is_sem_created(sem_id_t id);

extern int _sem_create(const char *filename, int linenum,
         sem_id_t id, uint32_t ini_value);

extern int _sem_delete(const char *filename, int linenum,
         sem_id_t id);

extern int _sem_give(const char *filename, int linenum,
         sem_id_t id);

extern int _sem_get (const char *filename, int linenum,
         sem_id_t id, int32_t timeoutms);

extern int _sem_reset(const char *filename, int linenum,
         sem_id_t id);

extern int _sem_getval(const char *filename, int linenum,
         sem_id_t id);

//crqms00190541 jerryzh+
extern int _reboot_lock(const char *filename, int linenum);
//crqms00209397 jerryzh+
extern int _reboot_unlock(const char *filename, int linenum, bool_t force);
extern int _reboot_lock_status(const char *filename, int linenum);
//crqms00209397 jerryzh-
//crqms00190541 jerryzh-

#ifdef __cplusplus
}
#endif

/*------------------------------------------------------------------
 * Macro for Porting NOE Old Source Codes
 *
 *------------------------------------------------------------------*/

#define msg_opcode(msg)     (msg.primitiveCode)
#define msgL_data(msg)      (msg.payload)
#define msgS_data(m)        ((m).shortmsg)

#define msgS_allocate(msg, opcode, short_msg, src_comp)     \
{                                                           \
    msg.primitiveCode = opcode;                             \
    msg.src_component = src_comp;                           \
    msg.shortmsg = short_msg;                               \
    msg.payload = NULL;                                     \
    msg.payload_length = 0;                                 \
}

#define msgL_allocate(o,i,s,l,p)        _msgL_allocate(__FILE__, __LINE__,o,s,l,p)
#define msg_release(msg)                if (msg.payload != NULL) pw_free(msg.payload)
#define aom_msgQ_create(queue_id)
#define aom_msgQ_send(queue_id, msg)  msgQ_send(queue_id, msg)
#define aom_msgQ_recv(queue_id, msg)     _msgQ_recv(__FILE__, __LINE__, queue_id, msg, FALSE)

#define aom_task_delay(delay)                   usleep(delay)
#define aom_task_create(task_id, entry, nouse)  thread_create(task_id, entry)
#define aom_task_create_ex(task_id, entry, nouse, arg)  thread_create_ex(task_id, entry, arg)

#endif//_OS_WRAPPER_H_

/** @} */ // end of group OSWrapper

