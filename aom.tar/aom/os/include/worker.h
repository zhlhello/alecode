/*-----------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         worker.h

   DATED:          2003/07/01

   AUTHOR:         N. Bertin

   DESCRIPTION:    worker interface

   SccsId=         @(#)worker.h	1.7  04/06/11

   HISTORY:

      - creation   2003/07/01

-----------------------------------------------------------------------------*/
#ifndef _WORKER_H_
#define _WORKER_H_



/*-----------------------------------------------------------------------------
  maximum number of callbacks registered

   1 phymngt
   2 timerbox
   3 date
   4 drvlcd_A
   5 headset_presence
   6 headset_evt_line
   7 icon
   8 timevt popupbox
   9 timevt popupbox
  10 timevt popupbox
  11 timevt popupbox
  12 timevt dialogbox
  13 timevt dialogbox
  14 timevt dialogbox
  15 timevt dialogbox
  16 timevt dialogbox
  17 timevt dialogbox
  18 timevt dialogbox
  19 timevt dialogbox
  20 netlog           XTSce99040
  21

add 3 callback for T1 and T2 and remoteopen timer in IME manager
  ---------------------------------------------------------------------------*/
#ifndef FEATURE_IME
#define MAX_WORKER_CALLBACKS   21
#else
#define MAX_WORKER_CALLBACKS   24
#endif  /* FEATURE_IME */


// XTSce27667+
/*-----------------------------------------------------------------------------
  valeur proposee pour indiquer le fait de ne pas etre enregistre

  homogene a un worker_id, peut etre retournee par worker_register.
  ---------------------------------------------------------------------------*/
#define WORKER_NOT_REGISTERED     (-1)

// XTSce27667-

/*-----------------------------------------------------------------------------
  worker callbacks type definition
  ---------------------------------------------------------------------------*/
typedef void (*worker_callback_t)(void *data);



/*-----------------------------------------------------------------------------
  the specified callback is registered to the worker thread only if an empty
  room is found (MAX_WORKER_CALLBACKS)

  The worker id returned to the caller must be passed to the worker_execute()
  routine (see below)

  If WORKER_NOT_REGISTERED is returned, there was an error while registering
  the callback

  ---------------------------------------------------------------------------*/
#define worker_register(f, d) __worker_register(f, d, __FUNCTION__, __LINE__)
extern int __worker_register(worker_callback_t f, void *data, const char *func, int line);



/*-----------------------------------------------------------------------------
  the specified callback is unregistered from the worker only if it is found
  in the callbacks list
  ---------------------------------------------------------------------------*/
extern void worker_unregister(int id);



/*-----------------------------------------------------------------------------
  instruct the worker thread to execute the routine previously registered
  ---------------------------------------------------------------------------*/
extern void worker_execute(int id);



/*-----------------------------------------------------------------------------
  worker task initialization
  ---------------------------------------------------------------------------*/
extern void init_worker(void);



#endif /* _WORKER_H_ */
