/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#ifndef _NOEOS_TIMER_H_
#define _NOEOS_TIMER_H_


typedef enum timer_id_e
{
    TIMER_ID_ua_udp_rexmit          ,
    TIMER_ID_ua_udp_link_wd         ,
    TIMER_ID_mgr                    ,
//  TIMER_ID_aom_rts_failed         ,
    TIMER_ID_ticker                 ,
//  TIMER_ID_dos                    ,
//  TIMER_ID_arp_spoofing           ,
    TIMER_ID_mmi                    ,
//  TIMER_ID_netlog_read            ,
//  TIMER_ID_headset                ,
    TIMER_ID_keyb_hook              ,
    TIMER_ID_keyb_press             ,
#if defined(KEYBOARD_MINIKBD)
//  TIMER_ID_keyb_minikbd           ,
#endif
    TIMER_ID_remoteopen             ,
//  TIMER_ID_bt_stack               ,
//  TIMER_ID_bt_oor                 ,
//  TIMER_ID_bth_watchdog           ,
//  TIMER_ID_keep_talk_check_rtcp   ,
//  TIMER_ID_keep_talk_real_reset   ,
//  TIMER_ID_keep_talk_get_lcd_data ,
//  TIMER_ID_LED                    ,
//  TIMER_ID_SYSTEM_LED             ,//crms00462528 Yang.FU  
//  TIMER_ID_display,
    TIMER_ID_ua_rtp_monitor         ,//CR8018NOE-472 xiaoguay
    TIMER_ID_MAX
} timer_id_t;


typedef void         timer_func_t(void);
typedef int          duration_t;

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_create

  DESCRIPTION
        creates the specified timer

        - the timer is activated after it is created if the enable parameter
	  value is TRUE.
          Otherwise (FALSE), the timer is not activated (noe_timer_start)

        - initial and repeat parameters are expressed in milliseconds.
          initial specifies the time before first expiration.

	- repeat specifies the time for every expirations after the first
	  expiration.
          if this parameter is zero, the timer only expires once (one-shot)

  INPUT
        timer_id_t    id      , timer identifier
	duration_t    initial ,
	duration_t    repeat  ,
	timer_func_t  callback,
	bool_t        enable  ,

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
extern void
_noe_timer_create(const char *filename, int linenum,
		  timer_id_t   id,
		  duration_t   initial,
		  duration_t   repeat,
		  timer_func_t callback,
		  bool_t       enable);



/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_delete

  DESCRIPTION
        deletes the specified timer

  INPUT
        timer_id_t id, timer identifer

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
extern void
_noe_timer_delete(const char *filename, int linenum,
		  timer_id_t id);

extern void noe_timer_clearall(void);

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_reset

  DESCRIPTION
        changes parameters of the specified timer

        see noe_timer_create()

  INPUT
        timer_id_t    id      , timer identifier
	duration_t    initial ,
	duration_t    repeat  ,
	timer_func_t  callback,
	bool_t        enable  ,

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
extern void
_noe_timer_reset(const char *filename, int linenum,
		 timer_id_t   id,
		 duration_t   initial,
		 duration_t   repeat,
		 timer_func_t callback,
		 bool_t       enable);



/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_start

  DESCRIPTION
        starts the specified timer

  INPUT
        timer_id_t id, timer identifier

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
extern void
_noe_timer_start(const char *filename, int linenum,
		 timer_id_t id);



/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_stop

  DESCRIPTION
        stops the specified timer

  INPUT
        timer_id_t id, timer identifier

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
extern void
_noe_timer_stop(const char *filename, int linenum,
		timer_id_t id);

#ifdef __cplusplus
}
#endif

#define noe_timer_create(id,initial,repeat,callback,enable) \
       _noe_timer_create(__FILE__, __LINE__, id,initial,repeat,callback,enable)

#define noe_timer_delete(id) \
       _noe_timer_delete(__FILE__, __LINE__, id)

#define noe_timer_reset(id,initial,repeat,callback,enable) \
       _noe_timer_reset(__FILE__, __LINE__, id,initial,repeat,callback,enable)

#define noe_timer_start(id) \
       _noe_timer_start(__FILE__, __LINE__, id)

#define noe_timer_stop(id) \
       _noe_timer_stop(__FILE__, __LINE__, id)


#endif	//_NOEOS_TIMER_H_

