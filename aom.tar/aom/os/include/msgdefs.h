/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
  
#ifndef _MSGDEFS_H_
#define _MSGDEFS_H_


/*-----------------------------------------------------------------------------

  message opcode  : 16 bits (uint16_t)
  module increment: 0x100 = 256 messages/module -> 256 modules max.

  pour le debug, penser a mettre a jour ../mod/noeos/noeos_dbg.c

  WARNING first message after conditionnal compilation (after #if and #endif) MUST have fixed value

  ---------------------------------------------------------------------------*/
typedef enum
{
    MSG_BASE_MGR               = 0x4200,
    MSG_reset_hard_request             ,
    MSG_reset_soft_request             ,
    
    MSG_BASE_COMMAND            = 0x4C00,
    MSG_request_thread_exit       ,
    MSG_request_screen_upg       ,
    MSG_request_pageicon_upg       ,
    MSG_request_keyInfo_upg       ,
    MSG_request_screensaver,
    MSG_request_skin_reload,
    MSG_request_id_info,
    
    MSG_BASE_EVENT             = 0x8000,
    MSG_event_key                      , // keys.h
    MSG_event_drv_keyb            , // drvkeyb.h
    MSG_worker_execute            ,

    MSG_BASE_TIMER             = 0x8100,
    MSG_timer_timeout                  , // timer_wrapper.h
    
    MSG_BASE_MAX               = 0xffff

} msg_opcode_t;

#ifdef __cplusplus
extern "C" {
#endif

// declaration of opcode to string
extern char *opcode2name(uint16_t opcode);

#ifdef __cplusplus
}
#endif

#endif /* _MSGDEFS_H_ */

