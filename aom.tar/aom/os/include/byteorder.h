/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         byteorder.h
 
   DATED:          2002/11/26
 
   AUTHOR:         N. Bertin
 
   DESCRIPTION:    endianness

   SccsId=         @(#)byteorder.h	1.8  03/06/10

   HISTORY: 

      - creation   2002/11/26

-----------------------------------------------------------------------------*/
#ifndef _BYTEORDER_H_
#define _BYTEORDER_H_

#if defined(HOST)
#include <endian.h>
#endif

/*-----------------------------------------------------------------------------
  
  get32() and get16() functions takes a memory area and an offset into the
  area. At this offset, 32bits or 16bits will be read and returned in  the
  target hardware byte order.
  
  ---------------------------------------------------------------------------*/
extern uint32_t get32(uint8_t *ptr, uint32_t off);
extern uint16_t get16(uint8_t *ptr, uint32_t off);
extern uint8_t  get8 (uint8_t *ptr, uint32_t off);


/*-----------------------------------------------------------------------------
 
  put32() and put16() functions takes a memory area and an offset into the
  area. At this offset, 32bits or 16bits will be written in  network  byte
  order.

  ---------------------------------------------------------------------------*/
extern void put32 (uint8_t *ptr, uint32_t off, uint32_t val);
extern void put16 (uint8_t *ptr, uint32_t off, uint16_t val);
extern void put8  (uint8_t *ptr, uint32_t off, uint8_t  val);
extern void putPtr(uint8_t *ptr, uint32_t off, void*  val);


/*-----------------------------------------------------------------------------
  
  putstring() function writes a string out to memory.

  ---------------------------------------------------------------------------*/
extern void *putstring(uint8_t *dst, uint32_t off, uint8_t *src, uint32_t len);


/*-----------------------------------------------------------------------------
  
  getstring() function reads a string of specified length from memory.

  ---------------------------------------------------------------------------*/
extern void *getstring(uint8_t *src, uint32_t off, uint8_t *dst, uint32_t len);


/*-----------------------------------------------------------------------------
  
  swap32() and swap16() functions swap 4 bytes of a 32bits number or 2  bytes
  of 16bits number. Note that these functions work on  both  Big  Endian  and
  Little Endian architectures. On Big Endian architectures this function will
  not change the byte ordering.
  
  ---------------------------------------------------------------------------*/
#if (BYTE_ORDER == LITTLE_ENDIAN)
extern uint32_t swap32(uint32_t n);
extern uint16_t swap16(uint16_t n);
#else
#define  swap32(n) (n)
#define  swap16(n) (n)
#endif

#endif /* _BYTEORDER_H_ */
