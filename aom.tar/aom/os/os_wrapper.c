/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

/*------------------------------------------------------------------
 * System includes
 *------------------------------------------------------------------*/
#define _GNU_SOURCE
#include <features.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/errno.h>
#include <time.h>
#include <stdlib.h>

#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/syscall.h>

#include <stdio.h>
#include <string.h>

/*------------------------------------------------------------------
 * Module includes
 *------------------------------------------------------------------*/

#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"
#include "mem_wrapper.h"
#include "ipcConstants.h"

/** @defgroup group3 OSWrapper
 *  This is the group of OS Wrapper Layer
 *  @{
 */

/*------------------------------------------------------------------
 * Module Macro and Type definitions
 * Module Variables Definitions
 *------------------------------------------------------------------*/

/*!
 * \def UNDEF
 *    Define an unvalid value for thread and message queue.
 */
#define UNDEF        0
#define TASK_LOG_ENABLE 0

/*-------------------------------------------------------------------
  Threads
  -------------------------------------------------------------------*/

/*!
 * \def OSTYPE_THREAD
 *    Define pthread_t as OSTYPE_THREAD.
 */
#define OSTYPE_THREAD  pthread_t

/*!
 *  \brief This is a thread structure.
 */
typedef struct
{
    const char    *name     ;   //!< thread name
    int           priority  ;   //!< thread priority : 99 <-> highest, 1 <-> lowest in Linux

    OSTYPE_THREAD id        ;   //!< thread id
    thread_entry_t *entryPoint; //!< thread entry point function
    bool_t 	is_running		;	//!< thread status
    pid_t	thread_tid		;	//!< thread unique TID, refer to 'man gettid'

} map_thread_t;

/*!
 * \brief A global variable to save the list of all threads name and priority
 */
#define MAP_THREADS
#define DECL_NORMAL(name) { #name	, 0, UNDEF, NULL, FALSE, 0 }
static map_thread_t thread_array[THREAD_ID_MAX]=
{
	DECL_THREADS()
};
#undef DECL_NORMAL
#undef MAP_THREADS

/*------------------------------------------------------------------
  Queues
  ------------------------------------------------------------------*/

/*!
 * \def OSTYPE_MSGQ
 *  Define int as OSTYPE_MSGQ
 */
#define OSTYPE_MSGQ  int

/*!
 *  \brief This is a queue structure.
 */
typedef struct
{
    const char   *name  ;   //!< Name of Queue
    OSTYPE_MSGQ  id     ;   //!< Queue id
} map_queue_t;

/*!
 * \brief A global value to save system message Queue ID
 */
static volatile OSTYPE_MSGQ msgQ_id = -1; // volatile because shared between all threads, but volatile is not enough and static is really important on host! (don't know why. ph)

#ifdef MSGQ_CHECK
int Qid_array[QUEUE_ID_MAX] = {0};
#endif

/*!
 * \brief A global variable to save the list of message Queue name and ID
 */
#define MAP_MSGQUES
#define DECL_NORMAL(name) { #name	, QUEUE_ID_##name }
static map_queue_t msgQ_array[QUEUE_ID_MAX]=
{
	DECL_MSGQUES()
};
#undef DECL_NORMAL
#undef MAP_MSGQUES

/*------------------------------------------------------------------
  Semaphores
  ------------------------------------------------------------------*/

/*!
 * \def OSTYPE_SEM
 *  Define sem_t pointer as OSTYPE_SEM
 */
#define OSTYPE_SEM  sem_t *

/*!
 *  \brief This is a semaphore structure.
 */
typedef struct
{
    const char   *name  ;   //!< Name of Semaphore
    OSTYPE_SEM   id     ;   //!< Semaphore id
} map_sem_t;

/*!
 * \brief A global variable to save the list of semaphore name and ID
 */
static sem_t semaphore[SEM_ID_MAX];

/*!
 * \brief A global variable to save the list of semaphore name and ID
 */
static map_sem_t sem_array[SEM_ID_MAX]=
{
    { "user"        , UNDEF },
    { "objmgr"      , UNDEF }
};

/*------------------------------------------------------------------
 * Module Internal functions Definitions
 *------------------------------------------------------------------*/

/*!
 * \brief Set Thread Priority
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param pattr     : thread attribute
 * \param priority  : thread priority : 99 <-> highest, 1 <-> lowest in Linux
 *
 * \return int
 *          - positive  : successful
 *          - others    : failure
 */
static int set_thread_priority( const char *filename, int linenum,
    pthread_attr_t *pattr,
    int priority
)
{
    struct sched_param sched;
    int rs;
    int newpriority = 0;
    //int oldpriority;

    rs = pthread_attr_getschedparam( pattr, &sched );
    if (rs!=0) {
        LOGE("pthread_attr_getschedparam failed" );
        return -1;
    }

    //oldpriority = sched.__sched_priority;
    sched.__sched_priority = priority;

    rs = pthread_attr_setschedparam( pattr, &sched );
    if (rs!=0) {
        LOGE("pthread_attr_setschedparam failedv" );
        return -2;
    }

    rs = pthread_attr_getschedparam( pattr, &sched );
    if (rs!=0) {
        LOGE("pthread_attr_getschedparam failed" );
        return -3;
    }
    newpriority = sched.__sched_priority;

    return newpriority;
}


/*------------------------------------------------------------------
 * Module External functions Definitions
 *------------------------------------------------------------------*/

/*!
 * \brief OS Wrapper Layer Initialzation
 * Create one general system message queue and enable thread cancelable
 *
 * \return int
 *          - 0     : successful
 *          - others: failure
 */
int oswrapper_init(void)
{
    /* message queue creation */

    int msgQid;

    msgQid = msgget(IPC_QUEUE_NOEMMI, (IPC_CREAT|0666));
    if (msgQid < 0) {
           LOGE("Message Queue creation failed" );
           return -1;
    }

    /* Save it into global variable */
    msgQ_id = msgQid;

    /* thread attribute */

    int state, oldstate;

    state = PTHREAD_CANCEL_ENABLE;
    if ( 0 != pthread_setcancelstate(state, &oldstate) )
    {
        LOGE("thread setcancelstate failed" );
    }

    return 0;
}

/*!
 * \brief OS Wrapper Layer Termination
 * The general system message queue will be deleted.
 */
void oswrapper_term(void)
{
    /* message queue deletion */
    if (-1 != msgQ_id)
    {
        if ( 0 != msgctl(msgQ_id, IPC_RMID, NULL) )
        {
            LOGE("message queue delete failed" );
        }
        msgQ_id = -1;
    }

    return;
}

/*!
 * \brief initialize and activate a thread
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Thread ID
 * \param entry     : Thread Entry Point Function
 *
 * \return int
 *          - 0     : successful
 *          - others: failure
 */
int _thread_create(const char *filename, int linenum,
         thread_id_t id, thread_entry_t entry, void* arg)
{
    int r;
    pthread_attr_t attr;
    int rs;

    rs = pthread_attr_init( &attr );
    if (rs!=0) {
        LOGE("pthread_attr_init failed" );
        return -1;
    }

    rs = pthread_attr_setschedpolicy(&attr, SCHED_FIFO);
    if (rs != 0) {
        LOGE("pthread_attr_setschedpolicy failed");

        rs = pthread_attr_destroy(&attr);
        if (rs != 0)
        {
           LOGE("pthread attribute destroy failed");
        }
        return -1;
    }

    if (thread_array[id].priority > 0){
        set_thread_priority( filename, linenum, &attr, thread_array[id].priority );
    }

    rs = pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_DETACHED);//Set thread as detached, never be joined. Yang.FU+
    if (rs!=0) {
        LOGE("pthread_attr_setdetachstate() failed");
    }

    thread_set_status(id, THREAD_IS_RUNNING);
    r = pthread_create((pthread_t *)&thread_array[id].id,
               &attr,
               (void *(*)(void *))entry,
               arg);
    if (r != 0)
    {
        thread_set_status(id, THREAD_IS_CLOSED);
        LOGE("thread creation failed" );
    }
    else{
        thread_array[id].entryPoint = entry;
    }

    rs = pthread_attr_destroy( &attr );
    if (rs!=0) {
        LOGE("pthread attribute destroy failed" );
    }

#ifdef TASK_LOG_ENABLE
    LOGE("Thread %s created.", thread_array[id].name );
#endif
    pthread_setname_np(thread_array[id].id, thread_array[id].name);

    return 0;
}

/*!
 * \brief inquiry thread status
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Thread ID
 *
 * \return thread_status_t
 *          - 0     : THREAD_IS_CLOSED.
 *          - 1		: THREAD_IS_RUNNING.
 */
thread_status_t _thread_get_status(const char *filename, int linenum,
		thread_id_t id)
{
	if (id < THREAD_ID_MAX){
		return thread_array[id].is_running;
	}
	else{
	       LOGE("thread_get_status(): invalid id=%d", id );
		return 0;
	}
}


void request_all_threads_exit(void)
{
	msg_t msg;
	thread_id_t thread_id;
	msgQ_id_t msgq_id;
	for (thread_id = 0; thread_id < THREAD_ID_MAX; thread_id++ )
	{
		if ( thread_array[thread_id].is_running )
		{
			for (msgq_id=0; msgq_id<QUEUE_ID_MAX; msgq_id++){
				if (0==strncmp(msgQ_array[msgq_id].name, thread_array[thread_id].name, 4)){
					break;
				}
			}

			if (msgq_id < QUEUE_ID_MAX){
				LOGW("request thread exit: %s", thread_array[thread_id].name );
				msgS_allocate(msg, MSG_request_thread_exit, TRUE, eCOMPONENT_UNKNOWN);
				aom_msgQ_send(msgq_id, msg);
			}
			else{
				LOGE("can't find msgQ for thread: %s", thread_array[thread_id].name );
			}
		}
	}

	return;
}

bool_t check_if_all_threads_exited(void)
{
	thread_id_t id;
	for (id = 0; id < THREAD_ID_MAX; id++ )
	{
		if ( thread_array[id].is_running )
			return FALSE;
	}

	return TRUE;
}

void printf_all_alive_threads(void)
{
	thread_id_t id;
	for (id = 0; id < THREAD_ID_MAX; id++ )
	{
		if ( thread_array[id].is_running ){
		    LOGW("Thread %s still alive!", thread_array[id].name );
		}
	}

	return;
}

/*!
 * \brief save thread status
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Thread ID
 * \param status	: Stopped or Running.
 *
 * \return bool_t
 *          - 0     : Stopped.
 *          - others: Running.
 */
thread_status_t _thread_set_status(const char *filename, int linenum,
		thread_id_t id, thread_status_t status)
{
	if (id < THREAD_ID_MAX){
		thread_array[id].is_running = status;
	}
	else{
	       LOGE("thread_set_status(): invalid id=%d", id );
	}
	return thread_array[id].is_running;
}

/*!
 * \brief Inquiry the thread Unique TID. Must be called in thread internal context.
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Thread ID
 *
 * \return void
 */
void _thread_set_tid(const char *filename, int linenum,
		thread_id_t id)
{
	if (id < THREAD_ID_MAX){
		thread_array[id].thread_tid = syscall(SYS_gettid);	//gettid();
	}
	else{
		LOGE("thread_set_tid(): invalid id=%d", id );
	}
	return;
}

#if !defined(DBG_DW_N)
void _thread_get_tid_me(void)
{
    pid_t me;
    thread_id_t id;

    me = syscall(__NR_gettid);
    LOGI("[David] syscall(__NR_gettid)=%d(0x%x).",me,me);

    for(id=0; id<THREAD_ID_MAX; id++) {
        if(thread_array[id].thread_tid == me) {
            LOGI("[David] current thread is: %s.\n",thread_array[id].name);
            break;
        }
    }
    if(id == THREAD_ID_MAX) {
        LOGI("[David] no thread tid.\n");
    }
    return;
}
thread_id_t _thread_get_id(void)
{
    pid_t me;
    thread_id_t id;

    me = syscall(__NR_gettid);

    for(id=0; id<THREAD_ID_MAX; id++) {
        if(thread_array[id].thread_tid == me) {
            break;
        }
    }
    return id; // normal id or max
}
#endif

/*!
 * \brief delete a previously created thread
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Thread ID
 *
 * \return int
 *          - 0 : successful
 *          - others : failure
 */
int _thread_delete(const char *filename, int linenum, thread_id_t id)
{
    int ret = 0;
    pthread_t tid;

    if (id < THREAD_ID_MAX)
    {
        tid = thread_array[id].id;
        if (tid==UNDEF) {
            ret = -1;
        }
        else
        {
            if (0 != pthread_cancel(tid))
            {
                LOGI("thread terminate failed");
                ret = -2;
            }
            thread_set_status(id, THREAD_IS_CLOSED);
            thread_array[id].id = UNDEF;
        }
    }

    return ret;
}


/*!
 * \brief send message to message queue
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : User Message Queue ID
 * \param msg       : A primitive message
 *
 * \return int
 *          - 0       : Success
 *          - others  : Failure
 */
int _msgQ_send(const char *filename, int linenum, msgQ_id_t id, msg_t msg)
{
    struct {
        long  mtype;    /* message type */
        msg_t mtext;    /* message data */
    } themsg;
    long msqid;

    if ((id < 0) || (id >= QUEUE_ID_MAX))
    {
        LOGE("msgQ_send: invalid queue id (%d)", id);
        return -1;
    }
    msqid = msgQ_array[id].id;

    themsg.mtype = msqid; // must be > 0 (= QUEUE_ID_dummy defined)
    themsg.mtext = msg;

    if (0 != msgsnd(msgQ_id, (struct msgbuf *)&themsg, sizeof(msg_t), IPC_NOWAIT))
    {
        LOGE("msgQ_send: msgQ_id=%d name=%s(%d) opcode=%s err=%s(%d)",
            msgQ_id, msgQ_array[id].name, id, opcode2name(msg_opcode(msg)), strerror(errno), errno
        );
        return -2;
    }
    return 0;
}

/*!
 * \brief receive message from message queue
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : User Message Queue ID
 * \param msg       : A primitive message
 * \param nowait    : true if don't want wait
 *
 * \return int
 *          - 0       : Success
 *          - others  : Failure
 */
int _msgQ_recv(const char *filename, int linenum, msgQ_id_t id, msg_t *ptr_msg, bool_t nowait)
{
    int msqid;
    int flags;
    int ret;
    struct {
        long  mtype;    /* message type */
        msg_t mtext;    /* message data */
    } themsg;

    if ((id < 0) || (id >= QUEUE_ID_MAX))
    {
        LOGE("msgQ_recv: invalid queue id (%d)", id);
        return -1;
    }

    flags = 0;
    if (nowait)
        flags |= IPC_NOWAIT;

    msqid = msgQ_array[id].id;

    ret = msgrcv(msgQ_id, (struct msgbuf *)&themsg, sizeof(msg_t), msqid, flags);
    if ((-1 == ret) && (errno != ENOMSG))
    {
        LOGE("msgQ_recv: msgQ_id=%d name=%s(%d) nowait=%d err=%s(%d)",
            msgQ_id, msgQ_array[id].name, id, nowait, strerror(errno), errno
        );
        return -2;
    }

    if (ret > 0)
        *ptr_msg = themsg.mtext;

    if (nowait)
    {
        if (ret > 0)
            return 0; // 0: success! got new message
        else
            return 1; // 1: no new message
    }
    else
    {
        return 0; // 0: success! got new message
    }
}

/*!
 * \brief Allocate a long message with payload
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Semaphore ID
 * \param ini_value : Initial value of this semaphore
 *
 * \return int
 *          - 0     : success
 *          - others: failure
 */
msg_t _msgL_allocate(const char *filename, int linenum,
                            msg_opcode_t        opcode,
                            thread_id_t      	srcid ,
                            uint32_t            data_length,
                            const unsigned char *p_data)
{
    int fail=0;
    msg_t the_message;

    the_message.primitiveCode  = opcode;
    the_message.src_component  = srcid;
    the_message.shortmsg       = 0;
    the_message.payload_length = 0;
    the_message.payload        = NULL;

    if ((data_length > 0) && (p_data != NULL))
    {
    	the_message.payload = pw_malloc(data_length);
        if ( the_message.payload != NULL) {
            pw_memcpy( the_message.payload, (void *)p_data, data_length );
            the_message.payload_length= data_length;
        }
        else {
            fail = -1;
        }
    }
    else if (data_length >0) {
    	fail = -2;
    }
    else {
        fail = -3;
    }

    if (fail != 0) {
        LOGE("_msgL_allocate failure! length=%d, p_data=%p. fail=%d", data_length, p_data, fail );
    }

    return the_message;
}

bool_t is_sem_created(sem_id_t id)
{
    if ((id < 0) || (id >= SEM_ID_MAX))
        return FALSE;
    return (sem_array[id].id != UNDEF);
}

/*!
 * \brief initialize a semaphore
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Semaphore ID
 * \param ini_value : Initial value of this semaphore
 *
 * \return int
 *          - 0     : success
 *          - others: failure
 */
int _sem_create(const char *filename, int linenum,
         sem_id_t id, uint32_t ini_value)
{
    OSTYPE_SEM   sem_id;

    if ((id < 0) || (id >= SEM_ID_MAX))
    {
        LOGE("Semaphore ID out of range" );
        return -1;
    }

    sem_id = sem_array[id].id;
    if ( sem_id != UNDEF ) {
        LOGE("Semaphore already created, can't repeat creating" );
        return -2;
    }

    sem_id = &semaphore[id];
    if ( 0 != sem_init( sem_id, 0, ini_value ) ){
        LOGE("semaphore creation failed" );
        return -3;
    }

    sem_array[id].id = sem_id;

   LOGD("sem_create id=%d", id);

    return 0;
}

/*!
 * \brief delete a semaphore
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Semaphore ID
 *
 * \return int
 *          - 0     : success
 *          - others: failure
 */
int _sem_delete(const char *filename, int linenum, sem_id_t id)
{
    OSTYPE_SEM   sem_id;

    if ((id < 0) || (id >= SEM_ID_MAX))
    {
        LOGE("Semaphore ID out of range" );
        return -1;
    }

    sem_id = sem_array[id].id;
    if ( sem_id == UNDEF ) {
        LOGE("Semaphore no creation, can't delete" );
        return -2;
    }

    if ( 0 != sem_destroy( sem_id ) ){
        LOGE("semaphore deletion failed" );
        sem_array[id].id = UNDEF;
        return -3;
    }

    LOGD("sem del=%d", id);    //crms00248198 Bruce Zhang
    sem_array[id].id = UNDEF;

    return 0;
}

/*!
 * \brief giving a semaphore
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Semaphore ID
 *
 * \return int
 *          - 0     : success
 *          - others: failure
 */
int _sem_give(const char *filename, int linenum,
         sem_id_t id)
{
    OSTYPE_SEM   sem_id;

    if ((id < 0) || (id >= SEM_ID_MAX))
    {
        LOGE("Target semaphore doesn't exist" );
        return -1;
    }

    sem_id = sem_array[id].id;
    if ( sem_id == UNDEF ) {
        LOGE("Target semaphore doesn't initialize" );
        return -2;
    }

    if ( 0 != sem_post( sem_id ) ){
        LOGE("semaphore giving failed" );
        return -3;
    }

    //__syslog( filename, linenum, FLUX_OSWRAP, LOG_DEBUG, "sem_give id=%d", id);

    return 0;
}

/*!
 * \brief waiting for a semaphore
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Semaphore ID
 * \param timeoutms : wait timeout (ms)
 *                      -  0 : sem_trywait  , return immediately
 *                      - <0 : sem_wait     , suspend if no semaphore
 *                      - >0 : sem_timedwait
 *
 * \return int
 *          - 0     : success to get a semaphore
 *          - 1     : timeout
 *          - <0    : failure
 */
int _sem_get(const char *filename, int linenum,
         sem_id_t id, int32_t timeoutms)
{
    OSTYPE_SEM      sem_id;
    int             retVal;
    struct timespec *abstime=NULL;

    if ((id < 0) || (id >= SEM_ID_MAX))
    {
        LOGE("Target semaphore doesn't exist" );
        return -1;
    }

    sem_id = sem_array[id].id;
    if ( sem_id == UNDEF ) {
        LOGE("Target semaphore doesn't initialize" );
        return -2;
    }

    if ( timeoutms == 0 ) {
        if ( 0 == sem_trywait( sem_id ) ){
            LOGD("sem_get: try wait id=%d", id);
            return 0;
        }
        else {
            return -3;
        }
    }
    else if ( timeoutms < 0 ) {
        if ( 0 != sem_wait( sem_id ) ){
            LOGD("sem_wait: semaphore getting failed" );
            return -4;
        }
    }
    else if ( timeoutms > 0 ) {
        struct timespec thetime;
        abstime = &thetime;
        clock_gettime(CLOCK_REALTIME, abstime);
        abstime->tv_sec  += timeoutms / 1000;
        abstime->tv_nsec += 1000000*(timeoutms - (timeoutms / 1000 * 1000));
        if ( abstime->tv_nsec >= 1000000000 ) {
             abstime->tv_sec  += 1;
             abstime->tv_nsec -= 1000000000 ;
        }
        /*
        __syslog( filename, linenum,
                FLUX_OSWRAP, LOG_DEBUG,
                "sem_timedwait: tv_sec=%d, tv_nsec=%d",
                 abstime->tv_sec, abstime->tv_nsec );
                 */

        retVal = sem_timedwait( sem_id, abstime );
        if ((errno == ETIMEDOUT) || (retVal == 0))
        {
            // indicate it is a timeout
            if (retVal==0)
            {
                LOGD("sem_get:  id=%d  got it not time out", id);
                return 0;
            }
            else
            {
                LOGD("sem_get:  id=%d  timeout=%d ms", id, timeoutms);
                return 1;
            }
        }
        else {
            LOGD("sem_timedwait: semaphore getting failed" );
            return -5;
        }
    }

    //__syslog( filename, linenum, FLUX_OSWRAP, LOG_DEBUG, "sem_get id=%d", id);

    return 0;
}

/*!
 * \brief Reset a semaphore
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Semaphore ID
 *
 * \return int
 *          - 0     : success
 *          - others: failure
 */
int _sem_reset(const char *filename, int linenum,
         sem_id_t id)
{
    OSTYPE_SEM   sem_id;
    int          sval;
    int          i;

    if ((id < 0) || (id >= SEM_ID_MAX))
    {
        LOGE("Target semaphore doesn't exist" );
        return -1;
    }

    sem_id = sem_array[id].id;
    if ( sem_id == UNDEF ) {
        LOGE("Target semaphore doesn't initialize" );
        return -2;
    }

    if ( 0 != sem_getvalue( sem_id, &sval ) ){
        LOGE("semaphore getvalue failed" );
        return -3;
    }

    LOGD("sem_reset id=%d, wait=%d", id, sval);

    for ( i = 0; i < sval; i++ ) {
        sem_trywait( sem_id );
    }

    return 0;
}

/*!
 * \brief Get a semaphore value
 *
 * \param filename  : source file name in which this function is called
 * \param linenum   : source file line number in which this function is called
 * \param id        : Semaphore ID
 *
 * \return int
 *          - 0     : success
 *          - others: failure
 */
int _sem_getval(const char *filename, int linenum, sem_id_t id)
{
    OSTYPE_SEM   sem_id;
    int          sval;

    if ((id < 0) || (id >= SEM_ID_MAX))
    {
        LOGE("Target semaphore doesn't exist" );
        return -1;
    }

    sem_id = sem_array[id].id;
    if ( sem_id == UNDEF ) {
        LOGE("Target semaphore doesn't initialize" );
        return -2;
    }

    if ( 0 != sem_getvalue( sem_id, &sval ) ){
        LOGE("semaphore getvalue failed" );
        return -3;
    }

    return sval;
}


/** @} */ // end of group OSWrapper

