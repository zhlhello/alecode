/*-----------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         systime.c

   DATED:          2002/12/12

   AUTHOR:         N. Bertin

   DESCRIPTION:

   HISTORY:

      - creation   2002/12/12

      - 2017/02/20 bertin
        cleanup

-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <time.h>

#include "stdinc.h"

#include "systime.h"


uint32_t get_milliseconds(void)
{
    uint32_t        ms;
    struct timespec abstime;

//2013.06.07, changgzh +  use relative time instead of absolute time, to avoid the problem of change system datetime.
    //clock_gettime(CLOCK_REALTIME, abstime);
    clock_gettime(CLOCK_MONOTONIC, (struct timespec *)&abstime);
//2013.06.07, changgzh -

    ms  = (uint32_t)(abstime.tv_nsec / 1000000);
    ms += (uint32_t)(abstime.tv_sec  * 1000);

    return ms;
}
