/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdint.h>
#include <string.h>

#include "stdinc.h"
#include "byteorder.h"


/*-----------------------------------------------------------------------------
  
  get32() and get16() functions takes a memory area and an offset into the
  area. At this offset, 32bits or 16bits will be read and returned in  the
  target hardware byte order.
  
  ---------------------------------------------------------------------------*/
uint32_t get32(uint8_t *ptr, uint32_t off)
{
    uint8_t *p = (ptr + off);
    return (uint32_t)((p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3]);
}


uint16_t get16(uint8_t *ptr, uint32_t off)
{
    uint8_t *p = (ptr + off);
    return (uint16_t)((p[0] << 8) | p[1]);
}


uint8_t get8(uint8_t *ptr, uint32_t off)
{
    uint8_t *p = (ptr + off);
    return (uint8_t)(p[0]);
}


/*-----------------------------------------------------------------------------
 
  put32() and put16() functions takes a memory area and an offset into the
  area. At this offset, 32bits or 16bits will be written in  network  byte
  order.

  ---------------------------------------------------------------------------*/
void putPtr(uint8_t *ptr, uint32_t off, void* val)
{
    uint8_t *p = (ptr + off);

#ifdef ICT_TARGET
    {
        *p++ = (uint8_t)((uintptr_t)val >> 24);
        *p++ = (uint8_t)((uintptr_t)val >> 16);
        *p++ = (uint8_t)((uintptr_t)val >> 8 );
        *p   = (uint8_t)((uintptr_t)val      );
    }
#else
    {
        *p++ = (uint8_t)((uintptr_t)val >> 56);
        *p++ = (uint8_t)((uintptr_t)val >> 48);
        *p++ = (uint8_t)((uintptr_t)val >> 40);
        *p   = (uint8_t)((uintptr_t)val >> 32);
        *p++ = (uint8_t)((uintptr_t)val >> 24);
        *p++ = (uint8_t)((uintptr_t)val >> 16);
        *p++ = (uint8_t)((uintptr_t)val >> 8 );
        *p   = (uint8_t)((uintptr_t)val      );
    }
#endif
}

void put32(uint8_t *ptr, uint32_t off, uint32_t val)
{
    uint8_t *p = (ptr + off);

    *p++ = (uint8_t)(val >> 24);
    *p++ = (uint8_t)(val >> 16);
    *p++ = (uint8_t)(val >> 8 );
    *p   = (uint8_t)(val      );
}


void put16(uint8_t *ptr, uint32_t off, uint16_t val)
{
    uint8_t *p = (ptr + off);

    *p++ = (uint8_t)(val >> 8);
    *p   = (uint8_t)(val     );
}


void put8(uint8_t *ptr, uint32_t off, uint8_t val)
{
    uint8_t *p = (ptr + off);

    *p   = (uint8_t)(val);
}


/*-----------------------------------------------------------------------------
  
  putstring() function writes a string out to memory.

  ---------------------------------------------------------------------------*/
void *putstring(uint8_t *dst, uint32_t off, uint8_t *src, uint32_t size)
{
    return memcpy((dst + off), src, size);
}


/*-----------------------------------------------------------------------------
  
  getstring() function reads a string of specified length from memory.

  ---------------------------------------------------------------------------*/
void *getstring(uint8_t *src, uint32_t off, uint8_t *dst, uint32_t size)
{
    return memcpy(dst, (src + off), size);
}


/*-----------------------------------------------------------------------------
  
  swap32() and swap16() functions swap 4 bytes of a 32bits number or 2  bytes
  of 16bits number. Note that these functions work on  both  Big  Endian  and
  Little Endian architectures. On Big Endian architectures this function will
  not change the byte ordering.
  
  ---------------------------------------------------------------------------*/
#if (BYTE_ORDER == LITTLE_ENDIAN)
uint32_t swap32(uint32_t n)
{
    uint8_t *p = (uint8_t *)&n;

    return (uint32_t)((p[0] << 24) | (p[1] << 16) | (p[2] << 8) | p[3]);
}
#endif


#if (BYTE_ORDER == LITTLE_ENDIAN)
uint16_t swap16(uint16_t n)
{
    uint8_t *p = (uint8_t *)&n;

    return (uint16_t)((p[0] << 8) | p[1]);
}
#endif
