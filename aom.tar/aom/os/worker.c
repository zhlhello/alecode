/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
  
#include <stdint.h>
#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"

#include "worker.h"


/*-----------------------------------------------------------------------------
  worker callbacks list
  ---------------------------------------------------------------------------*/
static struct
{
    worker_callback_t  f;
    void              *d;
    char              *func;
    int                line;
} worker_callbacks[MAX_WORKER_CALLBACKS];



/*-----------------------------------------------------------------------------
  instruct the worker thread to execute the routine previously registered
  ---------------------------------------------------------------------------*/
void worker_execute(int id)
{
    static uint32_t senderror_count = 0;

    if ((id >= 0) && (id < MAX_WORKER_CALLBACKS))
    {
        if (worker_callbacks[id].f)
        {
            msg_t msg;
            msgS_allocate(msg, MSG_worker_execute, id, THREAD_ID_worker);

            if (senderror_count == 0)
            {
                if (0 != aom_msgQ_send(QUEUE_ID_worker, msg))
                {
                    senderror_count = 1;
                    LOGE("failed to send msg (MSG_worker_execute %d/%s:%d)",
                        id, worker_callbacks[id].func, worker_callbacks[id].line
                    );
                }
            }
            else
            {
                senderror_count++;
                if (senderror_count == 100)
                {
                    LOGE("cleared senderror_count)");
                    senderror_count = 0;
                }
            }
        }
    }
    else
    {
        LOGE((void*)(uintptr_t)id);
    }
}



/*-----------------------------------------------------------------------------
  the specified callback is registered to the worker thread only if an empty
  room is found (MAX_WORKER_CALLBACKS)

  The worker id returned to the caller must be passed to the worker_execute()
  routine (see below)

  If -1 is returned, there was an error while registering the callback

  ---------------------------------------------------------------------------*/
int __worker_register(worker_callback_t f, void *d, const char *func, int line)
{
    if (f != NULL)
    {
        int i;
        for(i = 0 ; (i < MAX_WORKER_CALLBACKS) ; i++)
        {
            if (worker_callbacks[i].f == NULL)
            {
                worker_callbacks[i].d    = d;
                worker_callbacks[i].f    = f;
                worker_callbacks[i].func = (char *)func;
                worker_callbacks[i].line = line;
                return i;
            }
        }
    }
    LOGE("WORKER : failed to register callback (%p/%s:%d)", f, func, line);

    return WORKER_NOT_REGISTERED;
}



/*-----------------------------------------------------------------------------
  the specified callback is unregistered from the worker thread only if it is
  found in the callbacks list
  ---------------------------------------------------------------------------*/
void worker_unregister(int id)
{
    if (id == WORKER_NOT_REGISTERED)
        return;

    if ((id >= 0) && (id < MAX_WORKER_CALLBACKS))
    {
        worker_callbacks[id].f    = NULL;
        worker_callbacks[id].func = NULL;
        worker_callbacks[id].line = 0;
    }
    else
       LOGE((void*)(uintptr_t)id);
}



/*-----------------------------------------------------------------------------
  worker task entry
  ---------------------------------------------------------------------------*/
static void worker_task_entry(void)
{
    thread_set_tid(THREAD_ID_worker);
    for(;;)
    {
        msg_t msg;

        if (0 != aom_msgQ_recv(QUEUE_ID_worker, &msg)){
            break; //For Thread Exit on Exception
        }

        if ( msg_opcode(msg) == MSG_worker_execute )
        {
            uint8_t id = msgS_data(msg);

            if (worker_callbacks[id].f)
                worker_callbacks[id].f(worker_callbacks[id].d);
            else
                LOGD("WORKER : %d not registered (execute)", id) ;
        }
        else if ( msg_opcode(msg) == MSG_reset_soft_request )
        {
            break;
        }
        else if ( msg_opcode(msg) == MSG_request_thread_exit )
        {
            break;
        }
        msg_release(msg);
    }
    LOGE("Thread Worker Exit Gracefully");
    thread_set_status(THREAD_ID_worker, THREAD_IS_CLOSED);
    pthread_exit(NULL);
}



/*-----------------------------------------------------------------------------
  worker thread initialization
  ---------------------------------------------------------------------------*/
void init_worker(void)
{
    int i;

    for(i = 0 ; (i < MAX_WORKER_CALLBACKS) ; i++) {
        worker_callbacks[i].f    = NULL;
        worker_callbacks[i].func = NULL;
        worker_callbacks[i].line = 0;
    }

    aom_msgQ_create(QUEUE_ID_worker);
    aom_task_create(THREAD_ID_worker, worker_task_entry, TRUE);
}
