/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
  
#define _GNU_SOURCE
#include <features.h>
#include "stdinc.h"
#include "stdint.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"
#include "noeos_timer.h"
#include "ticks.h"

#include <unistd.h>
#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/syscall.h>

#define OSTYPE_TIMER  pthread_t
#define OSTYPE_CBACK  timer_func_t *
#define UNDEF         0

typedef enum {
    TIMER_TYPE_NONE = 0, /*!< Dummy ID, Not Used */
    TIMER_TYPE_ONETIME  = 1, /*!< One time Timer */
    TIMER_TYPE_PERIODIC = 2, /*!< Periodic Timer */
    TIMER_TYPE_MAX
} timer_type_t;

typedef enum {
    TIMER_STATUS_IDLE = 0,
    TIMER_STATUS_START,
    TIMER_STATUS_MAX
} noe_timer_status_t;

typedef struct
{
    char          *name       ;
    duration_t     initial    ;
    duration_t     repeat     ;
    bool_t         enable     ;
    OSTYPE_CBACK   callback   ;
#ifdef OLD_TIMER
    OSTYPE_TIMER   id         ;
    bool_t         sleeping   ;	//!< crms00449241, gary.yu@2013.08.13.

    bool_t 	is_running		;	//!< thread status
    pid_t	thread_tid		;	//!< thread unique TID, refer to 'man gettid'
    pthread_cond_t thread_condition; // Thread condition : Enable / Disable the thread without ticking every 10ms
    pthread_mutex_t thread_mutex; // Thread mutex : Used for condition and secure enable flag modifications
#else
    msgQ_id_t    msgQ_id;
    timer_type_t timer_type;    // the type of the timer, can be onetime timer or a periodic timer
    noe_timer_status_t status;
    duration_t  tick_count;
#endif
} noe_timer_t;

static noe_timer_t timer_array[TIMER_ID_MAX]=
{
    { .name="ua_udp_rexmit"             },
    { .name="ua_udp_link_wd"            },
    { .name="mgr"                       },
//  { .name="aom_rts_failed"            },
    { .name="ticker"                    },
//  { .name="dos"                       },
//  { .name="arp_spoofing"              },
    { .name="mmi"                       },
//  { .name="netlog_read"               },
//  { .name="headset"                   },
    { .name="keyb_hook"                 },
    { .name="keyb_press"                },
#if defined(KEYBOARD_MINIKBD)
//  { .name="keyb_minikbd"              },
#endif
    { .name="remoteopen"                },
//  { .name="bt_stack"                  },
//  { .name="bt_oor"                    },
//  { .name="bth_watchdog"              },
//  { .name="keep_talk_check_rtcp"      },
//  { .name="keep_talk_real_reset"      },
//  { .name="keep_talk_get_lcd_data"    },
//  { .name="LED"                       },
//  { .name="SYSTEM_LED"                },//crms00462528 Yang.FU
//  { .name="display"                   }
};

static pthread_mutex_t timer_mutex;

#define SELECT_TIMEOUT_PERIOD (UNIT_TIME_10ms*5)   //the minimum value of timeout period is 10ms 
//#define ENABLE_TIMER_TRACE

static void timer_task_entry(void)
{
    struct timeval period;
    msg_t msg;
    thread_set_tid(THREAD_ID_timer);

    // Fill Message Header
    msg.src_component = THREAD_ID_timer;
    msg.shortmsg = 0;
    msg.payload_length = 0;
    msg.payload = NULL;

    while (TRUE)
    {
        timer_id_t id;
        period.tv_sec = 0;
        period.tv_usec = SELECT_TIMEOUT_PERIOD;

        /* here call select() with all three sets empty and a non-NULL timeout
         * as a fairly portable way to
         * sleep with subsecond precision.
         */
        select(0, NULL, NULL, NULL, &period);

        if (0 != pthread_mutex_lock(&timer_mutex))
        {
            LOGE("Timer Mutex lock fail!");
            break;  // quit thread to avoid too much fatal log
        }

        for(id = 0; id < TIMER_ID_MAX; id++)
        {
            if (timer_array[id].enable && timer_array[id].status == TIMER_STATUS_START)
            {
                timer_array[id].tick_count--;
                #if defined(ENABLE_TIMER_TRACE)
                LOGD(" timer %d tick_count :%d",id,timer_array[id].tick_count);
                #endif
                if (timer_array[id].tick_count <= 0)  // timer is just timeout
                {
                    if (timer_array[id].callback != NULL)
                    {
                        // timer callback function call
                        #if defined(ENABLE_TIMER_TRACE)
                        LOGD(" timer %d callback",id);
                        #endif
                        timer_array[id].callback ();
                    }
                    else if (timer_array[id].msgQ_id < QUEUE_ID_MAX)
                    {
                        msg.primitiveCode = MSG_timer_timeout;
                        msgQ_send(timer_array[id].msgQ_id, msg);
                        #if defined(ENABLE_TIMER_TRACE)
                        LOGD("Send timeout msg to %d",timer_array[id].msgQ_id);
                        #endif

                    }

                    if (timer_array[id].timer_type == TIMER_TYPE_PERIODIC)
                    {
                        // restore tick count if it's a periodic timer
                        if(timer_array[id].repeat != 0)
                            timer_array[id].tick_count = timer_array[id].repeat / SELECT_TIMEOUT_PERIOD;
                        else
                            timer_array[id].tick_count = timer_array[id].initial / SELECT_TIMEOUT_PERIOD;
                    }
                    else
                    {
                        //stop this timer
                        timer_array[id].status = TIMER_STATUS_IDLE;
                    }
                }
            }
        }  // end of while loop of timer queue

        if (0 != pthread_mutex_unlock(&timer_mutex))
        {
            LOGE("Timer Mutex unlock fail!");
            break;  // quit thread to avoid too much fatal log
        }
    }  // end of while loop of select sleep for a timer tick unit

    LOGI("Thread Timer exit gracefully");
    thread_set_status(THREAD_ID_timer, THREAD_IS_CLOSED);
    pthread_exit(NULL);

}

/*-----------------------------------------------------------------------------
 GLOBAL FUNCTIONS DEFINITIONS
Init timer wrapper module
 
 ----------------------------------------------------------------------------*/
void timer_init(void)
{
    if ( 0 != pthread_mutex_init( &timer_mutex, NULL) ) {
        LOGE("Timer Mutex initialization fail!");
    }

    if ( 0 != thread_create( THREAD_ID_timer, timer_task_entry ) ){
        LOGE("Timer thread creation fail!");
    }
    else {
        LOGI("timer thread start.");
    }    
    return;
}

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_create_by_msg

  DESCRIPTION
        creates the specified timer

        - the timer is activated after it is created if the enable parameter
      value is TRUE.
          Otherwise (FALSE), the timer is not activated (noe_timer_start)

        - initial and repeat parameters are expressed in milliseconds.
          initial specifies the time before first expiration.

    - repeat specifies the time for every expirations after the first
      expiration.
          if this parameter is zero, the timer only expires once (one-shot)

  INPUT
        timer_id_t    id      , timer identifier
    duration_t    initial ,
    duration_t    repeat  ,
    msgQ_id_t    msgQ_id,
    bool_t        enable  ,

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
void
_noe_timer_create_by_msg(const char *filename, int linenum,
          timer_id_t   id,
          duration_t   initial,
          duration_t   repeat,
          int  msgQ_id,
          bool_t       enable)
{
    if (timer_array[id].status == TIMER_STATUS_START){
        LOGD("try to create a Timer \"%s\" but is running!", timer_array[id].name );
        return;
    }
    if ( 0 != pthread_mutex_lock(&timer_mutex) ) {
        LOGE("noe_timer_create() fail, because of timer Mutex lock fail. timer_name=%s",
        timer_array[id].name);
        return;
    }
    timer_array[id].initial = initial;
    timer_array[id].repeat  = repeat;
    timer_array[id].enable = enable;
    timer_array[id].msgQ_id = msgQ_id;
    timer_array[id].tick_count = initial / SELECT_TIMEOUT_PERIOD;
    timer_array[id].status = TIMER_STATUS_START;
    if(repeat != 0)
        timer_array[id].timer_type = TIMER_TYPE_PERIODIC;
    if ( 0 != pthread_mutex_unlock(&timer_mutex) ) {
        LOGE("Timer Mutex unlock fail!"); 
    }
    if(thread_get_status(THREAD_ID_timer) == THREAD_IS_CLOSED)
        timer_init();
#if defined(ENABLE_TIMER_TRACE)
    LOGD("Timer %d created, tick_count:%d", id,timer_array[id].tick_count );
#endif    
}

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_create

  DESCRIPTION
        creates the specified timer

        - the timer is activated after it is created if the enable parameter
      value is TRUE.
          Otherwise (FALSE), the timer is not activated (noe_timer_start)

        - initial and repeat parameters are expressed in milliseconds.
          initial specifies the time before first expiration.

    - repeat specifies the time for every expirations after the first
      expiration.
          if this parameter is zero, the timer only expires once (one-shot)

  INPUT
        timer_id_t    id      , timer identifier
    duration_t    initial ,
    duration_t    repeat  ,
    timer_func_t  callback,
    bool_t        enable  ,

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
void
_noe_timer_create(const char *filename, int linenum,
          timer_id_t   id,
          duration_t   initial,
          duration_t   repeat,
          timer_func_t callback,
          bool_t       enable)
{
    if (timer_array[id].status == TIMER_STATUS_START){
        LOGD("try to create a Timer \"%s\" but is running!", timer_array[id].name );
            return;
    }
    if ( 0 != pthread_mutex_lock(&timer_mutex) ) {
        LOGE("noe_timer_create() fail, because of timer Mutex lock fail. timer_name=%s",
        timer_array[id].name);
        return;
    }
    timer_array[id].initial = initial;
    timer_array[id].repeat  = repeat;
    timer_array[id].enable = enable;
    timer_array[id].callback = callback;
    timer_array[id].tick_count = initial / SELECT_TIMEOUT_PERIOD;        
    timer_array[id].status = TIMER_STATUS_START;
    if(repeat != 0)
        timer_array[id].timer_type = TIMER_TYPE_PERIODIC;
    if ( 0 != pthread_mutex_unlock(&timer_mutex) ) {
        LOGE("Timer Mutex unlock fail!"); 
    }
    if(thread_get_status(THREAD_ID_timer) == THREAD_IS_CLOSED)
        timer_init();
#if defined(ENABLE_TIMER_TRACE)    
    LOGI("Timer %d created, tick_count:%d",id,timer_array[id].tick_count );
#endif    
}

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_delete

  DESCRIPTION
        deletes the specified timer

  INPUT
        timer_id_t id, timer identifer

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
void
_noe_timer_delete(const char *filename, int linenum, timer_id_t  id)
{
    if (timer_array[id].status == TIMER_STATUS_IDLE){
        LOGD("try to delete a Timer \"%s\" but is idle!", timer_array[id].name );
            return;
    }
    if ( 0 != pthread_mutex_lock(&timer_mutex) ) {
        LOGE("noe_timer_delete() fail, because of timer Mutex lock fail. timer_name=%s",
        timer_array[id].name);
        return;
    }
    timer_array[id].enable = FALSE;
    timer_array[id].callback = NULL;
    timer_array[id].status = TIMER_STATUS_IDLE;
    if ( 0 != pthread_mutex_unlock(&timer_mutex) ) {
        LOGE("Timer Mutex unlock fail!"); 
    }
#if defined(ENABLE_TIMER_TRACE)    
     LOGE("Timer %d deleted",id);
#endif    
}

void noe_timer_clearall(void)
{
    timer_id_t  id;
    for (id=0; id<TIMER_ID_MAX; id++)
    {
        if (timer_array[id].status != TIMER_STATUS_IDLE){
            noe_timer_delete(id);
            LOGI("noe_timer_clearall(): timer \"%s\" deleted.", timer_array[id].name );
        }
    }   
}

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_start

  DESCRIPTION
        starts the specified timer

  INPUT
        timer_id_t id, timer identifier

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/

void _noe_timer_start(const char *filename, int linenum, timer_id_t id)
{
    if (timer_array[id].status == TIMER_STATUS_IDLE){
         LOGD("try to start a Timer \"%s\" but is idle!", timer_array[id].name );
            return;
    }
    if ( 0 != pthread_mutex_lock(&timer_mutex) ) {
        LOGE("noe_timer_delete() fail, because of timer Mutex lock fail. timer_name=%s",
        timer_array[id].name);
        return;
    }
    timer_array[id].enable = TRUE;
    if ( 0 != pthread_mutex_unlock(&timer_mutex) ) {
        LOGE("Timer Mutex unlock fail!"); 
    }
#if defined(ENABLE_TIMER_TRACE)    
    LOGE("Timer %d startd",id);
#endif    
}

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_stop

  DESCRIPTION
        stops the specified timer.
        !!! Caution: MUST NOT call noe_timer_stop() in the timer callback function. It will cause deadlock!!!

  INPUT
        timer_id_t id, timer identifier

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
void
_noe_timer_stop(const char *filename, int linenum, timer_id_t id)
{
    if (timer_array[id].status == TIMER_STATUS_IDLE){
        LOGD("try to stop a Timer \"%s\" but is idle!", timer_array[id].name );
            return;
    }
    if ( 0 != pthread_mutex_lock(&timer_mutex) ) {
        LOGE("noe_timer_delete() fail, because of timer Mutex lock fail. timer_name=%s",
        timer_array[id].name);
        return;
    }
    timer_array[id].enable = FALSE;
    if ( 0 != pthread_mutex_unlock(&timer_mutex) ) {
        LOGE("Timer Mutex unlock fail!"); 
    }
#if defined(ENABLE_TIMER_TRACE)    
    LOGI("Timer %d stopped",id);
#endif    
}

/*-----------------------------------------------------------------------------

  FUNCTION
        noe_timer_reset

  DESCRIPTION
        changes parameters of the specified timer

        see noe_timer_create()

  INPUT
        timer_id_t    id      , timer identifier
    duration_t    initial ,
    duration_t    repeat  ,
    timer_func_t  callback,
    bool_t        enable  ,

  OUTPUT
        NONE

 ----------------------------------------------------------------------------*/
void
_noe_timer_reset(const char *filename, int linenum,
         timer_id_t   id,
         duration_t   initial,
         duration_t   repeat,
         timer_func_t callback,
         bool_t       enable)
{
     _noe_timer_stop(filename, linenum, id);
    if ( 0 != pthread_mutex_lock(&timer_mutex) ) {
        LOGE("noe_timer_delete() fail, because of timer Mutex lock fail. timer_name=%s",
        timer_array[id].name);
        return;
    }
    timer_array[id].initial  = initial;
    timer_array[id].repeat   = repeat;
    timer_array[id].callback = callback;  
    timer_array[id].enable = enable;
    timer_array[id].status = TIMER_STATUS_START;
    
    if(repeat > 0)
    {
        timer_array[id].timer_type = TIMER_TYPE_PERIODIC;
        timer_array[id].tick_count = repeat / SELECT_TIMEOUT_PERIOD;
    }
    if(initial > 0)
        timer_array[id].tick_count = initial / SELECT_TIMEOUT_PERIOD;

    if ( 0 != pthread_mutex_unlock(&timer_mutex) ) {
        LOGE("Timer Mutex unlock fail!"); 
    }
#if defined(ENABLE_TIMER_TRACE)    
    LOGI("Timer %d resetted",id);
#endif    
}
