/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdint.h>
#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"

#include "systime.h"
#include "ticker.h"
#include "noeos_timer.h"
#include "ticks.h"

static struct
{
    ticker_callback_t  f;
    void              *d;
} ticker_callbacks[MAX_TICKER_CALLBACKS];

static uint32_t ticker_tck = 0;


/*-----------------------------------------------------------------------------
  ticker timer handler
  ---------------------------------------------------------------------------*/
static void ticker_timer_handler(void)
{
    uint32_t ms = get_milliseconds();
    uint32_t i;
    
    for(i = 0 ; (i < MAX_TICKER_CALLBACKS) ; i++)
    {
        if (ticker_callbacks[i].f != NULL)
            ticker_callbacks[i].f(ms, ticker_tck, ticker_callbacks[i].d);
    }
 
    ticker_tck++;
}



/*-----------------------------------------------------------------------------
  the specified callback is registered to the ticker only if an empty room
  is found (MAX_TICKER_CALLBACKS)
  ---------------------------------------------------------------------------*/
int ticker_register(ticker_callback_t f, void *d)
{
    int i;

    if (f == NULL)
    {
        LOGE("register callback is NULL");
        return TICKER_NOT_REGISTERED;
    }

    for(i = 0 ; (i < MAX_TICKER_CALLBACKS) ; i++)
    {
        if (ticker_callbacks[i].f == NULL)
        {
            ticker_callbacks[i].d = d;
            ticker_callbacks[i].f = f;
            return i;
        }
    }

    LOGD("TICKER : failed to register callback (%p)", f);

    return TICKER_NOT_REGISTERED;
}



/*-----------------------------------------------------------------------------
  the specified callback is unregistered from the ticker only if it is found
  in the callbacks list
  ---------------------------------------------------------------------------*/
void ticker_unregister(int id)
{
    if (id == TICKER_NOT_REGISTERED) return;

    if ((id >= 0) && (id < MAX_TICKER_CALLBACKS))
    {
        ticker_callbacks[id].f = NULL;
    }
    else
    {
        LOGE("ticker id is invalid");
    }
}



/*-----------------------------------------------------------------------------
  ticker timer initialization
  ---------------------------------------------------------------------------*/
void init_ticker(void)
{
    int i;

    for(i = 0 ; (i < MAX_TICKER_CALLBACKS) ; i++)
        ticker_callbacks[i].f = NULL;

    ticker_tck = 0;

    noe_timer_create(TIMER_ID_ticker     ,
                     TICKER_TIMEOUT      ,
                     TICKER_TIMEOUT      ,
                     ticker_timer_handler, TRUE);
}
