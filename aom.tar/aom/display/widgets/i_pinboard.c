/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         w_pinboard.c
 
   AUTHOR:         P. Hanser
 
   DESCRIPTION:    pinboard widget

   SccsId=         @(#)i_pinboard.c	1.11  04/07/30

   HISTORY: 

      - 2003/06/16  creation

-----------------------------------------------------------------------------*/

#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"

#include "display.h"
#include "../disp_priv.h"



registerItem *disp_w_pinboard(NGWinstance *ctnr, const char *comment)
{
    NGWinstance  *widget;
    registerItem *rI    = (registerItem *)pw_malloc(sizeof(registerItem));
    
    if(rI == NULL)
    {
        LOGE("pw_malloc failed");
        return NULL;
    }

    widget = ngwCreate(global_w_ctx, "NGWalcPinboard", ctnr);
    if (NULL == widget)
    {
        LOGE("ngwCreate(pinboard)");
        return NULL;
    }

    disp_i_setprop(
        widget, NGWP_MOTIF_BORDER, (NGWPdata)""
        );
    disp_i_setprop(
        widget, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_BACKGROUND
        );

    rI->objId    = widget;
    rI->type     = DISP_TYPE_PINBOARD;

    return rI;
}

