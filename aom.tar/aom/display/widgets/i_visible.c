/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include "stdinc.h"
#include "log.h"

#include "display.h"
#include "../disp_priv.h"
#include "objmgr.h"

#if defined(DISPLAY)

#include <ngos.h>


bool_t disp_i_ngGetVisible(NGWinstance *widget)
{
    NGWPdata     hidden;
    NGWinstance *parent;
            
    for (hidden = FALSE ;
         !hidden && NULL != (parent = ngwGetParent(widget)) ;
         widget = parent)
    {
        ngwGetProp(widget, NGWP_HIDDEN, &hidden);
    }

    if (!hidden && ngwInstanciates(widget, "NGWwindow"))
    {
        ngwGetProp(widget, NGWP_HIDDEN, &hidden);
    }
    else
    {
        hidden = TRUE;
    }
    
    return (bool_t)!hidden;
}

#endif

