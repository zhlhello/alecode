/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include "stdinc.h"
#include "log.h"
#include "objmgr.h"

#include "display.h"
#include "../disp_priv.h"

#include <stdio.h>

void __disp_i_setprop(const char  *file  , int line,
                      NGWinstance *widget, NGWpropId pid, NGWPdata data)
{
    int result;

    if (widget)
    {
       result = ngwSetProp(widget, pid, data);
       if (NG_EOK != result)
       {
           char msg[64];

           sprintf(msg, "ngwSetProp(%d, 0x%x) = %d",
                   (int)pid, (unsigned int)data, result);

           LOGE("%s", msg);
       }
    }
    else
    {
           LOGE("disp_i_setprop: null widget");
    }
}



void __disp_i_getprop(const char  *file  , int line,
                      NGWinstance *widget, NGWpropId pid, NGWPdata *data)
{
    int result;

    if (widget)
    {
       result = ngwGetProp(widget, pid, data);
       if (NG_EOK != result)
       {
           char msg[64];

           sprintf(msg, "ngwGetProp(%d, %p) = %d",
                   (int)pid, data, result);

           LOGE("%s", msg);
       }
    }
    else
    {
           LOGE("disp_i_setprop: null widget");
    }
}
