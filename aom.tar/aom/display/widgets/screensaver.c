/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/11/29 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdlib.h>
#include <unistd.h>

#include "stdinc.h"
#include "syslog.h"
#include "primitive.h"
#include "os_wrapper.h"
#include "timevt.h"

#include "configs.h"
//XTScf01037

#include "display.h"
#include "../disp_priv.h"

#include "screensaver.h"
#include "backlight.h"

#include "skins.h"
#include "i_skins.h"

#include "log.h"

#define SCREENSAVER_NO_DISPLAY                   1    //according to PLM suggestion, AOM screensaver just turn off backlight
/*-----------------------------------------------------------------------------
  variables privees
  ---------------------------------------------------------------------------*/
static uint32_t         refresh_timeout;
static registerItem   *background_fbox  = NULL;
static registerItem   *foreground_fbox  = NULL;
static registerItem   *moving_fbox      = NULL;
static int              refresh_id       = -1;
static bool_t           scrn_active      = FALSE;
static uint8_t       bl_level_record;

extern NGWinstance          *disppinboard_mainscreen;
/*-----------------------------------------------------------------------------
  retourne TRUE si le screensaver est actif
  ---------------------------------------------------------------------------*/
bool_t screensaver_is_active(void)
{
    return scrn_active;
}



/*-----------------------------------------------------------------------------
  screensaver par defaut (RELEASED_VERSION)
  ---------------------------------------------------------------------------*/
typedef enum
{
    GO_DOWN,
    GO_UP
} scrnsaver_dir_t;

static scrnsaver_dir_t direction = GO_DOWN;

/*-----------------------------------------------------------------------------
  changement de la couleur de fond d'un widget
  ---------------------------------------------------------------------------*/
void disp_i_setWidgetBackground(registerItem *item,
                                NGWinstance  *widget,
                                uint8_t background)
{
    NGWpalette   *palOld;
    NGGcolor     *color;

    if (NULL == widget)
    {
        widget = item->objId;
    }

    // a t'on deja joue au jeu de la palette avec ce widget ?
    if (item->palette.colors == NULL)
    {
        // non: on cree une nouvelle palette
        ngwGetProp(widget, NGWP_PALETTE, (NGWPdata*)&palOld);

        item->palette.colors =
            (NGGcolor const *)pw_malloc(palOld->size * sizeof(NGGcolor));

        item->palette.size = palOld->size;

        memcpy( (NGGcolor *)item->palette.colors,
                 palOld->colors,
                 sizeof( NGGcolor) * palOld->size);
    }

    color = (NGGcolor *)item->palette.colors+NGWC_MOTIF_3DBACKGROUND;

    switch(background)
    {
    default:
    case COLOR_WHITE    :    *color = NGG_COLOR_WHITE    ; break;
    case COLOR_LIGHTGREY:    *color = NGG_COLOR_GRAY_xC  ; break;
    case COLOR_GREY     :    *color = NGG_COLOR_GRAY_x8  ; break;
    case COLOR_BLACK    :    *color = NGG_COLOR_BLACK    ; break;
    }

    disp_i_setprop(
        widget, NGWP_PALETTE, (NGWPdata)&(item->palette)
        );
    if (!ngwInstanciates(widget, "NGWscrollCt") &&
        !ngwInstanciates(widget, "NGWalcScrollCt")  &&
        !ngwInstanciates(widget, "NGWalcEntry"))
    { 
        disp_i_setprop(
            widget, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_BACKGROUND
            );
    }
}

/*-----------------------------------------------------------------------------
  deplacement de la homebar du haut vers le bas et inversement
  ---------------------------------------------------------------------------*/
static void screensaver_default(void)
{
    NGWinstance *widget ;
    NGGpoint     pos    ;
    NGGsize      siz    ;

//XTSce63429+
    // if screensaver is disabled, do not try to move it
    if (moving_fbox == NULL)
        return;
//XTSce63429-

    widget = moving_fbox->objId;

    disp_i_getprop(widget, NGWP_POSITION, (NGWPdata *)&pos);
    disp_i_getprop(widget, NGWP_SIZE    , (NGWPdata *)&siz);

    if (direction == GO_DOWN)
    {
        if (pos.y + siz.h == disp_size.h)
        {
            direction = GO_UP;
            pos.y--;
        }
        else
        {
            pos.y++;
        }
    }
    else
    {
        if (pos.y == 0)
        {
            direction = GO_DOWN;
            pos.y++;
        }
        else
        {
            pos.y--;
        }
    }

    disp_i_setprop(widget, NGWP_POSITION, (NGWPdata)&pos);
}



/*-----------------------------------------------------------------------------
  mise a jour du screensaver
  ---------------------------------------------------------------------------*/
static void screensaver_refresh(void *data)
{
    TIMING_VARIABLES
    ngwBegin(global_w_ctx);

    if (refresh_id != -1)
    {
       screensaver_default();
       timevt_restart(refresh_id, refresh_timeout);
    }

    TIMING_START
    ngwEnd(global_w_ctx);
    TIMING_END("ngwEnd")
}


static void on_skins_reload(registerItem *item)
{
    __set_background_image(item->objId, skins_get_image(IMG_SCREEN_BACKGROUND));
}


/*-----------------------------------------------------------------------------
  activation du screensaver
  ---------------------------------------------------------------------------*/
void screensaver_enter(void)
{
#if SCREENSAVER_NO_DISPLAY
    LOGD("screen saver enter ...");
    if (!scrn_active)
    { 
        backlight_onoff(FALSE);
        scrn_active = TRUE;
    }
#else
    NGWinstance *widget_moving_fbox ;
    NGWinstance *widget_background_fbox = NULL;
    NGWinstance *widget_foreground_fbox = NULL;
    NGGpoint     pos ;
    NGGsize      siz ;
    NGGsize      background_siz ={480, 854};
    NGGsize      foreground_siz ;

    LOGD("screen saver enter ...");
    if (!scrn_active)
    {
        if (background_fbox == NULL)
        {
            background_fbox = disp_w_pinboard(disppinboard_mainscreen, "background");

            refresh_timeout = 1;
            disp_i_setWidgetBackground(background_fbox, NULL, COLOR_BLACK);
        }

        widget_background_fbox = background_fbox->objId;
        disp_i_setprop(widget_background_fbox, NGWP_SIZE, (NGWPdata)&background_siz);
    
        if (moving_fbox == NULL)
        {
            uint16_t     h = 0;

            moving_fbox = disp_w_pinboard(disppinboard_mainscreen, "moving");
//XTScf01037+
            if (moving_fbox == NULL)
            {
                LOGE("Create(scrsav mov) FAILED");
                return;
            }
//XTScf01037-

            widget_moving_fbox = moving_fbox->objId ;

            siz.w = 480;
            siz.h = 43; //homebar size
            h = siz.h;
            // Ajustement de la hauteur
            {
                widget_background_fbox = background_fbox->objId;
                disp_i_getprop(widget_moving_fbox, NGWP_SIZE, (NGWPdata *)&siz);
                disp_i_getprop(widget_background_fbox, NGWP_SIZE, (NGWPdata *)&background_siz);

                siz.h = h;

                moving_fbox->skins_on_reload_cb = on_skins_reload;

                disp_i_setprop(widget_moving_fbox, NGWP_MOTIF_IMAGE, (NGWPdata) skins_get_image(IMG_SCREEN_BACKGROUND));
                disp_i_setprop(widget_moving_fbox, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_IMAGE);
                siz.w = 480;
                disp_i_setprop(widget_moving_fbox, NGWP_SIZE, (NGWPdata)&siz);
            }
        }
        else
        {
            widget_moving_fbox = moving_fbox->objId;
        }

  
        if (foreground_fbox == NULL)
        {
            foreground_fbox = disp_w_pinboard(disppinboard_mainscreen, "foreground");
            if (foreground_fbox == NULL)
            {
                LOGE("Create(scrsav fgd) FAILED");
                return;
            }

            widget_foreground_fbox = foreground_fbox->objId;

            disp_i_setprop(widget_foreground_fbox, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_NONE);
            disp_i_getprop(widget_foreground_fbox, NGWP_SIZE, (NGWPdata *)&foreground_siz);

            foreground_siz.w = 480;
            foreground_siz.h = 854;

            disp_i_setprop(widget_foreground_fbox, NGWP_SIZE, (NGWPdata)&foreground_siz);

        }

        // enregistrement du timer
        refresh_id = timevt_register(screensaver_refresh, NULL, refresh_timeout);
        if (refresh_id == -1)
            LOGE("failed to register screensaver !");

        // visibilite des framebox
        disp_i_setprop(widget_background_fbox, NGWP_HIDDEN, (NGWPdata)0);
        disp_i_setprop(widget_moving_fbox, NGWP_HIDDEN, (NGWPdata)0);

        //set backlight level
        bl_level_record = get_backlight_level();
        set_backlight_level(1);
    
        scrn_active = TRUE;
        direction   = GO_DOWN;
    }
#endif
}



/*-----------------------------------------------------------------------------
  desactivation du screensaver
  ---------------------------------------------------------------------------*/
void screensaver_leave(void)
{
#if SCREENSAVER_NO_DISPLAY
    LOGD("screen saver leave ...");
    if (scrn_active)
    { 
        backlight_onoff(TRUE);
        scrn_active = FALSE;
    }
#else    
    LOGD("screen saver leave ...");
    if (scrn_active)
    {
        if (refresh_id != -1)
        {
            timevt_unregister(refresh_id);
            refresh_id = -1;
        }

// on detruit les objets sur sortie car il seront detruits par un clearscreen
// et donc ca risque de planter par la suite
#if 0
        {
            NGGpoint pos ;
            NGWinstance *widget_moving_fbox ;

            // visibilite des framebox
             disp_i_setprop(background_fbox, NGWP_HIDDEN,(NGWPdata)1);
            disp_i_setprop(moving_fbox, NGWP_HIDDEN,(NGWPdata)1);

            // repositionnement de la moving framebox tout en haut
            widget_moving_fbox = moving_fbox->objId ;
            disp_i_getprop(widget_moving_fbox, NGWP_POSITION, (NGWPdata *)&pos);
            pos.y = 0 ;
            disp_i_setprop(widget_moving_fbox, NGWP_POSITION, (NGWPdata)&pos);
        }
#endif
        set_backlight_level(bl_level_record);
        scrn_active = FALSE;
    }
#endif
}



// XTSce87476+
/*-----------------------------------------------------------------------------
  destruction des frameboxes background et moving
  ---------------------------------------------------------------------------*/
void screensaver_destroy_fbox(void)
{
    if (moving_fbox != NULL)
    {
        ngwDelete(moving_fbox->objId);
        pw_free(moving_fbox);
        moving_fbox = NULL;
    }

    if (foreground_fbox != NULL)
    {
        ngwDelete(foreground_fbox->objId);
        pw_free(foreground_fbox);
        foreground_fbox = NULL;
    }

    if (background_fbox != NULL)
    {
        ngwDelete(background_fbox->objId);
        pw_free(background_fbox);
        background_fbox = NULL;
    }
}

// XTSce87476-
