/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <unistd.h>

#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"
#include "ticks.h"

#include "display.h"
#include "../disp_priv.h"

#include "i_skins.h"

#include <ngwalc.h>
#include <stdio.h>
#include <stdlib.h>

#if defined(HOST_CYGWIN)
#   include "../ng_win.h"
#else
#   if defined(HOST)
#      include "../ng_x11.h"
#      include <unistd.h>
#   else
#      include "../ng_lnx.h"
#   endif
#endif


/*****************************************************************************
 * conversion log Nexgen vers log NOE
 *****************************************************************************/
static void debugSyslog(void *cbdata, char const *file, int line, int module,
                        char const *msg)
{
    LOGI("%s: %s", ngwKernelDebugModuleStr[module] , msg);
}


/*---------------------------------------------------------------------------*/
/*                             NexGenWIDGETK                                 */
/*---------------------------------------------------------------------------*/
#define NGWDK_DRAW_BUF_SIZE   4*8192

/* Draw Buffer */
static NGubyte    gr_drawbuf[ NGWDK_DRAW_BUF_SIZE];

static NGOSmutex  wdk_mutex;
static NGOSmutex  wdk_mh_mutex;

NGubyte    wdk_mh_core[ NGW_HEAP_SIZE];
NGmemheap  wdk_mh;
NGubyte  * wdk_mh_extension;
NGmemstats        wdk_mh_initstats;

#if defined(NOE_D)
// TO CHECK : Do we have to create a specific wdk_params_D for model_E?
static NGWcfgent wdk_params [ ] = {

  NGW_CFG( NGWP_MUTEX,                    &wdk_mutex ),
  NGW_CFG( NGWP_DRAW_BUFFER,              gr_drawbuf ),
  NGW_CFG( NGWP_DRAW_BUFFER_LEN,          sizeof( gr_drawbuf) ),

//#if defined(HOST) && 0
//  NGW_CFG( NGWP_DEBUG_FLAGS,              NGWD_DRAW | NGWD_LAYOUT /* | NGWD_FOCUS */),
//#else
//  NGW_CFG( NGWP_DEBUG_FLAGS,              NGWD_NONE ),
//#endif
//  NGW_CFG( NGWP_DEBUG_CB,                 debugSyslog ),

  NGW_CFG( NGWP_ADD_CLASS,                ngwDTextClassNew),
  NGW_CFG( NGWP_DTEXT_FONT_MAX,           20), // majorant, patche en dynamique plus tard
  NGW_CFG( NGWP_DTEXT_PARSER_NEW,         ngwAlcTextParserNew),
  NGW_CFG( NGWP_DTEXT_PARSER_DESTROY,     ngwAlcTextParserDestroy),
  NGW_CFG( NGWP_DTEXT_PARSER_MAKE_BLOCK,  ngwAlcTextParserMakeBlock),
  /* Adding classes */
       /* Window widgets */
  NGW_CFG( NGWP_ADD_CLASS,                ngwWindowClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwPopupClassNew),
       /* Non interacting static widgets */
  NGW_CFG( NGWP_ADD_CLASS,                ngwImageClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwLabelClassNew),
       /* Interacting widgets: */
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcEntryClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwButtonClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwMessageBoxClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcTextAreaClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcTextAreaBoxClassNew),
       /* Layout container widgets */
  NGW_CFG( NGWP_ADD_CLASS,                ngwPinboardClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwStackClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwScrollCtClassNew),
  NGW_CFG( NGWP_SCROLLCT_SB_CLASSNAME,    "NGWalcScrollBar"),
  /* Miscellaneous objects */
  /* alcatel objects */
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcBannerClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcButtonClassNew),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcProgressBarClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcProgressViewClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcSliderClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcScrollBarClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcCardCtClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcTelNOEClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcHeaderBoxClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcPinboardClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcScrollCtClassNew),

  // c'est pas grave de mettre les classes 2 fois, la 2eme
  // ne fait que retrouver le bon pointeur initialise par la 1ere fois.
  // par contre il faut absolument mettre une definition de propriete
  // juste apres la definition de sa classe pour qu'elle soit enregistree
  // au bon endroit!
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcProgressBarClassNew),
  NGW_CFG( NGWP_ALC_PROGRESSBAR_SKIN_IMG, ngwAlcSkin_pbar),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcSliderClassNew),
  NGW_CFG( NGWP_ALC_SLIDER_SKIN_IMG,      ngwAlcSkin_slider),

// a supprimer ?
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcProgressViewClassNew),
  NGW_CFG( NGWP_ALC_PROGRESSVIEW_SKIN_IMG,ngwAlcSkin_pbar),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcScrollBarClassNew),
  NGW_CFG( NGWP_ALC_SCROLLBAR_BIG_SKIN_IMG,   ngwAlcSkin_sbar_big),
  NGW_CFG( NGWP_ALC_SCROLLBAR_SMALL_SKIN_IMG, ngwAlcSkin_sbar_small),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcCardCtClassNew),
  NGW_CFG( NGWP_ALC_CARDCT_SKIN_IMG,      ngwAlcSkin_cardct),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcTelNOEClassNew),
  NGW_CFG( NGWP_ALC_TELNOE_SKIN_IMG,      ngwAlcSkin_tnoe),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcHeaderBoxClassNew),
  NGW_CFG( NGWP_ALC_HEADERBOX_SKIN_IMG,   ngwAlcSkin_hdbox),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcTextAreaBoxClassNew),
  NGW_CFG( NGWP_ALC_TEXTAREABOX_SKIN_IMG, ngwAlcSkin_input),

  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcLabelClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcListClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcParaClassNew),

// a supprimer ?
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcMessageBoxClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcPopupClassNew),

#ifndef UNLOAD_UNUSED_WIDGETS
  NGW_CFG( NGWP_ADD_CLASS,                ngwScrollBarClassNew),
#endif
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcTextListClassNew),
// XTSce72250+
#if defined(FEATURE_IME)
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcImeClassNew),
#endif /*FEATURE_IME*/
// XTSce72250-
  //NGW_CFG( NGWP_ADD_CLASS,                ngwMessageBoxClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwScrollBarClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwProgressBarClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwRadioGroupClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwCanvasClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwSeparatorClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwComboBoxClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwMenuClassNew),
  //NGW_CFG( NGWP_ADD_CLASS,                ngwMenuButtonClassNew),
  NGW_CFG( NGWP_ADD_CLASS,                ngwAlcAppButtonClassNew),

  NGW_CFG( NGWP_END,                      NULL)
};

#endif

/*****************************************************************************
 * le heap pour les images
 *
 * use a separate heap to be sure it is available
 * size is needed because of PNG
 *****************************************************************************/
//XTSce72955+
#define WDK_IMG_MH_CORE_LEN  0x20000

static NGubyte    wdk_img_mh_core[WDK_IMG_MH_CORE_LEN];
//XTSce72955-
NGmemheap         wdk_img_mh;
NGmemstats        wdk_img_mh_initstats;
static NGOSmutex  wdk_img_mh_mutex;

/*****************************************************************************
 * Heap management functions
 *****************************************************************************/

void wdkHeapInit( void)
{
  NGmemheapctl  mhctl; /* temporaire, sera copié par ngMemInit dans wdk_mh */
  int           err;

  memset (wdk_mh_core, TEST_PATTERN_NEXGEN_HEAP, NGW_HEAP_SIZE);

  /* on fait d'abord le heap general pour les widgets */

  ngMemSet(&mhctl, '\0', sizeof(mhctl));
  mhctl.mhctl_core  = &wdk_mh_core;
  mhctl.mhctl_len   = sizeof( wdk_mh_core);
  mhctl.mhctl_blk   = NGW_HEAP_BLOCK_SIZE;
  mhctl.mhctl_mutex = &wdk_mh_mutex;

  err = ngMemInit( &wdk_mh, &mhctl);
  if (NG_EOK != err)
  {
    LOGE("nginit: Cannot init memory heap");
  }

  ngMemStatsGetFree( &wdk_mh, &wdk_mh_initstats);

  /* Init NexGen Core Heap extension to NULL */

  wdk_mh_extension = NULL;


  /* on fait ensuite le heap specifique du decodeur d'images */

  ngMemSet(&mhctl, '\0', sizeof(mhctl));
  mhctl.mhctl_core  = wdk_img_mh_core;
  mhctl.mhctl_len   = WDK_IMG_MH_CORE_LEN;
  mhctl.mhctl_blk   = NGW_HEAP_BLOCK_SIZE;      /* meme taille de blocs? */
  mhctl.mhctl_mutex = &wdk_img_mh_mutex;

  err = ngMemInit( &wdk_img_mh, &mhctl);
  if (NG_EOK != err)
  {
    LOGE("nginit: Cannot init image heap");
  }

  ngMemStatsGetFree( &wdk_img_mh, &wdk_img_mh_initstats);  /* interet discutable */
}


/*****************************************************************************
 * cree un nouveau contexte.
 *****************************************************************************/
NGWctx *disp_createContext(const char *comment)
{
    NGWctx *context;
	
    wdkHeapInit();

    context = ngwCtxNew (&wdk_mh, wdk_params);

    if (NULL == context)
    {
        LOGE("ngwCtxNew() failed. Cannot create widget context.");
    }

    // initialisation de la couleur du curseur:
    //
    // en fait, la bonne valeur devrait toujours etre blanc, sauf
    // qu'il y a un pb quand la palette est 2 ou 4 couleurs!


    // sur target, on veut mettre BLANC (valeur normale) pour le poste D
    // et NOIR sur les postes a petites palettes
    ngwClassSetProp( ngwGetClassByName( context, "NGWentry"),
                   NGWP_ENTRY_COLOR_XOR, (NGWPdata) NGG_COLOR_BLACK);

    ngwClassSetProp( ngwGetClassByName( context, "NGWalcEntry"),
                   NGWP_ENTRY_COLOR_XOR, (NGWPdata) NGG_COLOR_BLACK);

    ngwClassSetProp( ngwGetClassByName( context, "NGWalcTextArea"),
                   NGWP_TEXTAREA_COLOR_XOR, (NGWPdata) NGG_COLOR_BLACK);

/* [XTSce18258 */
    ngwClassSetProp( ngwGetClassByName( context, "NGWalcEntry"),
                   NGWP_ENTRY_PASSWORD_CHAR, (NGWPdata) "*");
/* XTSce18258] */

    ngwClassSetProp( ngwGetClassByName( context, "NGWalcEntry"),
                   NGWP_ENTRY_PASSWORD_SUBST, (NGWPdata) "_");

#if 1
/* [XTSce18826 PRS noeipD:inputbox, le texte est tronque. Affiche si appui sur Back
 * attente patch Nexgen OK
 */
    {
    int fontIdNg;

    fontIdNg= disp_i_fontIdNoe2fontIdNg(FONT_REGULAR);

    ngwClassSetProp( ngwGetClassByName( context, "NGWalcTextArea"),
                     NGWP_FONTID, (NGWPdata) fontIdNg);
    }
/* XTSce18826] */
#endif

/* [XTSce25353 */
    ngwClassSetProp( ngwGetClassByName( context, "NGWdText"),
                     NGWP_DTEXT_FONT_MAX, (NGWPdata) disp_max_fonts);
/* XTSce25353] */

    return context;
}

/*---------------------------------------------------------------------------
 * shutdown Nexgen
 *---------------------------------------------------------------------------*/

static int heapsCheck( void)
{
  int err;
  NGmemstats finalstats;
  err = NG_EOK;

#define HEAP_CHECK( name)                                                    \
  ngMemStatsGetFree( &name, &finalstats);                                    \
  if (0 != ngMemCmp( &finalstats, &name##_initstats, sizeof( NGmemstats))) { \
    printf( "Memory heap %15s not empty!\n", #name);                         \
    printf( "  %8u bytes still allocated\n",                                 \
  (unsigned int)(name##_initstats.ms_total_size - finalstats.ms_total_size));\
    ngMemStatsGetAlloc( &name, &finalstats);                                 \
    printf( "  in %u blocks\n", (unsigned int)finalstats.ms_total_count);    \
    ngMemDebugDump( &(name));                                                \
    err= -1;                                                                 \
  } else {                                                                   \
    printf( "Memory heap %15s empty (ok!)\n", #name);                        \
  }

  HEAP_CHECK( wdk_mh);

#undef HEAP_CHECK

  return err;
}

/*****************************************************************************
 * crée une nouvelle fenêtre dans un contexte donné
 *****************************************************************************/
NGWinstance *disp_w_window(const char *comment)
{
    NGWinstance *window;
    NGGpoint     pos;

    window = ngwCreate(global_w_ctx, "NGWwindow", NULL);
    if (NULL == window)
        LOGE("ngwCreate() failed");

    pos = POS_ORIGIN;
    disp_i_setprop(window, NGWP_POSITION, (NGWPdata)&pos);

    LOGI("disp_size: %d x %d", disp_size.w, disp_size.h);
    disp_i_setprop(window, NGWP_SIZE, (NGWPdata) &disp_size);

    return window;
}
