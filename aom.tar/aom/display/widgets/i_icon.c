/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stddef.h>

#include "stdinc.h"
#include "log.h"
#include "configs.h"
#include "rofs.h"

#include "ticker.h"
#include "worker.h"
#include "log.h"

#include "display.h"
#include "../disp_priv.h"

#include "i_icon.h"

#define TICKER_WHEN_REQUIRED

#if 0
#define debug(...) Log(__FILE__, __LINE__, LOG_DEBUG, ##__VA_ARGS__)

#  define DEBUG__(s) debug s
#else
#  define DEBUG__(s)
#endif


#if defined(TICKER_WHEN_REQUIRED)
static void animator_ticker_callback(uint32_t ms, uint32_t tck, void *data);
#endif

/*-----------------------------------------------------------------------------
  definition privees
  ---------------------------------------------------------------------------*/
#define ICON_ANIMATED 500

// pour acceder au 'byte X' et au 'byte Y' d'un icone de type virtual add-on
#define XID(id)       ((id & 0x003f) >> 0)
#define YID(id)       ((id & 0x3f00) >> 8)

/*-----------------------------------------------------------------------------
  variables privees
  ---------------------------------------------------------------------------*/
// 12345678
// icon_X_ : le prefixe des fichiers
static char nameprefix[8];

/*-----------------------------------------------------------------------------
  gestion du cache icones
  ---------------------------------------------------------------------------*/
#define ICON_MAX_S    500
static NGGimage *iconcache_S[ICON_MAX_S];

#define ICON_MAX_A    500
static NGGimage *iconcache_A[ICON_MAX_A];


/*-----------------------------------------------------------------------------
  gestion des icones animes
  ---------------------------------------------------------------------------*/
#define MAX_ANIMATED  ICON_MAX_A

static int8_t   animator_ticker_id  = -1;
static int8_t   animator_worker_id  = -1;
static uint32_t animator_worker_tck =  0;

// le tableau 'animated_next' donne pour chaque icone, l'icone suivant dans
// l'animation
static uint16_t animated_next[ICON_MAX_A];

// la liste des icones enregistres pour animation
static struct
{
    registerItem *item;
    uint16_t       icon;
    uint16_t       base;
    NGWinstance   *inst;
    int            prop;
    int            idx;
#ifdef do_debug
    uint16_t       oid;
#endif
} animated_list[MAX_ANIMATED];

static uint32_t animated_count = 0;

// setprop global pour toutes les icones y compris la telephonic box
static void disp_i_global_setprop(
    registerItem *item, NGWinstance *widget, NGWpropId pid, NGWPdata data, int idx
)
{
    disp_i_setprop(widget, pid, data);
}

/*-----------------------------------------------------------------------------
  recherche d'une icone dans le cache

  iconid dans [0 .. ICON_MAX_S-1] ou dans [0 .. ICON_MAX_A-1]
  ---------------------------------------------------------------------------*/
static NGGimage *iconcache_find(uint16_t iconid)
{
    if (iconid < ICON_ANIMATED)
    {
        if (iconid < ICON_MAX_S)
            return iconcache_S[iconid];
    }
    else
    {
        uint16_t animid = (iconid-ICON_ANIMATED);

        if (animid < ICON_MAX_A)
            return iconcache_A[animid];
    }
    return NULL;
}

/*-----------------------------------------------------------------------------
  Retrieve an icon id  associated to a widget or to an icon pointer

  - Static icons can be retrieved by specifying the icon pointer (iconpt). You
  may set inst and item_number to null.
  - Animated icon can be retrieved by specifying the widget (inst) and the
  item_number for widget that handles multiples icons (today only telnoe). You
  may set iconpt to null.

  In case of animated icons, this function returns the icon id specified in
  disp_i_iconCreate() and the icon of the currently displayed icon.

  XTSce32049 add disp_i_iconLookup() function

  ---------------------------------------------------------------------------*/
uint16_t disp_i_iconLookup(NGWinstance* inst, NGGimage *iconpt, int item_number)
{
    int i = 0;

    //-----------------------------------------------------------
    // Look in table of animated icons
    //-----------------------------------------------------------
    if (inst != NULL)
    {
        for(i = 0 ; i < MAX_ANIMATED ; i++)
        {
            if ((animated_list[i].item != NULL) &&
                (animated_list[i].inst == inst) &&
                (animated_list[i].idx  == item_number) )
                return animated_list[i].base;
        }
    }

    //-----------------------------------------------------------
    // Look in table of static icons
    //-----------------------------------------------------------
    if (iconpt != NULL)
    {
        for(i = 0; i < ICON_MAX_S ; i++)
            if (iconpt == iconcache_S[i])
                return i;
    }

    //-----------------------------------------------------------
    // Not found
    //-----------------------------------------------------------
    return (uint16_t)-1;
}

/*-----------------------------------------------------------------------------
  ajout d'une icone dans le cache

  iconid dans [0 .. ICON_MAX_S-1] ou dans [0 .. ICON_MAX_A-1]
  ---------------------------------------------------------------------------*/
static NGGimage *iconcache_save(uint16_t iconid, NGGimage *iconpt)
{
    if (iconid < ICON_ANIMATED)
    {
        if (iconid < ICON_MAX_S)
            iconcache_S[iconid] = iconpt;
    }
    else
    {
        uint16_t animid = (iconid-ICON_ANIMATED);

        if (animid < ICON_MAX_A)
            iconcache_A[animid] = iconpt;
    }
    return iconpt;
}

/*-----------------------------------------------------------------------------
  ajout d'une icone dans le cache

  iconid et resultat dans [ICON_ANIMATED .. ICON_ANIMATED+ICON_MAX_A-1]
  ---------------------------------------------------------------------------*/
static uint16_t next(uint16_t iconid)
{
    uint16_t animid = (iconid - ICON_ANIMATED);

    if (animid < ICON_MAX_A)
        return (animated_next[animid]+ICON_ANIMATED);
    return iconid;
}


/*-----------------------------------------------------------------------------
  chargement des donnees associees a une icone. Si c'est une nouvelle icone,
  elle est ajoutee au cache

  iconid dans [0 .. ICON_MAX_S-1]
  ou
  iconid dans [ICON_ANIMATED .. ICON_ANIMATED+ICON_MAX_A-1]
  ---------------------------------------------------------------------------*/
NGGimage *load_icon(uint16_t iconid)
{
    NGGimage *iconpt;
    DEBUG__(("load_icon(%d) func ent.", (int)iconid));

    LOGI("load_icon(%d) func ent.\n",iconid);

    // check cache
    iconpt = iconcache_find(iconid);
    if (iconpt == NULL)
    {
        // 12345678901234567890
        // icon_X_sss.png
        // icon_X_aaa_bbb.png
//XTScf01037
        char    name[32];
        FILE_t *file = NULL;

        if (iconid < ICON_ANIMATED)
            sprintf(name, "%s%03d.png", nameprefix, iconid);
        else
           sprintf(name, "%s%03d_%03d.png", nameprefix, iconid, next(iconid));

        file = rofs_open(ROFS_RSC_ICON, name);
        if (file == NULL)
        {
            DEBUG__(("file %s not found !", name));
            return NULL;
        }
//XTSce93959+
        if (rofs_fsize(file) == 0)
        {
            rofs_close(file);
            DEBUG__(("file %s size is zero!", name));
           return NULL;
        }
//XTSce93959-

        iconpt = disp_decode(NULL, rofs_faddr(file), rofs_fsize(file), IMAGE_FORMAT_PNG);

        iconcache_save(iconid, iconpt);
        rofs_close(file);
    }
    return iconpt;
}

static uint16_t normalize(uint16_t iconid)
{
    if (iconid & ICON_NOE)
        iconid = (iconid & 0x7fff);
    else
        iconid = XID(iconid);

    return iconid;
}

/*-----------------------------------------------------------------------------
  decodage d'une icone

  iconid dans [0x8000 .. 0x8???] ou dans [0 .. 0x7fff]
  ---------------------------------------------------------------------------*/
NGGimage *disp_i_iconDecode(uint16_t iconid)
{
    DEBUG__(("disp_i_iconDecode(%d) func ent.", iconid));
    return load_icon(normalize(iconid));
}

/*-----------------------------------------------------------------------------
  retourne les dimensions d'une icone

  iconid dans [0x8000 .. 0x8???] ou dans [0 .. 0x7fff]
  ---------------------------------------------------------------------------*/
void disp_i_iconSize(uint16_t iconid, NGGsize *size)
{
    if (NULL == size)
    {
        return;
    }

    NGGimage *image = load_icon(normalize(iconid));

    if (NULL == image)
    {
        size->w = 0;
        size->h = 0;
    }
    else
    {
        size->w = image->img_size.w;
        size->h = image->img_size.h;
    }

    DEBUG__(("disp_i_iconSize() func iconid=%d, size=(w:%d,h:%d)", iconid, size->w, size->h));
}



/*-----------------------------------------------------------------------------
  register
  ---------------------------------------------------------------------------*/
static void register_animated(registerItem *item,
                              uint16_t       icon,
                              NGWinstance   *inst,
                              int            prop,
                              int            idx )
{
    int    i = 0;
    int    r = 0;
    bool_t f = FALSE;

    for(i = 0 ; (i < MAX_ANIMATED) ; i++)
    {
        if ((animated_list[i].item == NULL) && (! f))
        {
            r = i;
            f = TRUE;
            DEBUG__(("ICONMGR: empty room found (%2d)", r));
        }
        else
        if ((animated_list[i].item == item) && (animated_list[i].inst == inst))
        {
            r = i;
            f = TRUE;
            DEBUG__(("ICONMGR: same registered item found (%2d)", r));
            break;
        }
    }

    if (f)
    {
        animated_list[r].prop = prop;
        animated_list[r].inst = inst;
        animated_list[r].base = icon;
        animated_list[r].item = item;
        animated_list[r].idx  = idx;
#ifdef do_debug
        animated_list[r].oid  = OID;
#endif
        // apres enregistrement d'une icone -> reset de toutes les icones avec
        // l'icones initiale
        for(i = 0 ; (i < MAX_ANIMATED) ; i++)
        {
            if (animated_list[i].item != NULL)
                animated_list[i].icon = animated_list[i].base;
        }
#if defined(TICKER_WHEN_REQUIRED)
        if ((animated_count == 0) && (animator_ticker_id == -1))
        {
            bool_t need_ticker = (animator_worker_id != -1);
//RA 33126+ register ticker only if associated worker callback exist
            if (need_ticker)
            {
                animator_ticker_id = ticker_register(animator_ticker_callback, NULL);
                if (animator_ticker_id == -1)
                {
                    DEBUG__(("ICONMGR: failed to register animator ticker"));
                    return;
                }
                 LOGI("ICONMGR: animator started");
            }
            else
            {
                DEBUG__(("ICONMGR: failed to register animator ticker because worker doesn't exist"));
                return;
            }
//RA 33126-
        }
#endif
        animated_count++;
        DEBUG__(("ICONMGR: %3d icons (register)", animated_count));
    }
    else
    {
        DEBUG__(("ICONMGR: failed to register 0x%04x for animation...", icon));
    }
}



/*-----------------------------------------------------------------------------
  unregister
  ---------------------------------------------------------------------------*/
static void unregister_animated(registerItem *item, NGWinstance *inst, int idx)
{
    int i;

    for(i = 0 ; (i < MAX_ANIMATED) ; i++)
    {
        if (animated_list[i].item == item)
        {
            if ((inst == NULL) || ( (animated_list[i].inst == inst)))
            {
                 animated_list[i].item = NULL;

                 animated_count--;
                 DEBUG__(("ICONMGR: %3d icons (unregister)", animated_count));

                 if (inst != NULL)
                 {
                     DEBUG__(("ICONMGR: icon removed in animated list, item=%p inst=%p idx=%d",
                              item, inst, idx ));
                 }
            }
        }
    }
    DEBUG__(("ICONMGR: animated_count: %d, animator_ticker_id: %d",
                               animated_count, animator_ticker_id));
#if defined(TICKER_WHEN_REQUIRED)
    if ((animated_count == 0) && (animator_ticker_id != -1))
    {
        ticker_unregister(animator_ticker_id);
        animator_ticker_id = -1;
        LOGD("ICONMGR: animator stopped");
    }
#endif
}


/*-----------------------------------------------------------------------------
  creation

  iconid dans [0x8000 .. 0x8???] ou dans [0 .. 0x7fff]
  ---------------------------------------------------------------------------*/
void disp_i_iconCreate(registerItem *item,
                       uint16_t       icon,
                       NGWinstance   *inst,
                       int            prop,
                       int            idx)
{
    uint16_t  conv;
    NGGimage *iconpt = NULL;

    DEBUG__((
        "ICONMGR: create item=%p icon=0x%04x inst=%p idx=%d",
        item, icon, inst, idx
        ));

    if (icon & ICON_NOE)
    {
        conv   = (icon & 0x7fff);
        iconpt = load_icon(conv);

        if (conv >= ICON_ANIMATED)
        {
            register_animated(item, icon, inst, prop, idx);
            DEBUG__(("ICONMGR: registered N-animated (0x%04x)", icon));
        }
        else
        {
            /* remove eventualy in blinking list */
            unregister_animated(item, inst, idx);
        }
    }
    else
    {
        iconpt = load_icon(XID(icon));

        if (icon)
        {
            register_animated(item, icon, inst, prop, idx);
            DEBUG__(("ICONMGR: registered 2-animated (0x%04x)", icon));
        }
    }

    disp_i_global_setprop(item, inst, prop, (NGWPdata)iconpt, idx);
}



/*-----------------------------------------------------------------------------
  destruction (remove from the blinking list at object delete)
  ---------------------------------------------------------------------------*/
void disp_i_iconBlinkFlush(registerItem *item)
{
    unregister_animated(item, NULL, 0);
}



/*-----------------------------------------------------------------------------
  destruction icon (remove from the blinking list) and write a white one
  ---------------------------------------------------------------------------*/
void disp_i_iconErase(
    registerItem *item, NGWinstance *inst, int prop, int idx
    )
{

    DEBUG__((
        "ICONMGR: erase  item=%p icon=0x%04x inst=%p idx=%d",
        item, 0, inst, idx
        ));

    /* remove in blinking list */
    unregister_animated(item, inst, idx);


    /* delete object (animated or fixed) */
    if( inst != NULL )
    {
        NGGimage *iconpt = NULL; /* NULL ptr means remove the Nexgen icon */

        disp_i_global_setprop(item, inst, prop, (NGWPdata)iconpt, idx);
    }
}



#if !defined(NO_ICON_ANIMATION)
/*-----------------------------------------------------------------------------
  routine appelee par le worker pour la gestion de l'animation
  ---------------------------------------------------------------------------*/
static void animator_worker_callback(void *data)
{
    TIMING_VARIABLES

    int          i;
    bool_t       boVisible;
    NGWinstance *widget;

    ngwBeginMaxWait(global_w_ctx, 20);

    for(i = 0 ; (i < MAX_ANIMATED) ; i++)
    {
        registerItem *item = animated_list[i].item;

        if (item)
        {
            widget = item->objId;

            boVisible = disp_i_ngGetVisible(widget);

            DEBUG__(("ICONMGR:CALLB[%d] item:%p, icon:%04X, inst:%p, "
                     "prop:%X, idx:%d, visib:%d", i,
                     item, animated_list[i].icon, animated_list[i].inst,
                     animated_list[i].prop, animated_list[i].idx, boVisible));

            if (boVisible)
            {
                uint16_t icon_curr = animated_list[i].icon;
                uint16_t icon_next = 0;

                DEBUG__(("icon:%04X visible", animated_list[i].icon));
                if (icon_curr & ICON_NOE)
                {
                    icon_curr = (icon_curr & 0x7fff);
                    icon_next = next(icon_curr);

                    DEBUG__(("icon:%04X visible, setprop icon_noe", animated_list[i].icon));
                    disp_i_global_setprop(
                        item,
                        animated_list[i].inst,
                        animated_list[i].prop,
                        (NGWPdata)load_icon(icon_next),
                        animated_list[i].idx
                        );

                    animated_list[i].icon = (icon_next | ICON_NOE);
                }
                else
                {
                    uint16_t  id = 0;
                    uint16_t xid = XID(icon_curr);
                    uint16_t yid = YID(icon_curr);

                    if (xid != yid)
                    {          
                        switch(*(uint32_t *)data & 0x3)
                        {
                        case 0x2:
                            id = yid;
                            break;

                        case 0x0:
                            id = xid;
                            break;
                        }

                        DEBUG__(("icon:%04X visible, setprop next anim", animated_list[i].icon));
                        disp_i_global_setprop(
                            item,
                            animated_list[i].inst,
                            animated_list[i].prop,
                            (NGWPdata)load_icon(id),
                            animated_list[i].idx
                            );
                    }
                }
            }
        }
    }

    TIMING_START
    ngwEnd(global_w_ctx);
    TIMING_END("ngwEnd")
}



/*-----------------------------------------------------------------------------
  routine appelee par le ticker pour la gestion de l'animation
  ---------------------------------------------------------------------------*/
static void animator_ticker_callback(uint32_t ms, uint32_t tck, void *data)
{
    animator_worker_tck = tck;

    // icon animation rate = 500ms
    if ((tck & 0x1) == 0x1)
        return;

#if (TRACE_DRAW_REQUESTS == 0) || (TRACE_DRAW_REQUESTS_ICONS == 1)
    worker_execute(animator_worker_id);
#endif
}

#endif /* ! NO_ICON_ANIMATION */


static void cb_on_rofs_list(const char *prefix, const char *filename)
{
    int n;
    int id_curr;
    int id_next;

    char *p = (char *)(filename + strlen(prefix));
    n = sscanf(p, "%03d_%03d.png", &id_curr, &id_next);
    if (n == 2) {
#define isvalid(id) ((id) < (ICON_ANIMATED + ICON_MAX_A))
        if (isvalid(id_curr) && isvalid(id_next)) {
            animated_next[(id_curr - ICON_ANIMATED)] = (id_next - ICON_ANIMATED);
        } else {
            LOGE("icons: animated icon error (max=%d, %d, %d)", ICON_MAX_A, id_curr, id_next);
        }
    }
}

/*-----------------------------------------------------------------------------
  initialisation de la liste des icones animes (nu gestionnaire d'icones
  ---------------------------------------------------------------------------*/
static void load_N_animated(void)
{
    int  i;
    char prefix[_MAX_FILENAME_LEN_] = "";

    for(i = 0 ; i < MAX_ANIMATED ; i++)
        animated_next[i] = 0;

    sprintf(prefix, "%s", nameprefix);
    rofs_list(ROFS_RSC_ICON, prefix, cb_on_rofs_list);
}

/*-----------------------------------------------------------------------------
  OnSkinsReload event support
  ---------------------------------------------------------------------------*/
void icons_reload()
{
    int            i;
    unsigned char *ptr;

#if !defined(NO_ICON_ANIMATION)
    if (animator_ticker_id != -1)
    {
        ticker_unregister(animator_ticker_id);
        animator_ticker_id = -1;
        LOGD("icons_reload(): ticker stopped");
    }
#endif

    // static
    for(i = 0 ; (i < ICON_MAX_S) ; i++) {
        ptr = (unsigned char *)iconcache_S[i];
        if (ptr) {
            iconcache_S[i] = NULL;
            load_icon(i);
            disp_w_image_free((NGGimage *)ptr);
        }
    }

    // animated
    for(i = 0 ; (i < ICON_MAX_A) ; i++) {
        ptr = (unsigned char *)iconcache_A[i];
        if (ptr) {
            iconcache_A[i] = NULL;
            load_icon(i+ICON_ANIMATED);
            disp_w_image_free((NGGimage *)ptr);
        }
    }

    load_N_animated();

#if !defined(NO_ICON_ANIMATION)
    animator_ticker_id = ticker_register(animator_ticker_callback, NULL);
    if (animator_ticker_id == -1) {
        LOGE("icons_reload(): failed to start ticker");
        return;
    }
    LOGD("icons_reload(): ticker restarted");
#endif
}

registerItem *disp_w_iconbox(NGWinstance *ctnr, const char *comment)
{
    NGWinstance  *widget;
    registerItem *rI    = (registerItem *)pw_malloc(sizeof(registerItem));
    
    if(rI == NULL)
    {
        LOGE("pw_malloc failed");
        return NULL;
    }

    widget = ngwCreate(global_w_ctx, "NGWimage", ctnr);
    if (NULL == widget)
    {
        LOGE("ngwCreate(iconbox)");
        return NULL;
    }

    disp_i_setprop(
        widget, NGWP_MOTIF_BORDER, (NGWPdata)""
        );
    disp_i_setprop(
        widget, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_BACKGROUND
        );

    rI->objId    = widget;
    rI->type     = DISP_TYPE_ICON;

    return rI;
}
/*-----------------------------------------------------------------------------
  initialisation du gestionnaire d'icones
  ---------------------------------------------------------------------------*/
void disp_init_iconsmgr(void)
{
    int       i;
    char      model_letter = 'e';

    // creation du prefixe des noms de fichiers
    sprintf((char *)&nameprefix, "icon_%c_", model_letter);

    // initialisation du cache des icones 'statiques'
    for(i = 0 ; (i < ICON_MAX_S) ; i++)
        iconcache_S[i] = NULL;

    // initialisation du cache des icones 'animes'
    for(i = 0 ; (i < ICON_MAX_A) ; i++)
        iconcache_A[i] = NULL;

    // initialisation de la liste des icones enregistres pour animation
    for(i = 0 ; (i < MAX_ANIMATED) ; i++)
        animated_list[i].item = NULL;

    // chargement des icones 'N-animated'
    load_N_animated();

#if !defined(NO_ICON_ANIMATION)
    // initialisation du worker
    animator_worker_id = worker_register(
        animator_worker_callback, &animator_worker_tck
    );
    if (animator_worker_id == -1)
    {
        DEBUG__(("ICONMGR: failed to register animator worker"));
        return;
    }
#  if !defined(TICKER_WHEN_REQUIRED)
    // initialisation du ticker
    animator_ticker_id = ticker_register(animator_ticker_callback, NULL);
    if (animator_ticker_id == -1)
    {
        DEBUG__(("ICONMGR: failed to register animator ticker"));
        return;
    }
#  endif
    DEBUG__(("ICONMGR: animator ticker & animator worker registered"));
#else
    DEBUG__(("ICONMGR: icon animation disabled"));
#endif /* ! NO_ICON_ANIMATION */
}



#if defined(WANT_FINALIZE)

void disp_exit_iconsmgr(void)
{
    int i;

    if (animator_ticker_id != -1)
    {
        ticker_unregister(animator_ticker_id);
        DEBUG__(("ICONMGR: animator ticker unregistered"));
    }

    if (animator_worker_id != -1)
    {
        worker_unregister(animator_worker_id);
        DEBUG__(("ICONMGR: animator worker unregistered"));
    }

    for(i = 0 ; (i < ICON_MAX_S) ; i++)
        if (iconcache_S[i])
        {
            disp_w_image_free(iconcache_S[i]);
            iconcache_S[i] = NULL;
        }

    for(i = 0 ; (i < ICON_MAX_A) ; i++)
        if (iconcache_A[i])
        {
            disp_w_image_free(iconcache_A[i]);
            iconcache_A[i] = NULL;
        }
}

#endif // defined(WANT_FINALIZE)

