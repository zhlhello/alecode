/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/10/04 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "stdinc.h"
#include "ctype.h"
#include "log.h"
#include "configs.h"

#if defined(DISPLAY)

/* NexGenOS includes */
#include <ngos2.h>
#include <ngerrno.h>
#include <ngstdlib.h>
#include <ngfsio.h>
#include <ngshell.h>
#include <ngos.h>
#include "ngwalc.h"
#endif

#include "display.h"
#include "../disp_priv.h"

#if defined(DISPLAY)
#include "arabic.h"
#endif

#if defined HOST
/*-----------------------------------------------------------------------------
  conversion 'texte protocole' vers 'texte nexgen'
  ----------------------------------------------------------------------------*/
static unsigned char *disp_i_textDumper(unsigned char *txt)
{
    int i, lng;
    unsigned char *p;
    unsigned char *q;

    lng=strlen((char *)txt);

    // bridage pour ne pas exploser syslog!
    if (lng > 100)
        lng= 100;

    p= q= pw_malloc((4 * lng) + 1); // au pire tout en utf-8 (<-> \xvv) + le null de fin

    for (i=0 ; i < lng ; i++)
    {
        if (txt[i] < 128) *q++= txt[i];
        else q += sprintf((char *)q, "\\x%.2x", txt[i]);
    }

    // pour avoir le null meme en cas de bridage:
    *q= '\0';

    return p;
}

#endif /* defined(HOST) */

/*-----------------------------------------------------------------------------
  conversion 'texte protocole' vers 'texte nexgen'
  ----------------------------------------------------------------------------*/
#if defined(DISPLAY)

//XTSce61171+
// This function is used instead of strtoul() to control the number of digits
// If the number of digits is lower than n, the value returned is zero.
// If the number of digits is greater than n, only firsts n digits are decoded.
unsigned long strndigittoul(const char *cp, char **endp, unsigned int ndigit)
{
    unsigned int i;
    unsigned long result = 0;
    for (i=0;i<ndigit;i++)
    {
        if (*cp<'0' || *cp>'9')
            break;
        result = result*10 + *cp-'0';
        cp++;
    }
    if (i<ndigit)
        result = 0;
    if (endp)
        *endp = (char *)cp;
    return result;
}
//XTSce61171-

unsigned char * disp_i_noeTxt2ngTxt(const char *texte, bool_t *trunc_allowed)
{
    int   newTextLen;
    char *newText;

    int nb;
    int i;
    int lng;
    char *p;

    *trunc_allowed = TRUE;

    lng= strlen(texte);

#if defined HOST
    LOGD("texte enrichi avant: lng= %d", lng);
#endif /* defined(HOST) */

    nb= 0;
    for (i=0; i < lng ; i++)
    {
        if ((texte)[i] == '\\') nb++;
        if ((texte)[i] == '{' ) nb++;
    }

    // on alloue une nouvelle chaine, en faisant une allocation par exces:
    // le 11 c'est parceque au pire on traite un \P et on insere 11 caracteres
    // le 1 c'est pour le '\0' a la fin bien sur
    newTextLen= lng + 11*nb + 1;
    newText   = pw_malloc(newTextLen);

    if(newText == NULL)
    {
         LOGE("pw_malloc failed");
        return NULL;
    }


    p= newText;
    for (i=0; i <= lng ; i++)
    {
        unsigned char c1= texte[i];

        if (c1 == '{')
        {
            *p++ = c1;
            *p++ = c1;
        }
        else if (c1 == '\\')
        {
            unsigned char c2= texte[i+1];
//David/crqms00203716 +
            if (c2 > 0x80)
            {
                *p++ = c1;
                continue;
            }
//David/crqms00203716 -
            switch(c2)
            {
                case 'R':
                    {
                        int fontId;
                        fontId= 1 + disp_i_fontIdNoe2fontIdNg(FONT_REGULAR);
                        p +=sprintf(p, "{F%d{.", fontId);
                    }
                    break;
                case 'B':
                    {
                        int fontId;
                        fontId= 1 + disp_i_fontIdNoe2fontIdNg(FONT_BOLD);
                        p +=sprintf(p, "{F%d{.", fontId);
                    }
                    break;
                case 'X':
                    {
                        int fontId;
//ZW crqms00190154+
                        fontId= 1 + disp_i_fontIdNoe2fontIdNg(FONT_EXTRABOLD);
//ZW crqms00190154-
                        p +=sprintf(p, "{F%d{.", fontId);
                    }
                    break;
                case 'K':
                    // clignotant
                    *p++ = '{';
                    *p++ = 'B';
                    *p++ = '1';
                    /* [XTSce18224 */
                    *p++ = '{';
                    *p++ = '.';
                    /* XTSce18224] */
                    break;
                case 'F':
                    /* XTSce23502+ */
                    // not underlined
                    *p++ = '{';
                    *p++ = 'U';
                    *p++ = '0';
                    /* XTSce23502- */
                    // framed
                    *p++ = '{';
                    *p++ = 'X';
                    *p++ = '1';
                    /* [XTSce18224 */
                    *p++ = '{';
                    *p++ = '.';
                    /* XTSce18224] */
                    break;
                case 'U':
                    /* XTSce23502+ */
                    // not framed
                    *p++ = '{';
                    *p++ = 'X';
                    *p++ = '0';
                    /* XTSce23502- */
                    // underlined
                    *p++ = '{';
                    *p++ = 'U';
                    *p++ = '1';
                    /* [XTSce18224 */
                    *p++ = '{';
                    *p++ = '.';
                    /* XTSce18224] */
                    break;
                case 'P':
                    // normal
                    // not underlined
                    *p++ = '{';
                    *p++ = 'U';
                    *p++ = '0';
                    // not framed
                    *p++ = '{';
                    *p++ = 'X';
                    *p++ = '0';
                    // not clignotant
                    *p++ = '{';
                    *p++ = 'B';
                    *p++ = '0';
                    /* [XTSce18224 */
                    *p++ = '{';
                    *p++ = '.';
                    /* XTSce18224] */
                    break;
                case 'n':
                    // next line
                    *p++ = '\n';
                    break;
                case '^':
                    // right tab
                    *p++ = '{';
                    *p++ = '|';
                    // XTSce37699+
                    // Special case when \^ is put on first position
                    if (i == 0)
                    {
                        *p++ = '{';
                        *p++ = '|';
                    }
                    // XTSce37699+
                    *trunc_allowed = FALSE;
                    break;
#if !defined(LOADER)
                case 'L':
                    // melody label
                    {
                        int       len = 0;
                        uint32_t  idx = 0;
                        char     *ptr = (char *)&texte[i+2];
                        /* XTSce64277 / XTSce64282 + */
                        if (sscanf(ptr,"%2d", (int *)&idx) > 0)
                        {
                            /* if sscanf > 0, at least 1st char is a digit */
                            len = 1 + (isdigit(ptr[1]) != 0);
                        }
                        /* XTSce64277 / XTSce64282 - */

                        if (len > 0)
                        {
                            const char *lptr = "melody 0";//just for compile, for AOM, will not come here.
                            int         llen = 0;

                            if (lptr != NULL)
                            {
                                int offt  = (p - newText);

                                llen      = strlen(lptr);

                                newTextLen= (newTextLen + llen + 1);
                                if (newText==NULL){
                                    newText   = pw_malloc(newTextLen);
                                }
                                else{
                                    newText   = pw_realloc(newText, newTextLen);
                                }

                                if(newText != NULL)
                                {
                                    p         = newText + offt;

                                    strcat(p, lptr);
                                    p += llen;
                                }
                            }
                            i += len; // skip label index
                        }
                        break;
                    }
#endif
                    //XTSce61171+
                case 'I':
                    // icon label
                    {
                        int       len = 0;
                        uint32_t  idx = 0;
                        char     *ptr = (char *)&texte[i+2];
                        char     *end = NULL;

                        idx = strndigittoul(ptr, &end, 3);
                        len = (end - ptr);

                        if (len > 0)
                        {
                            p +=sprintf(p, "{I%d{.", idx);
                            i += len; // skip label index
                        }
                        break;
                    }
                    //XTSce61171-
                case '\\':
                    // escape
                    *p++ = '\\';
                    break;
            }
            i++; // skip the second character
        }
        else
        {
            *p++ = c1;
        }
    }

#if defined HOST
    {
        if(newText != NULL)
        {
            char *z=(char *)disp_i_textDumper((uint8_t *)newText);
            LOGD("texte enrichi apres: `%s`", z);
            pw_free(z);
        }
    }
#endif /* defined(HOST) */

    /* DEV MS uaconvdisp + */
    return (unsigned char *)newText;
    /* DEV MS uaconvdisp - */
}


void disp_i_setTexte(NGWinstance *widget, char **texte)
{
//genshenl+
    char   *newText   = NULL;
    bool_t  truncation_allowed;
#if !defined(LOADER)
    int     len;
    char   *str_new   = NULL;
    char   *texte_tmp = NULL;
#endif

// XTSce26874+
    if (NULL == texte)
    {
         LOGE("texte is NULL\n");
        return;
    }

    if (NULL == *texte)
    {
        disp_i_setprop(widget, NGWP_TEXT, (NGWPdata)NULL);
        // on ne traite pas le TRUNCATE ici car pas de sens (?)
        return;
    }
// XTSce26874-

#if !defined(LOADER)
    len = strlen(*texte);
    disp_i_arabic_transformation(*texte, &str_new);

    if (str_new != NULL)
    {
        //Check if blinking cursor displayed
        char *findpos = NULL;
        
        findpos = strstr(str_new, "\\P|\\K");
        if (findpos && (str_new == findpos))
            memcpy(str_new, "\\K|\\P", strlen("\\K|\\P"));
                
        texte_tmp = exchange_datetime_name_arabic(str_new, len, FALSE);
        newText = (char *)disp_i_noeTxt2ngTxt(texte_tmp, &truncation_allowed);

        if (str_new && str_new != texte_tmp) 
            pw_free(str_new);
    }
    else
    {
// crqms00202831 Anne +
        if (language_is_arabic_or_hebrew()) //CR3GEENOE-1049
        {
            char *output = NULL;
            //output = reverse_arrow_latin_in_hebrewctx(*texte, len);
            // crqms00202857 Shilong +
            texte_tmp =  (char *)exchange_datetime_name_arabic(*texte, len, TRUE); //crqms00204663 Shilong

            output =  (char *)reverse_arrow_latin_in_hebrewctx(texte_tmp, len);
            // crqms00202857 Shilong -

            if(output)
            {
                newText = (char *)disp_i_noeTxt2ngTxt( output, &truncation_allowed);

                // in case output==*texte
                //if (output != *texte) {
                if (output != texte_tmp) {
                    pw_free(output);
                }
            }
            else
            {
                newText= (char *)disp_i_noeTxt2ngTxt(*texte, &truncation_allowed);
            }
        }
        else
// crqms00202831 Anne -
        {
            //would removed, only for test
            newText= (char *)disp_i_noeTxt2ngTxt(*texte, &truncation_allowed);
        }
    }

    if (texte_tmp != NULL && texte_tmp != *texte)
        pw_free(texte_tmp);

    disp_i_setprop(widget, NGWP_TEXT, (NGWPdata)newText);
#else
    /* DEV MS uaconvdisp + */
    newText= (char *)disp_i_noeTxt2ngTxt(*texte, &truncation_allowed);
    /* DEV MS uaconvdisp - */
    disp_i_setprop(widget, NGWP_TEXT, (NGWPdata)newText);
#endif
//crqms00200514 Anne -

    if (!truncation_allowed && ngwInstanciates(widget, "NGWalcLabel"))
    {
        disp_i_setprop(widget, NGWP_ALC_LABEL_TRUNCATE, (NGWPdata)0);
    }

    if (newText != NULL)
        pw_free(newText);

    //crms00204551 genshenl-
}

bool_t language_is_arabic_or_hebrew()
{
    return FALSE;
}

/*
  transformation the arabic and hebrew strings
  in_str is the input string paramter,
  out_str[in/out]: contains the transformed result string in case there are
  arabic/hebrew characters in the input string.
  the return value is a boolean flag:
  case true:  the input string contains arabic/herew characters
  case false: the input string doesn't contain arabic/hebrew characters
*/
//crms00204551 genshenl+
#if !defined(LOADER)
bool_t  disp_i_arabic_transformation(char * in_str, char **out_str)
{
    char  * str_new =   NULL;
    int  wstr_len=0;
    int  c_len =0;
    int  c_wlen=0;
    int i=0;
    int l1=0;
    bool_t b_aflag =FALSE;
    NGwchar * new_wtext=NULL;
    NGwchar * t2 = NULL;

    *out_str= NULL;

    if(in_str == NULL)
        return FALSE;

    //tranform the utf8 into UCS2 coded string
    wstr_len = strlen(in_str)+1;
    new_wtext =(NGwchar *)pw_malloc(wstr_len * sizeof(NGwchar));

    if(new_wtext == NULL)
    {
        return FALSE;
    }

    l1= ngUTF8mbstowcs(new_wtext, in_str, wstr_len-1);

    if(l1 < 0)
    {
        pw_free(new_wtext);
        return FALSE;
    }

    new_wtext[l1] = 0x0000; //add a termination character

    //to see if the string contains arabic/hebrew characters
    b_aflag = FALSE;

    for(i=0; i<l1; i++)
    {
        if(isArabicOrHebraize(new_wtext[i]))
        {
            b_aflag = TRUE;
            break;
        }
    }

    //transform only if the string contains such arabic/hebrew characters
    if(b_aflag)
    {
        //transform the arabic/hebrew characters
        t2 = pw_malloc(wstr_len * sizeof(NGwchar));

        if(t2 == NULL)
        {
            pw_free(new_wtext);
            return FALSE;
        }

        Arabic_Convert_Api( (char *)new_wtext,(char *)t2, l1*2, &c_wlen);

        t2[c_wlen/2]=0x0000;

        //tranform the UCS2 coded transformation result back into utf8 formats
        str_new = pw_malloc((wstr_len*3+1));

        c_len = ngUTF8wcstombs((char *)str_new, (uint16_t *)t2, wstr_len*3+1);
        (void)c_len;

        //return back to the caller
        *out_str = str_new;

        //free up resources
        if(t2!=NULL)
        {
            pw_free(t2);
            t2 = NULL;
        }
    }

    //free up resources
    if(new_wtext!=NULL)
    {
        pw_free(new_wtext);
        new_wtext = NULL;
    }

    return b_aflag;
}
#endif
//crms00204551 genshenl-


// retourne length after conversion or < 0 en cas d'erreur
// si outText n'est pas NULL une chaine mallocee est retourne dedans
// sinon la chine est liberee dans la fonction

int disp_i_utf8ok(const unsigned char *inText, NGwchar **outText)
{
    size_t   l1;
    int      l1w;
    NGwchar *p1w;

    // pour eviter de tester chez l'appelant, une chaine 'nulle' est OK

    if (NULL == inText)
    {
        // petit cas foireux: et dans outText?
        return 0;
    }

    // on cherche un majorant pour la taille des chaines 'wides'
    l1= strlen((const char *)inText) + 1;

    p1w= (NGwchar*)pw_malloc(l1 * sizeof(NGwchar));

    l1w= ngUTF8mbstowcs(p1w, (const char *)inText , l1);

    if (l1w < 0)
    {
        // chaine incorrecte
        pw_free(p1w);
        if (NULL != outText) *outText= NULL;
        return l1w;
    }

    if (NULL == outText)
    {
        pw_free(p1w);
    }
    else
    {
        *outText= p1w;
    }

    return l1w;
}

#endif

