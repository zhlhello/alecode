/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

//#define CYRILLIC
//#define GREC

#include "stdinc.h"
#include "log.h"
#include "objmgr.h"
#include "configs.h"

#include <ngwalc.h>
#include <a_list.h>
#include <a_sbar.h>
#include <stdio.h>

#include "display.h"
#include "../disp_priv.h"
#include "i_icon.h"
#include "screensaver.h"

#include "skins.h"

#define DEBUG 0

uint8_t disp_i_get_row_height(registerItem *item, int lineNb)
{
    return 78;
    //return YGRID(GRID_TYPE2)[3] - YGRID(GRID_TYPE2)[2];
}


registerItem *disp_w_list(NGWinstance *ctnr, const char *comment)
{
    NGWinstance  *widget;
    registerItem *rI    = (registerItem *)pw_malloc(sizeof(registerItem));
    
    if(rI == NULL)
    {
        LOGE("pw_malloc failed\n");
        return NULL;
    }
    
    widget = ngwCreate(global_w_ctx, "NGWalcList", ctnr);
    if (NULL == widget)
        LOGE("ngwCreate(pinboard)\n");

    disp_i_setprop(widget, NGWP_ALC_PHONE_TYPE, (NGWPdata)NGW_ALC_PHONE_TYPE_NOE_E);
        
    rI->objId    = widget;
    rI->type     = DISP_TYPE_LIST;
    rI->hook     = NULL;
    rI->data     = NULL;
    rI->palette.size   = 0;
    rI->palette.colors = NULL;
    
    return rI;
}


void disp_list_create_default(NGWinstance *widget,
                              NGWPdata count,
                              NGWPdata sb_count,
                              NGWPdata sb_start,
                              enum_ncolumns_t mode)
{
#ifdef DISPLAY
    disp_i_setprop(widget, NGWP_PALETTE, (NGWPdata)&ngwPalette2bpp);

#if 1
    disp_i_setprop(widget, NGWP_MOTIF_BORDER, (NGWPdata) "");
#else
#ifndef __arm
#warning "let the border only for test : TO BE SUPPRESSED"
#endif
#endif

    /* Define the column number */
    disp_i_setprop(widget, NGWP_ALC_LIST_COL_COUNT, (NGWPdata)(mode == COLUMN_1 ? 1 :2));

    /* Display policy of scrollbar */
    disp_i_setprop(widget, NGWP_LIST_SB_SHOW, (NGWPdata)
                   (mode == COLUMN_1 ? NGW_LIST_SB_SHOW_AS_REQUIRED : NGW_LIST_SB_SHOW_ALWAYS));

    /* Marge entre la scrollbar et l'item */
    disp_i_setprop(widget, NGWP_ALC_LIST_INTERNAL_MARGIN, (NGWPdata)1);

    /* 1er element visible dans la liste : a tester */
    disp_i_setprop(widget, NGWP_LIST_VISIBLE_FIRST_IDX, (NGWPdata)0);

    /* Size of the scrollbar: -1=> real number of item in list*/
    if (mode == COLUMN_2)
    {
        disp_i_setprop(widget, NGWP_ALC_LIST_THEORICAL_LENGTH, (sb_count + 1) / 2);
        disp_i_setprop(widget, NGWP_ALC_LIST_THEORICAL_IDX, (sb_start + 1) / 2);
    }
    else
    {
        disp_i_setprop(widget, NGWP_ALC_LIST_THEORICAL_LENGTH, sb_count);
        disp_i_setprop(widget, NGWP_ALC_LIST_THEORICAL_IDX, sb_start);
    }

    if (DEBUG)
    {
        NGWPdata data;
        ngwGetProp(widget, NGWP_LIST_COUNT, &data);
        LOGD("NGWP_LIST_COUNT=%d", (int)data);
        ngwGetProp(widget, NGWP_ALC_LIST_VISIBLE_LINE_COUNT, &data);
        LOGD("NGWP_LIST_VISIBLE_LINE_COUNT=%d", (int)data);
        if (mode == COLUMN_2)
        {
            ngwGetProp(widget, NGWP_ALC_LIST_THEORICAL_LENGTH, &data);
            LOGD("NGWP_ALC_LIST_THEORICAL_LENGTH=%d", (int)data);
            ngwGetProp(widget, NGWP_ALC_LIST_THEORICAL_IDX, &data);
            LOGD("NGWP_ALC_LIST_THEORICAL_IDX=%d", (int)data);
        }
    }

#endif // DISPLAY
}

/*-----------------------------------------------------------------------------
  change a graphical item in the graphical list
  -----------------------------------------------------------------------------*/
bool_t disp_list_delete_item_at(registerItem *item, int idx)
{
    NGWinstance *list = item->objId;
    NGWinstance *label;

    if (NG_EOK == ngwListGetAt(list, idx, (void const **)&label, NULL) &&
        NG_EOK == ngwListRemove(list, idx))
    {
//XTSce90166+
        disp_i_iconErase(item, label, NGWP_IMAGE, 0);
//XTSce90166-

        // suppress the label
        ngwDestroy(label);
        return TRUE;
    }
    else
    {
        char error[100];

        sprintf(error, "ngwListGetAt or ngwListRemove at index %d FAILED", idx);

        LOGE(error);
        return FALSE;
    }
}

#if defined(CYRILLIC) || defined(GREC)
unsigned char *u_convert(unsigned char *text)
{
    static unsigned char u_text[1024];
    int                  i,j;
    int                  u_page;
    int                  u_offset_U;
    int                  u_offset_L;
#ifdef CYRILLIC
    u_page = 0xd0;
    u_offset_U = 0x90;
    u_offset_L = 0xb0;
#elif defined(GREC)
    u_page = 0xce;
    u_offset_U = 0x91;
    u_offset_L = 0xb1;
#else
    return text;
#endif

    printf("u_text(%s) = ", text);
    for (i = j = 0 ; text[i] ; i++, j += 2) {
        if (text[i] < 0x80) {
            if (isalpha(text[i])) {
                u_text[j] = u_page;
                if (isupper(text[i])) {
                    u_text[j+1] = text[i] - 'A' + u_offset_U;
                } else {
                    u_text[j+1] = text[i] - 'a' + u_offset_L;
                }
                if (u_text[j+1] > 0xbf) {
                    u_text[j]++;
                    u_text[j+1] -= 0x40;
                }
                printf("%02x %02x ", u_text[j], u_text[j+1]);
            } else {
                u_text[j] = text[i];
                j--;
                printf("%02x ", u_text[j]);
            }
        } else {
            u_text[j] = text[i++];
            u_text[j+1] = text[i];
            printf("%02x %02x ", u_text[j], u_text[j+1]);
        }
    }
    u_text[j] = 0;
    printf("\n");

    return u_text;
}
#endif

/*-----------------------------------------------------------------------------
  change a graphical item in the graphical list
  -----------------------------------------------------------------------------*/
NGWinstance *disp_list_change_item_at(registerItem *item, int idx, char const *text, void *data, uint8_t fontid)
{
    NGWinstance *list = item->objId;
    NGWinstance *label = NULL;

    LOGD("LIST: Change item(idx=%d, text=\"%s\", icon=%s (%d)\n",
           idx, text ? text : "(no text)", data ? "yes" : "no", data ? *(uint16_t *)data : 0);

#ifdef DISPLAY
    if (NG_EOK == ngwListGetAt(list, idx, (void const **)&label, NULL))
    {
        if (NULL != text)
        {

#if defined(CYRILLIC) || defined(GREC)
            text = u_convert(text);
#endif

            disp_i_setTexte(label, (char**)&text); // ON VIOLE LE CONST!!!
            disp_i_setFont(label, fontid);
        }
// RA XTSce26874+
        else
        {
            disp_i_setprop(label, NGWP_TEXT, (NGWPdata)NULL);
        }
// RA XTSce26874-

        if (NULL != data)
        {
            uint16_t icon = *(uint16_t *)data;

            /* use new API for blinking icons */
            if(icon != 0)
            {
                disp_i_iconCreate(item, icon, label, NGWP_IMAGE, 0);
            }
            else /* icone 0 : delete it */
            {
                disp_i_iconErase(item, label, NGWP_IMAGE, 0);
            }
        }
#ifdef DEBUG
        else
        {
            LOGD("disp_list_change_item_at() : no icon created");
        }
#endif
    }
    else
    {
        LOGW("disp_list_change_item_at: no label found");
    }
#endif // DISPLAY

    return label;
}

/*-----------------------------------------------------------------------------
  insert a graphical item in the graphical list
  -----------------------------------------------------------------------------*/
NGWinstance *disp_list_insert_item_at(registerItem *item, int idx, char const *text, void *data, uint8_t fontid)
{
    NGWinstance *list   = item->objId;
    NGWinstance *label  = NULL;
#ifdef DISPLAY
    NGGsize      label_margin = {0, 0};
    NGWPdata     label_offset_y = 0;

    int          ret;

    LOGD("disp_list_insert_item_at(idx=%d, text=\"%s\", icon=%s (%d)\n",
           idx, text ? text : "(no text)", data ? "yes" : "no", data ? *(uint16_t *)data : 0);

    label = ngwNew(global_w_ctx, "NGWalcLabel");
    if (NULL == label)
    {
        LOGE("disp: ngwNew failed");
    }

    // insertion dans la liste
    ret = ngwListInsertAt(list, idx, label, text);
    if (NG_EOK > ret)
    {
//XTScf01037+
        char error_msg[64];

        ngwDestroy(label);
        label = NULL;
        sprintf(error_msg, "disp:ngwListInsertAt(idx=%d) failed, error %d", idx, ret);
        LOGD(error_msg);
    }
    else
    {
        disp_i_setprop(label, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_NONE);
        disp_i_setprop(label, NGWP_TRANSPARENT, (NGWPdata)1);

        int32_t xor_color_text = skinsinfo_get_rgbtext(ID_CURR_SKIN, ID_RGBTEXT_LISTS) ^ 0xffffff;
        disp_i_setprop(label, NGWP_TEXT_BLINK_COLOR, (NGWPdata)xor_color_text);

        disp_i_setprop(label, NGWP_MARGIN, (NGWPdata)&label_margin);

        // mise a jour des proprietes du label
        if (NULL != text)
        {
#if defined(CYRILLIC) || defined(GREC)
            text = u_convert(text);
#endif

            disp_i_setTexte(label, (char**)&text); // ON VIOLE LE CONST!!!
        }
        if (NULL != data)
        {
            /* use new API for blinking icons */
            disp_i_iconCreate(item, *(uint16_t *)data, label, NGWP_IMAGE, 0);
        }

        disp_i_setprop(label, NGWP_SIZE_HEIGHT, (NGWPdata)
                       disp_i_get_row_height(item, item->height));

        disp_i_setprop(label, NGWP_ALC_TEXT_ENHANCEMENT, (NGWPdata)1);
        disp_i_setFont(label, fontid);
    }

    if (DEBUG)
    {
        NGWPdata data1;
        ngwGetProp(list, NGWP_LIST_COUNT, &data1);
        LOGD("NGWP_LIST_COUNT=%d", (int)data1);
    }
#endif // DISPLAY

    return label;
}

