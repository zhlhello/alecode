/*****************************************************************************
 * NexGenGRAPH Decoder v1.4
 * NexGen image source file
 * Created with Conv2ng 2004-04-15
 *----------------------------------------------------------------------------
 *    Copyright (c) 1998-2004 NexGen Software.
 *
 *    All rights reserved. NexGen Software' source code is an
 *  unpublished work and the use of a copyright notice does not imply
 *  otherwise.  This source code contains confidential, trade secret
 *  material of NexGen Software. Any attempt or participation in
 *  deciphering, decoding, reverse engineering or in any way altering
 *  the source code is strictly prohibited, unless the prior written
 *  consent of NexGen Software is obtained.
 *
 *    This software is supplied under the terms of a license agreement
 *  or nondisclosure agreement with NexGen Software, and may not be
 *  copied or disclosed except in accordance with the terms of that
 *  agreement.
 *
 *----------------------------------------------------------------------------
 * 22/09/2004 - NexGen Software
 *****************************************************************************/

#include <ngos.h>
#include <nggraph/grtypes.h>


/* Declarations to include in your header to use an NGGanim/NGGimage/NGGbitmap 
 * are given below :
 */
/* 
 * const NGGimage skin_err;
 */



/*------ Begin of frame1 ------*/


static const NGushort skin_err_data[] = {
0xffff,0xffff,
0xffff,0xffff,
};

const NGGimage skin_err={
NGG_IMAGE_COLOR_A4R4G4B4,
0,
{2, 2},
0x00000000,
0,
NULL,
0,
NULL,
4,
(NGubyte *)skin_err_data
};




/*----------- End of frame1 ------------*/


