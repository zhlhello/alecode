/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/29 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include "stdinc.h"
#include "log.h"
#include "objmgr.h"

#include <stdio.h>
#include <stddef.h>
#include <stdlib.h>
#include <arpa/inet.h>
#if defined(DISPLAY)

#define JPEG_ENABLED

#include <ngdecode.h>
#include <nggcfg.h>

#include "configs.h"
#include "rofs.h"
#include "display.h"
#include "../disp_priv.h"
#include "noep/class_defs.h"

/* valeur spéciale: <-> à la fin de l'image */
#define NG_REFRESH_OFFSET    0

/* size max of a decoded image (3 octets/pixel?) */
#define NG_SIZE_MAX_IMAGE  1710000  // : For AOM, max size should be greater than 50000 854*480*4= 1536000 + security buffer

#define NB_FRAME_ANIMATION  10

/* Decoders and filters */
static NGDecoder    mydecoder;
static NGFilterPNG  myfilterpng;
#ifdef JPEG_ENABLED
static NGFilterJPEG myfilterjpeg;
#endif

static int nb_frame; /* > 1 for gif animated only !! */

#if defined(FEATURE_DIRECTFB) && defined(FEATURE_GALDRIVER)
#  error "define only FEATURE_DIRECTFB or only FEATURE_GALDRIVER"
#endif

/*-----------------------------------------------------------------------------
  Display an NGGimage image

  retourne la fenetre qui contient l'image
  l'image peut etre NULL suite a une erreur de creation, auquel cas on
  retourne une fenetre vide
  ---------------------------------------------------------------------------*/
NGWinstance *disp_w_image(const NGGimage *imgObj,
                          NGWinstance *conteneur,
                          const char *comment)
{
    NGWinstance   *w, *img;
    char buf[100];

    if (NULL == conteneur)
    {
        sprintf(buf, "window for %s", comment);
        w= disp_w_window(buf);
    }
    else
    {
        w= conteneur;
    }

    /* la fenetre va être remplie cachée: */
    disp_i_setprop(w, NGWP_HIDDEN,       (NGWPdata) 1);

    img= ngwCreate(global_w_ctx, "NGWimage", w);
    if (NULL == img)
    {
        LOGE("Create(img) FAILED");
        return NULL;
    }

    disp_i_setprop(img, NGWP_MOTIF_BORDER, (NGWPdata)"");

    if (imgObj != NULL)
    {
        disp_i_setprop(img, NGWP_IMAGE,        (NGWPdata)imgObj);
    }

    /* on démasque la fenètre: */
    disp_i_setprop(w, NGWP_HIDDEN,       (NGWPdata) 0);

    return w;
}

/*-----------------------------------------------------------------------------
  Utility function for displaying a PNG image

   - memory allocator -
  ---------------------------------------------------------------------------*/

static NGGframe     *imgPtr;
//XTSce29330+
static bool_t       b_process_error = FALSE;
//XTSce29330-

static int alloc_4_dest(void *ctx, NGuint size, int *mode, void **ptr)
{
    ((void) ctx); /* for lint warning unused */
    ((void) mode);

    /* Ce qui est alloué, c'est une zone pour un objet NGGanim.
     * C'est plus que pour l'image seule.
     */
    *ptr= pw_malloc(size);

    //syslog(FLUX_DISPLAY, LOG_DEBUG, "malloc %u bytes at %p", size, *ptr);

    nb_frame++;
    return NG_EOK;
}


#if defined(FEATURE_USE_GPU)
#  if defined(FEATURE_DIRECTFB)
extern void      nglnxdfb_image_free (NGGimage *image);
extern NGGimage *nglnxdfb_image_alloc(NGGimage *image);
#  endif
#  if defined(FEATURE_GALDRIVER)
extern void      nglnxgal_image_free (NGGimage *image);
extern NGGimage *nglnxgal_image_alloc(NGGimage *image);
#  endif
#endif


void disp_w_image_free(NGGimage *image)
{
#if defined(FEATURE_USE_GPU)
    if (image->gpu_data != NULL)
    {
#  if defined(FEATURE_DIRECTFB)
        nglnxdfb_image_free(image);
#  endif
#  if defined(FEATURE_GALDRIVER)
        nglnxgal_image_free(image);
#  endif
    }
    else
#endif
    {
        unsigned char *ptr = (unsigned char *)image;
        if (ptr)
        {
            ptr = ptr - offsetof(NGGframe, frame_data) - sizeof(void *);
            pw_free(ptr);
        }
    }
}

/*-----------------------------------------------------------------------------
  Utility function for displaying a PNG image

   - event analyser -
  ---------------------------------------------------------------------------*/

int inform_event(NGGframe *target, void *ctx, unsigned int event)
{
    objmgr_item_t *item = (objmgr_item_t *)ctx;
    NGWinstance *self = NULL;
//XTSce29330+
    b_process_error = FALSE;
//XTSce29330-

    if (NULL != ctx)
    {
        self = (NGWinstance *)PRIV->objId;
    }

    switch(event)
    {
    case NG_DECODE_DONE :
        if (NULL != self) {
            ngwSetProp(self, NGWP_IMAGE_EVENT_DONE, (NGWPdata)target);
        }
        //syslog(FLUX_DISPLAY, LOG_DEBUG, "decoding done for the current image");
        imgPtr= target;
        break;
    case NG_DECODE_REFRESH :
        if (NULL != self) {
            ngwSetProp(self, NGWP_IMAGE_EVENT_REFRESH, (NGWPdata)target);
        }
        //syslog(FLUX_DISPLAY, LOG_DEBUG, "refresh the current frame");
        break;
    case NG_DECODE_ABORT :
        if (NULL != self) {
            ngwSetProp(self, NGWP_IMAGE_EVENT_ABORT, (NGWPdata)target);
        }
        LOGE("abort processing\n");
//XTSce29330+
        b_process_error = TRUE;
//XTSce29330-
        break;
    case NG_DECODE_ERROR :
        if (NULL != self) {
            ngwSetProp(self, NGWP_IMAGE_EVENT_ERROR, (NGWPdata)target);
        }
        LOGE("error processing\n");
//XTSce29330+
        b_process_error = TRUE;
//XTSce29330-
        break;
    case NG_DECODE_NEWFRAME :
        // sauver le pointeur dans l'objet w_imagebox
        if (NULL != item && C_imagebox == item->objtype)
        {
            // liberer un eventuel ancien pointeur non NULL
            if (NULL != PRIV->data)
            {
                pw_free(PRIV->data);
                //syslog(FLUX_DISPLAY, LOG_DEBUG, "freeing %p of old frame", PRIV->data);
            }

            PRIV->data = target;
        }

        if (NULL != self) {
            ngwSetProp(self, NGWP_IMAGE_EVENT_NEWFRAME, (NGWPdata)target);
        }
        imgPtr= target;
        //syslog(FLUX_DISPLAY, LOG_DEBUG, "width= %d height= %d",
        //    imgPtr->frame_data->img_size.w,
        //    imgPtr->frame_data->img_size.h
        //);
        break;
    default:
        LOGE("unknown event %d\n", event);
        break;
    }

    return NG_EOK;
}

void nggHeaderFormat (NGGimage * pMemImage)
{
    pMemImage -> img_type      = ntohl (pMemImage -> img_type);
    pMemImage -> img_flags     = ntohl (pMemImage -> img_flags);
    pMemImage -> img_size.w    = ntohs (pMemImage -> img_size.w);
    pMemImage -> img_size.h    = ntohs (pMemImage -> img_size.h);
    pMemImage -> img_trans     = ntohl (pMemImage -> img_trans);
    pMemImage -> img_ncolors   = ntohl (pMemImage -> img_ncolors);
    pMemImage -> img_palette   = NULL;
    pMemImage -> img_mask_bpl  = 0;
    pMemImage -> img_mask_data = NULL;
    pMemImage -> img_bpl       = ntohl (pMemImage -> img_bpl);
    pMemImage -> img_data      = NULL;

    //syslog(FLUX_DISPLAY, LOG_DEBUG, "img_type %d",    pMemImage->img_type   );
    //syslog(FLUX_DISPLAY, LOG_DEBUG, "img_flags %d",   pMemImage->img_flags  );
    //syslog(FLUX_DISPLAY, LOG_DEBUG, "img_size.w %d",  pMemImage->img_size.w );
    //syslog(FLUX_DISPLAY, LOG_DEBUG, "img_size.h %d",  pMemImage->img_size.h );
    //syslog(FLUX_DISPLAY, LOG_DEBUG, "img_trans %d",   pMemImage->img_trans  );
    //syslog(FLUX_DISPLAY, LOG_DEBUG, "img_ncolors %d", pMemImage->img_ncolors);
    //syslog(FLUX_DISPLAY, LOG_DEBUG, "img_bpl %d",     pMemImage->img_bpl    );
}

extern NGmemheap wdk_img_mh;

static NGGimage *__disp_decode(
    objmgr_item_t       *item,
    const unsigned char *ptrImg,
    unsigned int         sizeImg,
    unsigned int         format,
    bool_t               gpu_support
)
{
    static NGGpixval (*color_to_pixval_f)(NGGcolor *pal, NGGcolor *c);

    int             output_format;
    int             res;
    const NGGcolor *palette;
    int             palette_size;

    if ((format != IMAGE_FORMAT_PNG) && (format != IMAGE_FORMAT_JPEG))
    {
        LOGE("disp_decode - wrong input format: %d\n", format);
        return NULL;
    }

    output_format     = NGG_IMAGE_COLOR_A8R8G8B8;
    color_to_pixval_f = &nggrColorToPixvalA8R8G8B8;
    palette           = NULL;
    palette_size      = 0;

    // Decoder Init
    if (format == IMAGE_FORMAT_PNG)
    {
        res = ngdDecoderPNGInit(
            &mydecoder,
            &wdk_img_mh,
            NG_REFRESH_OFFSET,
            NG_SIZE_MAX_IMAGE,
            output_format,
            color_to_pixval_f,
            (NGGcolor *)palette,
            palette_size
        );
    }
    else
    if (format == IMAGE_FORMAT_JPEG)
    {
        res = ngdDecoderJPEGInit(
            &mydecoder,
            &wdk_img_mh,
            NG_REFRESH_OFFSET,
            NG_SIZE_MAX_IMAGE,
            output_format,
            color_to_pixval_f,
            (NGGcolor *) palette,
            palette_size
        );
    }

    if (NG_EOK != res)
    {
        LOGE("disp_decode - decoder init failed: %d\n", res);
        return NULL;
    }

    // Filter Init
    if (format == IMAGE_FORMAT_PNG)
    {
        res = ngdFilterPNGInit(
            &myfilterpng,
            &mydecoder,
            alloc_4_dest,
            NULL,
            inform_event,
            item,
            NG_FILTER_NONE
        );
    }
    else
    if (format == IMAGE_FORMAT_JPEG)
    {
        res = ngdFilterJPEGInit(
            &myfilterjpeg,
            &mydecoder,
            alloc_4_dest,
            NULL,
            inform_event,
            item,
            NG_FILTER_NONE
        );
    }

    if (NG_EOK != res)
    {
        LOGE("disp_decode - filter init failed: %d\n", res);
        return NULL;
    }

    nb_frame = 0;

    // Filter Input
    if (format == IMAGE_FORMAT_PNG)
    {
        res = ngdFilterInputData(&myfilterpng, ptrImg, sizeImg);
        ngdFilterDone(&myfilterpng);
    }

    else
    if (format == IMAGE_FORMAT_JPEG)
    {
        res = ngdFilterInputData(&myfilterjpeg, ptrImg, sizeImg);
        ngdFilterDone(&myfilterjpeg);
    }

    // Return Output Image
    if ((imgPtr == NULL) || (b_process_error == TRUE))
    {
        b_process_error = FALSE;
        return NULL;
    }

    // ImgPtr is a pointer to an NGGframe.
    // Field frame_data of NGGframe is a pointer to the real NGGImage data,
    // which in fact is stored immediately after the pointer
    //
    //  @malloc
    //    |
    //    V
    // +---------------------------------------------------+
    // |                    malloc'ed zone                 |
    // +-------------------------------------+-------------+
    // |          NGGFrame                   | NGGImage    |
    // +-------------------------------------+             |
    // | various fields          |frame_data |             |
    // +-------------------------+-----------+-------------+
    //                                |         ^
    //                                |         |
    //                                +---------+
    //                                          ^
    //                                          |
    //                                       returned
    //
    // What is returned is the address of the NGGImage.
    // So to free the struture you have to free
    //    returned ptr - offsetof(NGGframe, frame_data) - sizeof(void*)

    //     syslog(FLUX_DISPLAY, LOG_DEBUG,
    //            "ImagePng: return %p (imgPtr=%p) @frame_data=%p", imgPtr -> frame_data, imgPtr, &(imgPtr->frame_data));

#if (NGG_ALPHA_PREMULT_SRC == 1)
    if ((imgPtr->frame_data->img_flags & NGG_CPY_TRANSPARENT) && (imgPtr->frame_data->img_type == NGG_IMAGE_COLOR_A8R8G8B8)) {
        int     i;
        NGuint *s = (NGuint *)imgPtr->frame_data->img_data;

        for(i = 0 ; i < (imgPtr->frame_data->img_size.w * imgPtr->frame_data->img_size.h) ; i++, s++)
            *s = nggrImgA8R8G8B8Premult(*s);
    }
#endif

    if (gpu_support)
    {
        NGGimage *result = NULL;
#if defined(FEATURE_DIRECTFB)
        result = nglnxdfb_image_alloc(imgPtr->frame_data);
#endif
#if defined(FEATURE_GALDRIVER)
        result = nglnxgal_image_alloc(imgPtr->frame_data);
#endif
        free(imgPtr);
        return result;
    }
    else
    {
        return imgPtr->frame_data;
    }
}


//
// image creation with support of gpu
//
NGGimage *disp_decode(
    objmgr_item_t       *item,
    const unsigned char *ptrImg,
    unsigned int         sizeImg,
    unsigned int         format
)
{
    bool_t gpu_support = FALSE;
#if defined(FEATURE_USE_GPU)
    extern int ngVidDrv_use_gpu();
    gpu_support = ngVidDrv_use_gpu();
#endif
    return __disp_decode(item, ptrImg, sizeImg, format, gpu_support);
}

#define FILENAME_MAX_LEN _MAX_FILENAME_LEN_

//                 123456
//                 img_x_
#define PREFIX_LEN 6

//                 1234
//                 .png
#define SUFFIX_LEN 5

static NGGimage *__disp_i_load_image(rofs_rsc_t rsctype, char *imagename)
{
    FILE_t   *file;
    NGGimage *ret;
    char      name[FILENAME_MAX_LEN];
    char      model = 'a';


    unsigned int format = IMAGE_FORMAT_PNG;

    char   *ptr      = imagename;
    bool_t  with_ext = FALSE;

    while(*ptr ) {
        if (*ptr == '.') {
            if (strcasecmp(ptr, ".png") == 0) {
                with_ext = TRUE;
                break;
            }
        }
        ptr++;
    }

    if (with_ext)
        sprintf(name, "img_%c_%s"    , model, imagename);
    else
        sprintf(name, "img_%c_%s.png", model, imagename);

    file = rofs_open(rsctype, name);
    if (file == NULL)
    {
        LOGE("file %s not found !", name);
        return NULL;
    }

    ret = disp_decode(
        NULL, rofs_faddr(file), rofs_fsize(file), format
    );

    rofs_close(file);
    return ret;
}

NGGimage *disp_i_load_image(char *imagename)
{
    return __disp_i_load_image(ROFS_RSC_IMAGE,imagename);
}

NGGimage *disp_i_load_boot_image(char *imagename)
{
    return __disp_i_load_image(ROFS_RSC_BOOTIMAGE, imagename);
}


//XTScf01037+
bool_t getNGGimage (char     * pImageName,
                    NGGimage * pNGGimage)
{
    FILE_t * _pFile;
    char     _name [FILENAME_MAX_LEN];
    char *   addr;
    char     model = 'a';

    sprintf (_name, "img_%c_%s.ngg", model, pImageName);

    _pFile = rofs_open (ROFS_RSC_IMAGE, _name);
    if (_pFile == NULL)
        return FALSE;

    addr = (char *)rofs_faddr (_pFile);
    if (addr == NULL){
	rofs_close(_pFile);
    	return FALSE;
    }
    else{

	memcpy (pNGGimage, addr, sizeof (NGGimage));
	nggHeaderFormat (pNGGimage);
	pNGGimage -> img_data = (NGubyte *) (rofs_faddr (_pFile) + sizeof (NGGimage));

	rofs_close(_pFile);
	return TRUE;
    }
}
//XTScf01037-

#endif /* DISPLAY */

