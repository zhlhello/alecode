/*-----------------------------------------------------------------------------
   DESCRIPTION:    skins information file

    skininfo.txt

    #
    # mandatory
    # utf-8 string
    # no default value
    #
    # Skin name (displayed in usermenu)
    #
    skin-name=

    #
    # mandatory
    # integer (0..MAX_SKINSBASE-1)
    # no default value
    #
    # Default skin on which this one is build
    #
    base-skin=

    #
    # mandatory
    # integer (0..MAX_ICONSSET-1)
    # no default value
    #
    # ions set to use
    #
    icons-set=

    #
    # optional
    # boolean (yes or no)
    # default value = no
    #
    # images for the screensaver (slideshow)
    #
    slideshow=no

    #
    # optional
    # hexadecimal (0xrrggbb)
    # default value = 0x000000 (black)
    #
    # colors definition for labels
    #
    #rgbtext-homebar=0x000000
    #rgbtext-tabs=0x000000
    #rgbtext-tabs-selected=0x000000
    #rgbtext-lists=0x000000
    #rgbtext-labels=0x000000
    #rgbtext-inputbox=0x000000
    #rgbtext-timerbox=0x000000
-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/26 jerryzh
    Take from NOE for AoM project.
    
-----------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#if !defined(strcasestr)
extern char *strcasestr(const char *haystack, const char *needle);
#endif
#include <ctype.h>
#include <limits.h>

#include "stdinc.h"
#include "log.h"
#include "configs.h"
#include "rofs.h"

#include "skins.h"

/*-----------------------------------------------------------------------------
  C O N S T A N T S
  ---------------------------------------------------------------------------*/
#define RGBTEXT_DEFAULT (0x000000)

#define V_SKINNAME      (0x0001)
#define V_BASESKIN      (0x0002)
#define V_ICONSSET      (0x0004)
#define V_SLIDESHOW     (0x0008)
#define V_RGBTEXT(i)    (0x0010 << i)

#define M_REQUIRED      (V_SKINNAME | V_BASESKIN | V_ICONSSET)
#define REQUIRED(v)     ((v & M_REQUIRED) == M_REQUIRED)

#define K_SKINNAME      "skin-name="
#define K_BASESKIN      "base-skin="
#define K_ICONSSET      "icons-set="
#define K_SLIDESHOW     "slideshow="
#define K_RGBTEXT       "rgbtext-"

/*-----------------------------------------------------------------------------
  R G B T E X T
  ---------------------------------------------------------------------------*/
struct s_rgbtext {
    rgbtext_t  id;
    char      *key;
};

static struct s_rgbtext rgbtexts[] = {
    { ID_RGBTEXT_HOMEBAR                , "homebar"                 },
    { ID_RGBTEXT_TABS                   , "tabs"                    },
    { ID_RGBTEXT_TABS_SEL               , "tabs-selected"           },
    { ID_RGBTEXT_LISTS                  , "lists"                   },
    { ID_RGBTEXT_LABELS                 , "labels"                  },
    { ID_RGBTEXT_INPUTBOX               , "inputbox"                },
    { ID_RGBTEXT_TIMERBOX               , "timerbox"                },
    { ID_RGBTEXT_SMARTADDON             , "smartaddon"              },
    { ID_RGBTEXT_HIGHLIGHTED_ITEMS      , "highlighted-items"       },
    { ID_RGBTEXT_HIGHLIGHTED_ITEMS_LABEL, "highlighted-items-label" },
    { ID_RGBTEXT_CURSOR                 , "cursor" },
    { ID_INVALID                        , NULL                      }
};

/*-----------------------------------------------------------------------------
  T Y P E D E F S
  ---------------------------------------------------------------------------*/
typedef struct {
    uint32_t  validmsk;
    char     *skinname;
    uint32_t  baseskin;
    uint32_t  iconsset;
    bool_t    slideshow;
    uint32_t  rgbtext[MAX_RGBTEXT];
} skininfo_t;


/*-----------------------------------------------------------------------------
  P R I V A T E  V A R I A B L E S
  ---------------------------------------------------------------------------*/
static skininfo_t skininfos[MAX_SKINS] = {};


/*-----------------------------------------------------------------------------
  P R I V A T E  A P I
  ---------------------------------------------------------------------------*/
static char *trim(char *str)
{
    char *end;

    // Trim leading space
    while(isspace((unsigned char)*str))
        str++;

    if (*str == 0)  // All spaces?
        return str;

    // Trim trailing space
    end = str + strlen(str) - 1;
    while(end > str && isspace((unsigned char)*end))
        end--;

    // Write new null terminator
    *(end + 1) = 0;

    return str;
}

static char *__searchkey(const char *line, const char *key)
{
    char *s = strcasestr(line, key);
    if (s) {
        s = s + strlen(key);
        if (strlen(s))
            return s;
    }
    return NULL;
}

static void __parseline(skininfo_t *skininfo, const char *line)
{
    int   i;
    char *str, *endptr;

    if (line[0] == '#')
        return;

    str = __searchkey(line, K_SKINNAME);
    if (str) {
        skininfo->skinname  = strdup(str);
        skininfo->validmsk |= V_SKINNAME;
    }

    str = __searchkey(line, K_BASESKIN);
    if (str) {
        uint32_t val  = strtol(str, &endptr, 10);
        if (str != endptr) {
            if (val < MAX_SKINSBASE) {
                skininfo->baseskin  = val;
                skininfo->validmsk |= V_BASESKIN;
            }
        }
    }

    str = __searchkey(line, K_ICONSSET);
    if (str) {
        uint32_t val = strtol(str, &endptr, 10);
        if (str != endptr) {
            if (skininfo->iconsset < MAX_ICONSSET) {
                skininfo->iconsset  = val;
                skininfo->validmsk |= V_ICONSSET;
            }
        }
    }

    str = __searchkey(line, K_SLIDESHOW);
    if (str) {
        skininfo->slideshow = FALSE;
        if (strcasecmp(str, "no" ) == 0)
            skininfo->slideshow = FALSE;
        else
        if (strcasecmp(str, "yes") == 0)
            skininfo->slideshow = TRUE;
        skininfo->validmsk  |= V_SLIDESHOW;
    }

    for(i = 0 ; ((i < MAX_RGBTEXT) && (rgbtexts[i].key != NULL)) ; i++) {
        char key[128];
        sprintf(key, "%s%s=", K_RGBTEXT, rgbtexts[i].key);
        str = __searchkey(line, key);
        if (str) {
            uint32_t val = strtol(str, &endptr, 16);
            if (str != endptr) {
                if (val <= 0xffffff) {
                    uint32_t id = rgbtexts[i].id;
                    if (id < MAX_RGBTEXT)
                    {
                        skininfo->rgbtext[id] = val;
                        skininfo->validmsk   |= V_RGBTEXT(id);
                    }
                }
            }
        }
    }
}

static void __reset(skininfo_t * skininfo)
{
    int i;
    if (skininfo->skinname)
        free(skininfo->skinname);
    memset(skininfo, 0, sizeof(skininfo_t));
    for(i = 0 ; i < MAX_RGBTEXT ; i++)
        skininfo->rgbtext[i] = RGBTEXT_DEFAULT;
}

static void __loadfile(int32_t id)
{
    FILE       *file           = NULL;
    char        name[PATH_MAX] = "";
    char        line[LINE_MAX] = "";
    skininfo_t *skininfo       = (skininfo_t *)&skininfos[id];

    __reset(skininfo);

    if(id == ID_SKIN_CUST) {
        rofs_make_path(name, ROFS_RSC_SKININFO, "skininfo.txt", TRUE);
    } else {
        char filename[25] = "";
        sprintf(filename, "%d/%s", id , "skininfo.txt");
        rofs_make_path(name, ROFS_RSC_SKININFO, filename, FALSE);
    }

    file = fopen(name, "r");
    if (file == NULL) {
        LOGI("skininfo: %s not found!", name);
        return;
    }

    while(fgets(line, LINE_MAX, file) != NULL)
        __parseline(skininfo, trim(line));

    if (! REQUIRED(skininfo->validmsk))
        skininfo->validmsk = 0;

    fclose(file);
}


static int32_t __convertid(int32_t id)
{
    if (id == ID_CURR_SKIN)
        id = (CONFIG_get_use_customisation() ? ID_SKIN_CUST : CONFIG_get_skin_id());
    return id;
}


/*-----------------------------------------------------------------------------
  P U B L I C  A P I
  ---------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
  load (or reload) skins information files
  ---------------------------------------------------------------------------*/
void skinsinfo_init()
{
    int32_t id;
    for(id = 0 ; id < MAX_SKINS ; id++)
        skinsinfo_load(id);
}

#define CONVERT(id) id = __convertid(id)

/*-----------------------------------------------------------------------------
  load specified skin information file
  ---------------------------------------------------------------------------*/
void skinsinfo_load(int32_t id)
{
    CONVERT(id);
    if (id < MAX_SKINS)
        __loadfile(id);
}

/*-----------------------------------------------------------------------------
  returns skinsinfo validity
  ---------------------------------------------------------------------------*/
bool_t skinsinfo_is_valid(int32_t id)
{
    CONVERT(id);
    if (id < MAX_SKINS)
        return skininfos[id].validmsk;
    return FALSE;
}

/*-----------------------------------------------------------------------------
  returns TRUE if cust skin
  ---------------------------------------------------------------------------*/
bool_t skinsinfo_is_custskin(int32_t id)
{
    CONVERT(id);
    if (skinsinfo_is_valid(id))
        return (id == ID_SKIN_CUST);
    return FALSE;
}

/*-----------------------------------------------------------------------------
  getter: skin name
  ---------------------------------------------------------------------------*/
const char *skinsinfo_get_skinname(int32_t id)
{
    CONVERT(id);
    if (skinsinfo_is_valid(id))
        return skininfos[id].skinname;
    return NULL;
}

/*-----------------------------------------------------------------------------
  getter: base skin
  ---------------------------------------------------------------------------*/
int32_t skinsinfo_get_baseskin(int32_t id)
{
    CONVERT(id);
    if (skinsinfo_is_valid(id))
        return skininfos[id].baseskin;
    return INVALID_BASESKIN;
}

/*-----------------------------------------------------------------------------
  getter: icons set
  ---------------------------------------------------------------------------*/
int32_t skinsinfo_get_iconsset(int32_t id)
{
    CONVERT(id);
    if (skinsinfo_is_valid(id))
        return skininfos[id].iconsset;
    return INVALID_ICONSSET;
}

/*-----------------------------------------------------------------------------
  getter: text color
  ---------------------------------------------------------------------------*/
int32_t skinsinfo_get_rgbtext(int32_t id, rgbtext_t rgbtext)
{
    CONVERT(id);
    if (skinsinfo_is_valid(id) && (rgbtext < MAX_RGBTEXT))
        return skininfos[id].rgbtext[rgbtext];
    return RGBTEXT_DEFAULT;
}

/*-----------------------------------------------------------------------------
  getter: text color name
  ---------------------------------------------------------------------------*/
char *skinsinfo_get_rgbtext_name(rgbtext_t id)
{
    int i;
    for(i = 0 ; (rgbtexts[i].key != NULL) ; i++)
        if (rgbtexts[i].id == id)
            return rgbtexts[i].key;
    return "unknown";
}

/*-----------------------------------------------------------------------------
  getter: has images for slideshow (screensaver)
  ---------------------------------------------------------------------------*/
bool_t skinsinfo_has_slideshow(int32_t id)
{
    CONVERT(id);
    if (skinsinfo_is_valid(id))
        return skininfos[id].slideshow;
    return FALSE;
}