/*--------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         arabic.c

   DATED:          2009/12/7

   AUTHOR:         Qiaos

   DESCRIPTION:    Arabic characters mapping and reverse

   HISTORY:

      - creation   2009/12/7
        For Arabic requirement.

      - 2009/12/28 xiaodoay
        crms00179838 error building NOE host version

      - crms00206375 2010/1/8
        remove restrictions on Arabic/Hebrew RTL display

      - crms00222686 2010/3/31
        OXE R9.1 & Arabic strings : a specific character is added randomly in
        existing strings

      - 2016/08/10 Anne li
        crqms00202831 : [NOE3G R100][Hebrew_IME]:Requirement/Tech decision
        change: The arrow reverse/Content position change should be done on
        terminal side.

      - 2016/08/10 Anne li
        crqms00200514 : [NOE3G R100][Hebrew_IME]:In some scenes, Hebrew characters
        are displayed garbled

      - 2016/08/10 Anne li
        crqms00201813 :OXO_Hebrew: Left <- arrow is missing if call log page's
        specific call's details page is selected

      - 2016/09/06 Shilong han
        crqms00202857 :[NOE3G R100][Hebrew_IME]:Requirement/Tech decision
        change: Date/time/Name position change in calllog/IM/VM logs implementation
        on terminal side.

      - 2016/09/13 Shilong han
        crqms00204663 :[NOE3G R100][Hebrew]Hebrew name call log with
        'name+date+time+icon' is wrongly format

      - 2016/09/14 Shilong han
        crqms00204994 : [NOE3G R100][Hebrew]Memory leak lead phone reset

      - 2016/09/28 Anne Li
        crqms00205987 : [NOE3G R100][Hebrew]Black triangle should not be reversed
        in terminal side.

      - 2016/09/29 Shilong Han
        crqms00205908 : [Hebrew] Missed call log display format is wrong in
        NOE-3G TDM Sets.

      - 2017/03/16 Anne Li
        CR8018NOE-126  : [Hebrew] support: The arrow mark is reversed in IM log.
-----------------------------------------------------------------------------*/
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include "arabic.h"
//#include "thales.h"

/*This is Case 1 Arabic input-disp map table, including 4 status, 0 unexist*/
static w_char arabic_case1_map_table[][4]=
{
    /*INITIAL, MEDIAL, FINAL, ISOLATED*/
    {0,0,0,0xFE80},                 /*0x0621*/
    {0,0,0xFE82,0xFE81},            /*0x0622*/
    {0,0,0xFE84,0xFE83},            /*0x0623*/
    {0,0,0xFE86,0xFE85},            /*0x0624*/
    {0,0,0xFE88,0xFE87},            /*0x0625*/
    {0xFE8B,0xFE8C,0xFE8A,0xFE89},  /*0x0626*/
    {0,0,0xFE8E,0xFE8D},            /*0x0627*/
    {0xFE91,0xFE92,0xFE90,0xFE8F},  /*0x0628*/
    {0,0,0xFE94,0xFE93},            /*0x0629*/
    {0xFE97,0xFE98,0xFE96,0xFE95},  /*0x062A*/
    {0xFE9B,0xFE9C,0xFE9A,0xFE99},  /*0x062B*/
    {0xFE9F,0xFEA0,0xFE9E,0xFE9D},  /*0x062C*/
    {0xFEA3,0xFEA4,0xFEA2,0xFEA1},  /*0x062D*/
    {0xFEA7,0xFEA8,0xFEA6,0xFEA5},  /*0x062E*/
    {0,0,0xFEAA,0xFEA9},            /*0x062F*/
    {0,0,0xFEAC,0xFEAB},            /*0x0630*/
    {0,0,0xFEAE,0xFEAD},            /*0x0631*/
    {0,0,0xFEB0,0xFEAF},            /*0x0632*/
    {0xFEB3,0xFEB4,0xFEB2,0xFEB1},  /*0x0633*/
    {0xFEB7,0xFEB8,0xFEB6,0xFEB5},  /*0x0634*/
    {0xFEBB,0xFEBC,0xFEBA,0xFEB9},  /*0x0635*/
    {0xFEBF,0xFEC0,0xFEBE,0xFEBD},  /*0x0636*/
    {0xFEC3,0xFEC4,0xFEC2,0xFEC1},  /*0x0637*/
    {0xFEC7,0xFEC8,0xFEC6,0xFEC5},  /*0x0638*/
    {0xFECB,0xFECC,0xFECA,0xFEC9},  /*0x0639*/
    {0xFECF,0xFED0,0xFECE,0xFECD},  /*0x063A*/
    {0xFED3,0xFED4,0xFED2,0xFED1},  /*0x0641*/
    {0xFED7,0xFED8,0xFED6,0xFED5},  /*0x0642*/
    {0xFEDB,0xFEDC,0xFEDA,0xFED9},  /*0x0643*/
    {0xFEDF,0xFEE0,0xFEDE,0xFEDD},  /*0x0644*/
    {0xFEE3,0xFEE4,0xFEE2,0xFEE1},  /*0x0645*/
    {0xFEE7,0xFEE8,0xFEE6,0xFEE5},  /*0x0646*/
    {0xFEEB,0xFEEC,0xFEEA,0xFEE9},  /*0x0647*/
    {0,0,0xFEEE,0xFEED},            /*0x0648*/
    {0,0,0xFEF0,0xFEEF},            /*0x0649*/
    {0xFEF3,0XFEF4,0xFEF2,0xFEF1}   /*0x064A*/
};

/*This is Case 2 Arabic input-disp map table, including 4 status, 0 unexist*/
static w_char arabic_case2_map_table[][4]=
{
    /*space, tatweel, lam_isolated, lam_final*/
    { 0, 0, 0xFEF5, 0xFEF6},        /*0x0622*/
    { 0, 0, 0xFEF7, 0xFEF8},        /*0x0623*/
    { 0, 0, 0xFEF9, 0xFEFA},        /*0x0625*/
    { 0, 0, 0xFEFB, 0xFEFC},        /*0x0627*/
    { 0xfe70, 0xfe71, 0, 0},        /*0x064b*/
    { 0xfe72, 0, 0, 0},             /*0x064c*/
    { 0xfe74, 0, 0, 0},             /*0x064d*/
    { 0xfe76, 0xfe77, 0, 0},        /*0x064e*/
    { 0xfe78, 0xfe79, 0, 0},        /*0x064f*/
    { 0xfe7a, 0xfe7b, 0, 0},        /*0x0650*/
    { 0xfe7c, 0xfe7d, 0, 0},        /*0x0651*/
    { 0xfe7e, 0xfe7f, 0, 0},        /*0x0652*/
};

/*INPUT STRING*/
static char strings[MAX_ARABIC_LINE_LENGTH];
static unsigned int linepos;
/*CURRENT character position*/
static enum POS_STADUS globalPos;
static int line_length;
static int isSpecial(w_char);
static int isspace2(w_char ab_char);
static int istotweel(w_char ab_char);
static int islam(w_char ab_char);

static w_char getCurChar(const char *line);
static w_char getnextchar(const char *line);
static enum POS_STADUS resetglobalpos(enum POS_STADUS pos);
static int isalpha2(w_char c);
//int isControlSymbol(w_char c); //crqms00204663 Shilong
//crms00179838 xiaodoay +
#if !defined(HOST)
extern void dumpHex(const char *, uint8_t *, uint32_t);
#endif
//crms00179838 xiaodoay -

//crms00206375 qiaos+
static int Arabic_Convert_Api_Line(const char* input_ptr, char *output_ptr, int input_length, int *output_length);
//crms00206375 qiaos-

/*The following 3 functions is for case2. space, totweel and lam*/
static int isspace2(w_char ab_char)
{
    return  ab_char== 0x0020;
}

static int istotweel(w_char ab_char)
{
    return ab_char == 0x0640;
}

static int islam(w_char ab_char)
{
    return ab_char == 0x0644;
}

/*The following function is for case 3*/
static int isSpecial(w_char ab_char)
{
    switch(ab_char)
    {
    case 0x060c:
    case 0x061b:
    case 0x061f:
    case 0x0621:
    case 0x0622:
    case 0x0623:
    case 0x0624:
    case 0x0625:
    case 0x0627:
    case 0x062f:
    case 0x0630:
    case 0x0631:
    case 0x0648:
    case 0x0660:
    case 0x0661:
    case 0x0662:
    case 0x0663:
    case 0x0664:
    case 0x0665:
    case 0x0666:
    case 0x0667:
    case 0x0668:
    case 0x0669:
        return TRUE;
        break;
    default:
        return FALSE;
    }
}

/*return the status of current char. isolated, final, medial or initial*/
static enum POS_STADUS getCurrentPos(w_char c, const char *line)
{
    if (isarabic(c))
    {
        switch(globalPos)
        {
            case ISOLATED:
                if (isarabic(getnextchar(line)))
                {
                    globalPos = INITIAL;
                }
                else
                {
                    globalPos = ISOLATED;
                }
                break;
            case INITIAL:
            case MEDIAL:
                if (isarabic(getnextchar(line)) /*|| isspace(getnextchar()) && isarabic(getnnextchar())*/)
                {
                    globalPos = MEDIAL;
                }
                else
                {
                    globalPos = FINAL;
                }
                break;
            case FINAL:
                if (isarabic(getnextchar(line)))
                {
                    globalPos = INITIAL;
                }
                else
                {
                    globalPos = ISOLATED;
                }
                break;
            default:
                break;
        }
    }
    else
    {
        /*Non-arabic characters are set to isolated. Ignore Hebrew*/
        globalPos = ISOLATED;
    }
    return globalPos;
}


int isarabic(w_char c)
{
    if ((c <= 0x06FF && c >= 0x0600)
        || (c <= 0xFEFC && c >= 0xFE70)
        )
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

static int isSymbol(w_char c)
{
    if (((!isalpha2((int)c)) && c >= 0x20 && c <= 0x7f && !isControlSymbol(c)&& c != 0x5c)  //crqms00200514 Anne
            || (c == 0xE0C7)
            || (c == 0xE0C8)
            || (c == 0xE0F6)  //Fix black triangle icon sometimes not displayed issue  crqms00201813 Anne+
            || (c == 0xE0F7)  //Fix black triangle icon sometimes not displayed issue  crqms00201813 Anne+
            || (c == 0xAA)
            || (c == 0xAB))
        return TRUE;
    else
        return FALSE;

}

int isControlSymbol(w_char c) //crqms00204663 Shilong
{
    switch (c)
    {
//crms00206375 qiaos+
    //case 0x006e:/* \n   */
//crms00206375 qiaos-
    case 0x0052:/* \R   */
    case 0x0042:/* \B   */
    case 0x0031:/* \1   */
    case 0x0032:/* \2   */
    case 0x0033:/* \3   */
    case 0x0046:/* \F   */
    case 0x0055:/* \U   */
    case 0x004b:/* \K   */
    case 0x0050:/* \P   */
    case 0x005e:/* \^   */
    case 0x0058:/* \X   */
    case 0x0043:/* \Cxxx*/
        return TRUE;
    default:
        return FALSE;
    }
}

static int isalpha2(w_char c)
{
    if((c>=0x30 && c<=0x39)
    || (c>=0x41 && c<=0x5A)
    || (c>=0x61 && c<=0x7A)
        )
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

static w_char getCurChar(const char *line)
{
    return (w_char)(*((w_char *)(line+linepos)));
}


static w_char getnextchar(const char *line)
{
    if (linepos + 1 < line_length)
        return (w_char)(*((w_char *)(line+linepos+2)));
    else
        return (w_char)0x00;
}

int isArabicOrHebraize(w_char c)
{
    if ((c <= 0x06FF && c >= 0x0600)
     || (c <= 0xFEFC && c >= 0xFE70)
     || (c <= 0x05FF && c >= 0x0500)
    )
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}


//crqms00202831 Anne, shilongh+

//Deal the arrow in pure Latin display to make sure it is accordance with the hebrew reading direction R2L.
//The arrow direction and the contents beside the arrow should changed accordingly.
//For eg "Anne --> Bob" changed to "Bob <-- Anne"
char *reverse_arrow_latin_in_hebrewctx(char *line, int length) //crqms00204663 Shilong
{
    int i;
    char* output = NULL;
    char* output_tmp = NULL ;
    char* line_tmp = NULL ;
    unsigned char c_first, c_second, c_last_second, c_last;

    // a control symbol size is 2
    if (length < 3 || line == NULL) {
        return line;
    }

    c_first = (unsigned char)(*((unsigned char *)(line)));
    c_second = (unsigned char)(*((unsigned char *)(line + 1)));
    c_last_second = (unsigned char)(*((unsigned char *)(line + length - 2)));
    c_last = (unsigned char)(*((unsigned char *)(line + length - 1)));

    if (c_first == 0x5c && isControlSymbol(c_second))
    {
        output = pw_malloc(sizeof(char)*(length+1));
        if (output == NULL)
            return NULL;
        memset(output, 0x00, sizeof(char)*(length+1));

        output_tmp = reverse_arrow_latin_in_hebrewctx((line+2), length-2);

        memcpy(output, &c_first, sizeof(char));
        memcpy((char*)(output + 1), &c_second, sizeof(char));
        memcpy((char*)(output + 2), output_tmp , (length-2)*sizeof(char));

        if (output_tmp != NULL && (output_tmp != (line + 2))) {
            pw_free(output_tmp);
            output_tmp = NULL;
        }

        return output;

    } else if (c_last_second == 0x5c && isControlSymbol(c_last))
    {
        output = pw_malloc(sizeof(char)*(length+1));
        if (output == NULL)
            return NULL;
        memset(output, 0x00, sizeof(char)*(length+1));

        line_tmp = pw_malloc(sizeof(char)*(length-1));
        if (line_tmp == NULL) {
            return NULL;
            pw_free(output);
        }
        memset(line_tmp, 0x00, sizeof(char)*(length-1));

        strncpy(line_tmp, line, length-2);

        output_tmp = reverse_arrow_latin_in_hebrewctx(line_tmp, length-2);

        memcpy(output, output_tmp, (length - 2)*sizeof(char));
        memcpy((char*)(output + length-2), &c_last_second, sizeof(char));
        memcpy((char*)(output + length-1), &c_last , sizeof(char));

//crqms00204994: Fix memory leak +
        if (output_tmp && output_tmp != line_tmp)
        {
            pw_free(output_tmp);
            output_tmp = NULL;
        }
//crqms00204994: Fix memory leak -

        if (line_tmp != NULL) {
            pw_free(line_tmp);
            line_tmp = NULL;
        }
        return output;
    }

    //Find the arrow in string (0xee8387, right arrow-->  , 0xee8388 , left arrow <--)
    for(i = 0; i < length-2; i++)
    {
        unsigned char c, c_next,c_next_next;

        c = (unsigned char)(*((unsigned char *)(line+i)));
        c_next = (unsigned char)(*((unsigned char *)(line+i+1)));
        c_next_next = (unsigned char)(*((unsigned char *)(line+i+2)));

        //If the arrow found (in utf8 format)
        if ((c == 0xee && c_next == 0x83 && (c_next_next == 0x88 || c_next_next == 0x87)))
        {
            unsigned char temp_c;
            output = pw_malloc(sizeof(char)*(length+1));
            if (output == NULL)
                return NULL;
            memset(output, 0x00, sizeof(char)*(length+1));

            //Move the content after the arrow to the start
            memcpy(output, (char *)(line + i + 3), (length - i - 3)*sizeof(char));

            (c_next_next == 0x88) ? (temp_c = 0x87) : (temp_c = 0x88);

            //Change the arrow direction
            memcpy((char*)(output + length - i - 3), &c     , sizeof(char));
            memcpy((char*)(output + length - i - 2), &c_next, sizeof(char));
            memcpy((char*)(output + length - i - 1), &temp_c, sizeof(char));

            //Move the content before arrow to end.
            memcpy((char*)(output + length - i), (char *)line, i*sizeof(char));

            break;
        }

    }

    if (output == NULL) {
        output = pw_malloc(sizeof(char)*(length+1));
        if(output == NULL)
            return NULL;
        memset(output, 0x00, sizeof(char)*(length+1));
        strcpy(output, line);
    }
    return output;
}


// crqms00202857 Shilong +
char *extract_name(const char *line, int date_time_length) {

	int line_len;
    char *name = NULL;
    unsigned char c_last_third, c_last_second;

    if (line == NULL) {
		return (char *)line;
    }

	line_len = strlen(line);

	name = pw_malloc(sizeof(char)* (line_len+1));
    if(name == NULL)
        return NULL;
    memset(name, 0x00, sizeof(char)*(line_len+1));

	if (line == NULL || line_len <= date_time_length || line_len < 4) {
        return name;
    }

	c_last_third = (unsigned char)(*((unsigned char *)(line + line_len - 3)));
	c_last_second = (unsigned char)(*((unsigned char *)(line + line_len - 2)));

    if(c_last_third == 0xee && c_last_second == 0x83) {
//crqms00204663   shilong+
        if ((line_len - date_time_length - 5) >= 0) {
            strncpy(name, line + (date_time_length + 1), (line_len - date_time_length - 5));
        } else {
            strncpy(name, line + (date_time_length + 1), (line_len - date_time_length - 4));
        }
//crqms00204663   shilong-
    } else {
        strcpy(name, line + (date_time_length + 1));
    }

    return name;
}


//crqms00204663   shilong+
char * extract_time(char * str, int length) {
    int hour, min;
    char * t_str;
    char temp_str[512];
    char * result_str = NULL;
    char * p = NULL;

    result_str = pw_malloc(32);
    if(result_str == NULL)
        return NULL;
    memset(result_str, 0x00, 32);

    // time length
    if (! str || length < 5)
        return result_str;

    t_str = pw_malloc(32);
    if (t_str == NULL)
        return NULL;
    memset(t_str, 0x00, 32);

//CR3GEENOE-1607 jerryzh+
//NOTE: From the core dump file, it's same crash isssue with CR3GEENOE-1440
    memset(temp_str, 0, 512);
    strncpy(temp_str, str, 510);
//CR3GEENOE-1607 jerryzh-
	p = strtok(temp_str, " ");

	do {
		if (2 == sscanf(p, "%02d:%02d", &hour, &min))
			sprintf(t_str, "%02d:%02d", hour, min);
	} while ((p = strtok(NULL, " ")));

	if (!strlen(t_str)) {
		pw_free(t_str);
		return result_str;
	}

	sprintf(result_str, "%s", t_str);
	pw_free(t_str);

	return result_str;
}

char* extract_date(char * str, int length) {
	int year, month, day;
	char * d_str;
	char temp_str[512];
	char * result_str = NULL;
	char * p = NULL;

	result_str = pw_malloc(32);
	if(result_str == NULL)
		return NULL;
	memset(result_str, 0x00, 32);

	// date length
	if (!str || length < 5)
		return result_str;
    d_str = pw_malloc(32);
    if(d_str == NULL)
        return NULL;
    memset(d_str, 0x00, 32);

//CR3GEENOE-1607 jerryzh+
//NOTE: From the core dump file, it's same crash isssue with CR3GEENOE-1440
    memset(temp_str, 0, 512);
    strncpy(temp_str, str, 510);
//CR3GEENOE-1607 jerryzh-

    p = strtok(temp_str, " ");

    do {
        if (3 == sscanf(p, "%2d/%2d/%2d", &month, &day, &year))
            sprintf(d_str, "%02d/%02d/%02d", month, day, year);
		else if (2 == sscanf(p, "%2d/%2d", &month, &day))
            sprintf(d_str, "%02d/%02d", month, day);
	} while ((p = strtok(NULL, " ")));

    if (! strlen(d_str)) {
        pw_free(d_str);
        return result_str;
    }

    sprintf(result_str, "%s", d_str);
    pw_free(d_str);

    return result_str;
}

int is_contains_date_time(char *line, int length) {
    int year, month, day;
    int hour, min;
    char temp_str[512];
    int result = FALSE;
    char * p = NULL;

//CR3GEENOE-1607 jerryzh+
//NOTE: From the core dump file, it's same crash isssue with CR3GEENOE-1440
    memset(temp_str, 0, 512);
    strncpy(temp_str, line, 510);
//CR3GEENOE-1607 jerryzh-
    p = strtok(temp_str, " ");

    do {
        if ((2 == sscanf(p, "%02d:%02d", &hour, &min))
            || (3 == sscanf(p, "%2d/%2d/%2d", &month, &day, &year))
            || (2 == sscanf(p, "%2d/%2d", &month, &day)))
            result = TRUE;
    } while ((p = strtok(NULL, " ")));

    return result;
}

char *exchange_datetime_name_arabic(char *line, int length, bool_t exchangeName)
{
    char* output = NULL;
    char* output_tmp = NULL ;
    char* line_tmp = NULL ;
    unsigned char c_first, c_second, c_last_second, c_last;
    char* time_string = NULL;
	int time_length = 0;
	char* date_string = NULL;
	int date_length = 0;

	// date/time length
	if (line == NULL || length < 5) {
		return line;
    }

    c_first = (unsigned char)(*((unsigned char *)(line)));
    c_second = (unsigned char)(*((unsigned char *)(line + 1)));
    c_last_second = (unsigned char)(*((unsigned char *)(line + length - 2)));
    c_last = (unsigned char)(*((unsigned char *)(line + length - 1)));

    if (c_first == 0x5c && isControlSymbol(c_second))
    {
        output = pw_malloc(sizeof(char)*(length+1));
        if(output == NULL)
            return NULL;
        memset(output, 0x00, sizeof(char)*(length+1));

		output_tmp = exchange_datetime_name_arabic((line+2), (length-2), exchangeName);

        memcpy(output, &c_first, sizeof(char));
        memcpy((char*)(output + 1), &c_second, sizeof(char));
        memcpy((char*)(output + 2), output_tmp , (length-2)*sizeof(char));

        if(output_tmp != NULL && (output_tmp != (line + 2))) {
            pw_free(output_tmp);
            output_tmp = NULL;
        }

        return output;

    } else if (c_last_second == 0x5c && isControlSymbol(c_last))
    {
        output = pw_malloc(sizeof(char)* (length+1));
        if(output == NULL)
            return NULL;
        memset(output, 0x00, sizeof(char)*(length+1));

        line_tmp = pw_malloc(sizeof(char)* (length-1));
        if(line_tmp == NULL) {
            pw_free(output);
            return NULL;
        }
        memset(line_tmp, 0x00, sizeof(char)*(length-1));

        strncpy(line_tmp, line, length-2);

		output_tmp = exchange_datetime_name_arabic(line_tmp, (length-2), exchangeName);

        memcpy(output, output_tmp, (length - 2)*sizeof(char));
        memcpy((char*)(output + length-2), &c_last_second, sizeof(char));
        memcpy((char*)(output + length-1), &c_last , sizeof(char));

//crqms00204994 fix memory leak+
        if(output_tmp && output_tmp != line_tmp )
        {
            pw_free(output_tmp);
            output_tmp = NULL ;
        }
//crqms00204994 fix memory leak-

        if(line_tmp != NULL) {
            pw_free(line_tmp);
            line_tmp = NULL;
        }

        return output;
    }

// crqms00205908, shilongh+
    if (!is_contains_date_time(line, length)) {
        return line;
    }
// crqms00205908, shilongh-

	// date_string and time_string never be NULL
	date_string = extract_date(line, length);
	time_string = extract_time(line, length);

	if (date_string && time_string) {
		date_length = strlen(date_string);
		time_length = strlen(time_string);
	} else if (!date_string && time_string) {
		time_length = strlen(time_string);
	} else if (date_string && !time_string) {
		date_length = strlen(date_string);
	} else {
		pw_free(time_string);
		pw_free(date_string);
		return line;
    }
	if (date_length == 0 && time_length == 0) {
		pw_free(time_string);
		pw_free(date_string);
		return line;
    }

	if (time_length != 0 && date_length != 0 ) {
		char * time_index = NULL;

        char * date_index = NULL;
        char * name = NULL;
        int name_length = 0;
		int time_index_length;
        int date_index_length;

		time_index = strstr(line, time_string);
		if (!time_index) {
			pw_free(time_string);
			pw_free(date_string);
			return line;
		}
		time_index_length = strlen(time_index);

		date_index = strstr(line, date_string);

        if (! date_index) {
			pw_free(time_string);
			pw_free(date_string);
			return line;
        }
        date_index_length = strlen(date_index);

		if (date_index_length > time_index_length) {
			name = extract_name(time_index, time_length);
		} else {
			name = extract_name(date_index, date_length);
		}
        if (!name) {
            name_length = 0;
        } else {
            name_length = strlen(name);
        }

		// only time date exchange or no name found
		if (exchangeName == FALSE || name_length < 1) {
			// time already ahead date
			if (date_index_length < time_index_length) {
				if (name != NULL)
				{
					pw_free(name);
				}
				pw_free(time_string);
				pw_free(date_string);
				return line;
			} else {
        output = pw_malloc(sizeof(char)* (length+1));
        if(output == NULL)
            return NULL;
        memset(output, 0x00, sizeof(char)*(length+1));

        strncpy(output, line, (length - date_index_length));

				strcat(output, time_string);

				strcat(output, " ");
				strcat(output, date_string);

				strcat(output, time_index + time_length);
			}

		} else {
			output = pw_malloc(sizeof(char)* (length+1));
			if(output == NULL)
				return NULL;
			memset(output, 0x00, sizeof(char)*(length+1));

			// time already ahead date
			if (date_index_length < time_index_length) {
				strncpy(output, line, (length - time_index_length));

				strcat(output, name);

				strcat(output, " ");
				strcat(output, time_string);

				strcat(output, " ");
				strcat(output, date_string);

				strcat(output, date_index + (date_length + name_length + 1));

			} else {

				strncpy(output, line, (length - date_index_length));

				strcat(output, name);

				strcat(output, " ");
				strcat(output, time_string);

				strcat(output, " ");
				strcat(output, date_string);

				strcat(output, time_index + (time_length + name_length + 1));
			}
		}

		if (name != NULL) {
			pw_free(name);
		}

	} else if (time_length != 0 && date_length == 0) {
		char * time_index = NULL;
		char * name = NULL;
		int name_length = 0;
		int time_index_length;

		if (exchangeName == FALSE) {
			pw_free(date_string);
			pw_free(time_string);
			return line;
		}

		time_index = strstr(line, time_string);
		if (!time_index) {
			pw_free(date_string);
			pw_free(time_string);
			return line;
		}
		time_index_length = strlen(time_index);

		name = extract_name(time_index, time_length);
		// no name found, just return line
		if (!name) {
			pw_free(date_string);
			pw_free(time_string);
			return line;
		} else {
			name_length = strlen(name);
		}

		output = pw_malloc(sizeof(char)* (length+1));
		if(output == NULL)
			return NULL;
		memset(output, 0x00, sizeof(char)*(length+1));

		strncpy(output, line, (length - time_index_length));
        // already have space here.
		if (name_length > 0) {
            strcat(output, name);
            strcat(output, " ");
        }

		strncat(output, time_index, time_length);

		if (time_index_length > (time_length + name_length + 2)) {
			strcat(output, " ");
			if (name_length > 0) {
				strcat(output, time_index + (time_length + name_length + 2));
			} else {
				strcat(output, time_index + (time_length + name_length + 1));
			}
		}

		if (name != NULL) {
			pw_free(name);
		}

	} else if (time_length == 0 && date_length != 0) {
		char * date_index = NULL;
		char * name = NULL;
		int name_length = 0;
		int date_index_length;

		if (exchangeName == FALSE) {
			pw_free(time_string);
			pw_free(date_string);
			return line;
        }

		date_index = strstr(line, date_string);
		if (!date_index) {
			pw_free(time_string);
			pw_free(date_string);
			return line;
		}
		date_index_length = strlen(date_index);

		name = extract_name(date_index, date_length);
		// no name found, just return line
		if (!name) {
			pw_free(time_string);
			pw_free(date_string);
			return line;
		} else {
			name_length = strlen(name);
		}


		output = pw_malloc(sizeof(char)* (length+1));
		if(output == NULL)
			return NULL;
		memset(output, 0x00, sizeof(char)*(length+1));

		strncpy(output, line, (length - date_index_length));

		// already have space here.
		if (name_length > 0) {
			strcat(output, name);
			strcat(output, " ");
		}

		strncat(output, date_index, date_length);

		if (date_index_length > (date_length + name_length + 2)) {
			strcat(output, " ");
			if (name_length > 0) {
				strcat(output, date_index + (date_length + name_length + 2));
			} else {
				strcat(output, date_index + (date_length + name_length + 1));
			}
        }

        if (name != NULL) {
            pw_free(name);
        }
    }


    if (output == NULL) {
        output = pw_malloc(sizeof(char)* (length+1));
        if(output == NULL)
            return NULL;
        memset(output, 0x00, sizeof(char)*(length+1));
        strcpy(output, line);
    }

	pw_free(date_string);
	pw_free(time_string);

    return output ;
}
//crqms00202831 Anne, shilongh-
//crqms00204663 crqms00202857  Shilong -


/*STEP 1: divide the string into arabic and english strings*/
/*STEP 2: re-order them*/
static char* reverse_arabic(const char *line, int length)/////////////////////////////////////////////////////////////
{
    int i,j;
    struct group_pos_t pos[34];
    int group_amount = 0;
    char tempStr[512];
    char *resultStr=NULL;
    int final = 0;
    int SymbolCnt = 0;

//crqms00202831 Anne  arrow cr +
    bool_t reverse_flag = 0;
    char* input = NULL ;
    char* output = NULL;

    input = (char *)line;
    //Start to deal the arrow. If the arrow is not in hebrew context, the arrow direction and the contents beside the arrow should changed accordingly.
    output = pw_malloc(sizeof(char)* 512);
    if(output == NULL)
        return NULL;
    memset(output, 0x00, sizeof(char)*512);

    //Find the arrow in string (0xE0C7, right arrow  , 0xE0C8 , left arrow)
    for (i = 0; i < length; i+=2)
    {
        w_char c, c_next,c_prev;

        c = (w_char)(*((w_char *)(line+i)));
        if (i == (length-2))
        {
            c_next = 0x0020;
        }
        else
        c_next = (w_char)(*((w_char *)(line+i+2)));

        if (i == 0)
        {
            c_prev = 0x0020;
        }
        else
        c_prev = (w_char)(*((w_char *)(line+i-2)));

        //If the arrow found and neither of the chars beside the arrow are hebrew, change the contents postion
        if((c == 0xE0C7 || c == 0xE0C8) && (!isArabicOrHebraize(c_next))&& (!isArabicOrHebraize(c_prev)))
        {
            w_char temp_c ;
            memcpy(output, (char *)line , i*sizeof(char));

            if(c == 0xE0C7)
                temp_c = 0xE0C8;

            else
                temp_c = 0xE0C7 ;

            memcpy((char*)(output +i), &temp_c,sizeof(w_char) );

            memcpy((char*)(output + i + 2), (char *)(line + i + 2) , (length - i - 2)*sizeof(char));

            input = (char *)output;

            reverse_flag = TRUE;

            break;
        }
    }
//crqms00202831 Anne  arrow cr -

    memset(pos, 0x00, sizeof(pos));
    memset(tempStr, 0x00, sizeof(tempStr));

    resultStr = (char*)pw_malloc(sizeof(char)*512);
    if(resultStr == NULL)
        return NULL;
    memset(resultStr, 0x00, sizeof(char)*512);

    pos[group_amount].start = (char *)input; //crqms00202831 Anne  arrow cr
    for (i = 0; i < length; i+=2)
    {
        //crqms00202831 Anne  arrow cr +
        w_char c,c_next;

//crms00206375 qiaos+
        if(group_amount > 32)
            break;

        c = (w_char)(*((w_char *)(input+i)));

        if (i == (length-2))
        {
            c_next = 0xffff;
        }
        else
            c_next = (w_char)(*((w_char *)(input+i+2)));
        //crqms00202831 Anne  arrow cr -

        //crqms00200514 Anne +
        /*Find out the contrl symbols and make them in a seperated group*/
        if( c == 0x5c && isControlSymbol(c_next))
        {
            pos[group_amount+1].length = 4 ;
            pos[group_amount+1].start = pos[group_amount].start + pos[group_amount].length;
            pos[group_amount+1].reverse_flag = 0;
            group_amount+=2;
            pos[group_amount].start = pos[group_amount-1].start + pos[group_amount-1].length;
            SymbolCnt=0;
            i+=2;
            continue;
        }
        //crqms00200514 Anne -
        else if(isSymbol(c_next) && isalpha2(c))
        {
            pos[group_amount].length +=2;
            SymbolCnt++;
            continue;

        }
        else if(SymbolCnt > 0)
        {
            //crqms00200514 Anne +
            if (isSymbol(c_next) )  //Count the Symbol number followed with alpha only and will used to calculate the length later.
            {
                SymbolCnt++;
                continue;
            }
            if (c_next == 0x5c ) //Used to make control symbol seperated from Latin/Number/Hebrew/Other symbols
            {
                pos[group_amount].length += 2*SymbolCnt;
                SymbolCnt = 0;
                continue;
            }
            //crqms00200514 Anne -
            else if(isalpha2(c_next))
            {
                pos[group_amount].length +=2*SymbolCnt;
                pos[group_amount+1].start = pos[group_amount].start + pos[group_amount].length;
                pos[group_amount].reverse_flag = 0;
                SymbolCnt=0;
            }
            else if(isArabicOrHebraize(c_next))
            {
                pos[group_amount+1].start = pos[group_amount].start + pos[group_amount].length;
                pos[group_amount+1].length +=2*SymbolCnt;
                pos[group_amount+1].reverse_flag = 1;
                group_amount++;
                SymbolCnt=0;
            }
                    /*touch the tail*/
            else if (c_next == 0xffff)
            {
                //pos[group_amount].length -= (SymbolCnt*2);
                pos[group_amount+1].start = pos[group_amount].start + pos[group_amount].length;
                pos[group_amount+1].length = SymbolCnt*2;
                pos[group_amount+1].reverse_flag = 1;
                group_amount++;
                SymbolCnt=0;
            }

        }
//crms00206375 qiaos-
        else if (isArabicOrHebraize(c)^isArabicOrHebraize(c_next))
        {
            if( (isArabicOrHebraize(c) && isalpha2((int)c_next))
                || (isArabicOrHebraize(c_next) && isalpha2((int)c)))
            {
                pos[group_amount].length +=2;
                pos[group_amount+1].start = pos[group_amount].start + pos[group_amount].length;
                pos[group_amount].reverse_flag = isArabicOrHebraize(c);
                group_amount++;
            }
            else
            {
                pos[group_amount].reverse_flag = TRUE;
                pos[group_amount].length +=2;
            }
        }
        else if(isalpha2(c) && isalpha2(c_next))
        {
            pos[group_amount].length +=2;
            if(SymbolCnt == 0 && pos[group_amount].start == NULL && group_amount > 0)
                pos[group_amount].start = pos[group_amount-1].start + pos[group_amount-1].length;
        }
        else if(isSymbol(c) && isSymbol(c_next))
        {
            pos[group_amount].length +=2;
        }
        else if(isSymbol(c) && isalpha2(c_next))
        {
            pos[group_amount].length +=2;
            pos[group_amount+1].start = pos[group_amount].start + pos[group_amount].length;
            group_amount++;
        }
        else
        {
            pos[group_amount].length +=2;
        }
    }

    /*the symbols left in the tail should be in the style "*** Esssss...", seperate them and make a new group similiar with arabic.*/
    if(SymbolCnt >0)
    {
        pos[group_amount].length +=(2*SymbolCnt);
        pos[group_amount].reverse_flag = 1;
    }
    if( pos[group_amount].length == 0)
        group_amount--;

    for(i = group_amount; i>=0 ;i--)
    {
        w_char c;
              /*some character's need converting such as arrows*/
        if(pos[i].reverse_flag == 1)
        {
            for(j=0;j<pos[i].length;j+=2)
            {
                c = (w_char)(*((w_char *)(pos[i].start+j)));
                /*< > reverse*/
                if (c==0x3c)
                    *((w_char *)(pos[i].start+j)) = 0x3e;
                if (c==0x3e)
                    *((w_char *)(pos[i].start+j)) = 0x3c;
                /*E048 E047*/
                if (c==0xE0C7)
                {
                    if (! reverse_flag) //CR8018NOE-126  Anne Li
                        *((w_char *)(pos[i].start+j)) = 0xE0C8;
                }
                if (c==0xE0C8)
                {
                    if (! reverse_flag) //CR8018NOE-126  Anne Li
                        *((w_char *)(pos[i].start+j)) = 0xE0C7;
                }
                /*AB BB*/
                if (c==0xAB)
                    *((w_char *)(pos[i].start+j)) = 0xBB;
                if (c==0xBB)
                    *((w_char *)(pos[i].start+j)) = 0xAB;
                /*E0B9 E0BA*/
                if (c==0xE0B9)
                    *((w_char *)(pos[i].start+j)) = 0xE0BA;
                if (c==0xE0BA)
                    *((w_char *)(pos[i].start+j)) = 0xE0B9;
                /*()*/
                if (c==0x29)
                    *((w_char *)(pos[i].start+j)) = 0x28;
                if (c==0x28)
                    *((w_char *)(pos[i].start+j)) = 0x29;
                /*[]*/
                if (c==0x5b)
                    *((w_char *)(pos[i].start+j)) = 0x5d;
                if (c==0x5d)
                    *((w_char *)(pos[i].start+j)) = 0x5b;
                /*{}*/
                if (c==0x7b)
                    *((w_char *)(pos[i].start+j)) = 0x7d;
                if (c==0x7d)
                    *((w_char *)(pos[i].start+j)) = 0x7b;
            }
        }
    }

//crqms00205987 Anne Li +
	for(i = group_amount; i >= 0 ;i--)
	{
		w_char c;
		for(j = 0;j < pos[i].length; j += 2)
		{
			c = (w_char)(*((w_char *)(pos[i].start+j)));

			/*Black rectangle in log detail screen, 0xE0F7 presents right direction  > , 0xE0F6 presents left direction <*/
			if (c==0xE0F7)
			{
				*((w_char *)(pos[i].start+j)) = 0xE0F6;
			}
			if (c==0xE0F6)
				*((w_char *)(pos[i].start+j)) = 0xE0F7;
		}
	}
//crqms00205987 Anne Li -

        /*group convert*/
    for(i = group_amount; i>=0 ;i--)
    {
        if(pos[i].reverse_flag == 1)
        {
            for(j=pos[i].length;j>1;j-=2)
            {
                memcpy(tempStr+j-2,pos[i].start+pos[i].length-j,2);
            }
            memcpy(resultStr+final,tempStr,pos[i].length);
            final += pos[i].length;
        }
        else
        {
            memcpy(resultStr+final,pos[i].start,pos[i].length);
            final += pos[i].length;
        }
    }

    //crqms00202831 Anne  arrow cr +
    if(output)
        pw_free(output);
    //crqms00202831 Anne  arrow cr -

    return resultStr;
}

static enum ARABIC_NORMAL_CHAR Normal_Code2Index(w_char ab_code)
{
    switch (ab_code)
    {
    case 0x0621:    return AB_0621;
    case 0x0622:    return AB_0622;
    case 0x0623:    return AB_0623;
    case 0x0624:    return AB_0624;
    case 0x0625:    return AB_0625;
    case 0x0626:    return AB_0626;
    case 0x0627:    return AB_0627;
    case 0x0628:    return AB_0628;
    case 0x0629:    return AB_0629;
    case 0x062A:    return AB_062A;
    case 0x062B:    return AB_062B;
    case 0x062C:    return AB_062C;
    case 0x062D:    return AB_062D;
    case 0x062E:    return AB_062E;
    case 0x062F:    return AB_062F;
    case 0x0630:    return AB_0630;
    case 0x0631:    return AB_0631;
    case 0x0632:    return AB_0632;
    case 0x0633:    return AB_0633;
    case 0x0634:    return AB_0634;
    case 0x0635:    return AB_0635;
    case 0x0636:    return AB_0636;
    case 0x0637:    return AB_0637;
    case 0x0638:    return AB_0638;
    case 0x0639:    return AB_0639;
    case 0x063A:    return AB_063A;
    case 0x0641:    return AB_0641;
    case 0x0642:    return AB_0642;
    case 0x0643:    return AB_0643;
    case 0x0644:    return AB_0644;
    case 0x0645:    return AB_0645;
    case 0x0646:    return AB_0646;
    case 0x0647:    return AB_0647;
    case 0x0648:    return AB_0648;
    case 0x0649:    return AB_0649;
    case 0x064A:    return AB_064A;
    default:
        return AB_IILEGAL;
    }
}

static enum ARABIC_CASE2_CHAR Case2_Code2Index(w_char ab_code)
{
    switch(ab_code)
    {
    case 0x0622:
        return  ABS_0622;
    case 0x0623:
        return  ABS_0623;
    case 0x0625:
        return  ABS_0625;
    case 0x0627:
        return  ABS_0627;
    case 0x064b:
        return  ABS_064b;
    case 0x064c:
        return  ABS_064c;
    case 0x064d:
        return  ABS_064d;
    case 0x064e:
        return  ABS_064e;
    case 0x064f:
        return  ABS_064f;
    case 0x0650:
        return  ABS_0650;
    case 0x0651:
        return  ABS_0651;
    case 0x0652:
        return  ABS_0652;
    default:
        return  ABS_IILEGAL;
    }

}

static enum POS_STADUS resetglobalpos(enum POS_STADUS pos)
{
    enum POS_STADUS old = globalPos;
    globalPos = pos;
    return old;
}

/*main function, input should be UTF16*/
static int map_arabic(const char* line)
{
    int stringpos = 0;

    globalPos = ISOLATED;
    memset(strings,0x00,sizeof(strings));
    linepos = 0;

    while (linepos < (line_length))
    {
        w_char c,c_next;
        enum ARABIC_NORMAL_CHAR index1;
        enum ARABIC_CASE2_CHAR index2;
        w_char temp_disp_code= 0x0;

        c = getCurChar(line);
        c_next = getnextchar(line);

        /*CR and special char handling*/
        if (c == 0x5c)
        {
            if (isControlSymbol(c_next))
            {
                //crqms00200514 Anne +
                if(c_next != 0x43)
                {
                    linepos +=4;

                    memcpy((char *)(strings+stringpos), &c,2);
                    memcpy((char *)(strings+stringpos+2), &c_next,2);
                    stringpos+=4;
                }
                //crqms00200514 Anne -
                else
                {
                    linepos += 10;
                }
                continue;
            }
        }

        if (isspace2(c) && ((index2 = Case2_Code2Index(getnextchar(line)))!= 0xffff))
        {
            if((temp_disp_code = arabic_case2_map_table[index2][AB_SPACE]) != 0)
            {
                memcpy((char *)(strings+stringpos), (char *)(&temp_disp_code), sizeof(w_char));
                linepos += 4;
                stringpos+=2;
            }
            else
            {
                memcpy((char *)(strings+stringpos), (char *)(&c), sizeof(w_char));
                linepos+=2;
                stringpos+=2;
            }
    //crms00222686 jerryzh+
            continue;
    //crms00222686 jerryzh-
        }
//crms00206375 qiaos+
//For Lam symbol bug issue.
     else if (isarabic(c))
     {
            enum POS_STADUS cur = getCurrentPos(c,line);

            if (istotweel(c) && MEDIAL == cur && ((index2 = Case2_Code2Index(getnextchar(line)))!= 0xffff))
            {
                if((temp_disp_code = arabic_case2_map_table[index2][AB_TATWEEL]) != 0)
                {
                    memcpy((char *)(strings+stringpos), (char *)(&temp_disp_code), sizeof(w_char));
                    linepos += 4;
                    stringpos+=2;
                }
                else
                {
                    memcpy((char *)(strings+stringpos), (char *)(&c), sizeof(w_char));
                    linepos+=2;
                    stringpos+=2;
                }
    //crms00222686 jerryzh+
                continue;
    //crms00222686 jerryzh-
            }
            else if (islam(c) && INITIAL == cur && ((index2 = Case2_Code2Index(getnextchar(line)))!= 0xffff))
            {
                if((temp_disp_code = arabic_case2_map_table[index2][AB_LAM_ISOLATED]) != 0)
                {
                    memcpy((char *)(strings+stringpos), (char *)(&temp_disp_code), sizeof(w_char));
                    linepos += 4;
                    stringpos+=2;
                }
                else
                {
                    memcpy((char *)(strings+stringpos), (char *)(&c), sizeof(w_char));
                    linepos+=2;
                    stringpos+=2;
                }
                //Special characters causing next character re-calculate its pos
                resetglobalpos(FINAL);
    //crms00222686 jerryzh+
                continue;
    //crms00222686 jerryzh-
            }
            else if (islam(c) && MEDIAL == cur && ((index2 = Case2_Code2Index(getnextchar(line)))!= 0xffff))
            {
                if((temp_disp_code = arabic_case2_map_table[index2][AB_LAM_FINAL]) != 0) //?
                {
                    memcpy((char *)(strings+stringpos), (char *)(&temp_disp_code), sizeof(w_char));
                    linepos += 4;
                    stringpos+=2;
                }
                else
                {
                    memcpy((char *)(strings+stringpos), (char *)(&c), sizeof(w_char));
                    linepos+=2;
                    stringpos+=2;
                }
                    //Special characters causing next character re-calculate its pos

                resetglobalpos(FINAL);
    //crms00222686 jerryzh+
                continue;
    //crms00222686 jerryzh-
            }

            if ((index1 = Normal_Code2Index(c))!= 0xffff)
            {
                if(arabic_case1_map_table[index1][cur] != 0)
                {
                    memcpy((char *)(strings+stringpos), (char *)(&(arabic_case1_map_table[index1][cur])), sizeof(w_char));
                }
                /*if a character contains only two forms,isolated,final
                then the initial form will like isolated form?
                * mediate form will like final form?
                */
                else if (cur == MEDIAL && arabic_case1_map_table[index1][FINAL] != 0)
                {
                    memcpy((char *)(strings+stringpos), (char *)(&(arabic_case1_map_table[index1][FINAL])), sizeof(w_char));
                }
                else if (cur == INITIAL && arabic_case1_map_table[index1][ISOLATED] != 0)
                {
                    memcpy((char *)(strings+stringpos), (char *)(&(arabic_case1_map_table[index1][ISOLATED])), sizeof(w_char));
                }
            }
            /*Some other symbols*/
            else
            {
                memcpy((char *)(strings+stringpos), (char *)(&c), sizeof(w_char));
             }

            /*special character treat ,tuner the next word to be initial +*/
            if (isSpecial(c))
            {
                resetglobalpos(FINAL);
            }

        linepos+=2;
        stringpos+=2;
        }
//crms00206375 qiaos-
        else
        {

            getCurrentPos(c,line);//the result is useless,only to update globalpos
            memcpy((char *)(strings+stringpos), (char *)(&c), sizeof(w_char));
            linepos+=2;
            stringpos+=2;
        }
    }

    return stringpos;
}

//crms00206375 qiaos+
//Process a line of Arabic divided by \n
static int Arabic_Convert_Api_Line(const char* input_ptr, char *output_ptr, int input_length, int *output_length)
{
    char* result=NULL;

    if (input_length > MAX_ARABIC_LINE_LENGTH)
        return FALSE;

    line_length = input_length;
    if (input_length == 0 || input_ptr == NULL || output_ptr == NULL)
        return FALSE;


    if (output_length != NULL)
        *output_length = map_arabic(input_ptr);

    if (output_length != NULL)
        result = reverse_arabic(strings, *output_length);

    if (result!=NULL)
    {
        memcpy(output_ptr, result, *output_length);
        pw_free(result);
    }
    else
    {
        return FALSE;
    }
    return TRUE;
}

int Arabic_Convert_Api(const char* input_ptr, char *output_ptr, int input_length, int *output_length)
{
    int i,j=0;
    char tmp_output[MAX_ARABIC_LINE_LENGTH];
    int tmp_outlength = 0;
    w_char c,c1;
    int char_count = 0;

    if (input_length > MAX_ARABIC_LINE_LENGTH)
        return FALSE;

       /*using i recording the scan position, using j recording the amount of char which have been transformed already.*/
    for(i = 0 ; i < input_length ; i += 2)
    {
        char_count++; /*record the amount of chars before \n to avoid the case in which there is no \n in the tail.*/
        if (i != (input_length-2))
        {
            c = *(w_char *)(input_ptr+i); /*current char*/
            c1= *(w_char *)(input_ptr+i+2); /*next char*/

             /*\n handling.*/
            if (c == 0x5c && c1== 0x6e) /*\n*/
            {
                Arabic_Convert_Api_Line(input_ptr+j, tmp_output, i-j, &tmp_outlength);
                memcpy((void*)(output_ptr+*output_length),(void*)tmp_output,tmp_outlength);
                j=i;
                *output_length += tmp_outlength;

                /*convert \n to LF*/
                c = 0x0a;
                memcpy((void*)(output_ptr+*output_length),&c,2);
                *output_length += 2;
                char_count = 0;
                j+=4;
                i+=2;
            }
#if 0
            else if (c == 0x5c && c1== 0x5e) /*\^*/
            {
                Arabic_Convert_Api_Line(input_ptr+j, tmp_output, i-j, &tmp_outlength);
                memcpy((void*)(output_ptr+*output_length),(void*)tmp_output,tmp_outlength);
                j=i;
                *output_length += tmp_outlength;

                /*convert \n to LF*/
                c = '{';
                c1 = '|';
                memcpy((void*)(output_ptr+*output_length),&c,2);
                memcpy((void*)(output_ptr+*output_length+2),&c1,2);
                *output_length += 4;
                char_count = 0;
                j+=4;
                i+=2;
            }
#endif
        }
    }

    if (char_count > 0)
    {
        Arabic_Convert_Api_Line(input_ptr+j, tmp_output, i-j, &tmp_outlength);
        memcpy((void*)(output_ptr+*output_length),(void*)tmp_output,tmp_outlength);
        *output_length += tmp_outlength;
    }
    return TRUE;
}
//crms00206375 qiaos-



