/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#  include "stdinc.h"
#  include "stddef.h"
#  include "log.h"
#  include "rofs.h"
#  include "display.h"
#  include "../disp_priv.h"
#  include "skin_err.c"
#  include "skins.h"

#include "i_icon.h"
#include "i_skins.h"

enum {
    MODEL_A//for aom, only one model
};

#define SKIN_NAME_MAXLEN   (256)
#define SKIN_PREFIX_MAXLEN (16)


/*-----------------------------------------------------------------------------
  S K I N S  D E F I N I T I O N S
  ---------------------------------------------------------------------------*/

#define      COUNT_SBAR_BIG 8
NGGimage    *ngwAlcSkin_sbar_big[COUNT_SBAR_BIG];
static char *names_sbar_big[COUNT_SBAR_BIG] =
{
    NULL                 ,
    NULL              ,
    NULL              ,
    NULL               ,
    NULL            ,
    NULL            ,
    NULL              ,
    NULL
};

#define      COUNT_SBAR_SMALL 8
NGGimage    *ngwAlcSkin_sbar_small[COUNT_SBAR_SMALL];
static char *names_sbar_small[COUNT_SBAR_SMALL] =
{
    NULL               ,
    NULL            ,
    NULL            ,
    NULL             ,
    NULL          ,
    NULL          ,
    NULL            ,
    NULL
};

#define      COUNT_PBAR 12
NGGimage    *ngwAlcSkin_pbar[COUNT_PBAR];
static char *names_pbar[COUNT_PBAR] =
{
    NULL             ,
    NULL           ,
    NULL            ,
    NULL           ,
    NULL         ,
    NULL           ,
    NULL                              , // vertical progressbar (empty left)
    NULL                              , // vertical progressbar (empty middle)
    NULL                              , // vertical progressbar (empty right)
    NULL                              , // vertical progressbar (filled left)
    NULL                              , // vertical progressbar (filled middle)
    NULL                                // vertical progressbar (filled right)
};

#define      COUNT_SLIDER 16
NGGimage    *ngwAlcSkin_slider[COUNT_SLIDER];
static char *names_slider[COUNT_SLIDER] =
{
    NULL               ,
    NULL            ,
    NULL            ,
    NULL             ,
    NULL          ,
    NULL          ,
    NULL                              , // vertical sliderbar (empty left)
    NULL                              , // vertical sliderbar (empty middle)
    NULL                              , // vertical sliderbar (empty right)
    NULL                              , // vertical sliderbar (filled left)
    NULL                              , // vertical sliderbar (filled middle)
    NULL                              , // vertical sliderbar (filled right)
    NULL                              , // left arrow
    NULL               ,
    NULL            ,
    NULL                                // right arrow
};

#define      COUNT_CARDCT 18
NGGimage    *ngwAlcSkin_cardct[COUNT_CARDCT];
static char *names_cardct[COUNT_CARDCT] =
{
    NULL               ,
    NULL            ,
    NULL            ,
    NULL             ,
    NULL          ,
    NULL          ,
    NULL            ,
    NULL               ,
    NULL            ,
    NULL            ,
    NULL             ,
    NULL          ,
    NULL          ,
    NULL            ,
    NULL          ,
    NULL          ,
    NULL            ,    
    NULL
};

#define      COUNT_TNOE 24
NGGimage    *ngwAlcSkin_tnoe[COUNT_TNOE];
static char *names_tnoe[COUNT_TNOE] =
{
    NULL               ,
    NULL            ,
    NULL            ,
    NULL             ,
    NULL          ,
    NULL          ,
    NULL            ,
    NULL               ,
    NULL            ,
    NULL            ,
    NULL             ,
    NULL          ,
    NULL          ,
    NULL            ,
    NULL          ,
    NULL          ,
    NULL            ,    
    NULL            ,
    NULL          ,
    NULL          ,
    NULL            ,   
    NULL            ,
    NULL          ,  
    NULL
};

#define      COUNT_HDBOX 6
NGGimage    *ngwAlcSkin_hdbox[COUNT_HDBOX];
static char *names_hdbox[COUNT_HDBOX] =
{
    NULL               ,
    NULL            ,
    NULL            ,
    NULL             ,
    NULL          ,
    NULL 
};

#define      COUNT_INPUT 9
NGGimage    *ngwAlcSkin_input[COUNT_INPUT];
static char *names_input[COUNT_INPUT] =
{
    NULL            ,
    NULL          ,
    NULL          ,
    NULL            ,    
    NULL            ,
    NULL          ,
    NULL          ,
    NULL            ,   
    NULL        
};

#define      COUNT_PINB 9
NGGimage    *ngwAlcSkin_pinb_border0[COUNT_PINB];
static char *names_pinb_border0[COUNT_PINB] =
{
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};

NGGimage    *ngwAlcSkin_pinb_border1[COUNT_PINB];
static char *names_pinb_border1[COUNT_PINB] =
{
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};


NGGimage    *ngwAlcSkin_pinb_border2[COUNT_PINB];
static char *names_pinb_border2[COUNT_PINB] =
{
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};

NGGimage    *ngwAlcSkin_pinb_border4[COUNT_PINB];
static char *names_pinb_border4[COUNT_PINB] =
{
    NULL                              ,
    NULL                              ,
    NULL                              , // top
    NULL                              , // topleft
    NULL                              , // topright
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};

NGGimage    *ngwAlcSkin_pinb_border5[COUNT_PINB];
static char *names_pinb_border5[COUNT_PINB] =
{
    NULL                              ,
    NULL                              ,
    NULL                              , // top
    NULL                              , // topleft
    NULL                              , // topright
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};


NGGimage    *ngwAlcSkin_pinb_border8[COUNT_PINB];
static char *names_pinb_border8[COUNT_PINB] =
{
    NULL                              ,
    NULL                              ,
    NULL                              , // top
    NULL                              , // topleft
    NULL                              , // topright
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};

#define      COUNT_APPB 9
NGGimage    *ngwAlcSkin_appbutton[COUNT_APPB];
static char *names_appbutton[COUNT_APPB] =
{
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};

// XTSce72250+
#if defined(FEATURE_IME)
#define      COUNT_IME 9
NGGimage    *ngwAlcSkin_ime[COUNT_IME];
static char *names_ime[COUNT_IME] =
{
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL                              ,
    NULL
};
#endif /* FEATURE_IME */
// XTSce72250-


/*-----------------------------------------------------------------------------
  P R I V A T E  V A R I A B L E S
  ---------------------------------------------------------------------------*/

// models mask
#define A    (1 << MODEL_A)

#define UND  (0)

#define isfor(model) (model & (1 << MODEL_A))

typedef struct
{
    int        model;
    int        count;
    char     **names;
    NGGimage **skins;
} skin_descr_t;

static skin_descr_t skins_descr[] =
{
    { A, COUNT_PBAR      , names_pbar         , ngwAlcSkin_pbar          },
    { A, COUNT_SLIDER    , names_slider       , ngwAlcSkin_slider        },
    { A, COUNT_SBAR_BIG  , names_sbar_big     , ngwAlcSkin_sbar_big      },
    { A, COUNT_SBAR_SMALL, names_sbar_small   , ngwAlcSkin_sbar_small    },
    { A, COUNT_CARDCT    , names_cardct       , ngwAlcSkin_cardct        },
    { A, COUNT_TNOE      , names_tnoe         , ngwAlcSkin_tnoe          },
    { A, COUNT_HDBOX     , names_hdbox        , ngwAlcSkin_hdbox         },
    { A, COUNT_INPUT     , names_input        , ngwAlcSkin_input         },

    { A, COUNT_PINB      , names_pinb_border0 , ngwAlcSkin_pinb_border0  },
    { A, COUNT_PINB      , names_pinb_border1 , ngwAlcSkin_pinb_border1  },
    { A, COUNT_PINB      , names_pinb_border2 , ngwAlcSkin_pinb_border2  },
    { A, COUNT_PINB      , names_pinb_border4 , ngwAlcSkin_pinb_border4  },
    { A, COUNT_PINB      , names_pinb_border5 , ngwAlcSkin_pinb_border5  },

    { A, COUNT_PINB      , names_pinb_border8 , ngwAlcSkin_pinb_border8  },
#if defined(FEATURE_IME)    
    { A, COUNT_IME       , names_ime          , ngwAlcSkin_ime           },
#endif    
    { A, COUNT_APPB      , names_appbutton    , ngwAlcSkin_appbutton     },
    { UND, 0, NULL , NULL }
};

typedef struct {
    int              model;
    skin_image_id_t  id;
    NGGimage        *image;
    char            *fname;
} skin_image_t;

static skin_image_t skins_image[] = {
    { A, IMG_HOMEBAR_BACKGROUND    , NULL, "homebar_background"    },
    { A, IMG_TABS_BACKGROUND       , NULL, NULL                    }, // "tabs_background"
    { A, IMG_FRAMEBOX_BACKGROUND   , NULL, NULL                    }, // "framebox_background"
    { A, IMG_SCREEN_BACKGROUND     , NULL, "screen_background"     },
    { A, IMG_SCREENSAVER_BACKGROUND, NULL, NULL                    },
    { UND, IMG_INVALID_ID            , NULL, NULL                    }
};

#if !defined(DUMP_SKINS_NAMES)

// flags
static bool_t fl_init = FALSE;
static bool_t fl_load = FALSE;

// reload callback
static skins_on_reload_cb_t __on_reload_cb = NULL;


/*-----------------------------------------------------------------------------
  P R I V A T E  A P I
  ---------------------------------------------------------------------------*/

static NGGimage *__fs_load_image(char *filename)
{
    FILE_t   *file  = NULL;
    NGGimage *image = NULL;

    file = rofs_open(ROFS_RSC_SKIN, filename);
    if (file == NULL)
    {
        LOGE("skins: %s not found", filename);
        image = (NGGimage *)&skin_err;
    }
    else
    {
        LOGI("skins: %s found", filename);
        image = disp_decode(
            NULL, rofs_faddr(file), rofs_fsize(file), IMAGE_FORMAT_PNG
            );
        if (image == NULL)
            LOGE("skins: %s decode failed", filename);
        rofs_close(file);
    }
    return image;
}

static NGGimage *__load_image(const char *name)
{
    char      fname[SKIN_NAME_MAXLEN];
    int       request = 0;
    NGGimage *skin;

    // no filename = no image
    if (name == NULL)
        return NULL;

    sprintf((char *)&fname, "skin_%s.png", name);
    skin = __fs_load_image(fname);

    return skin;
}

static bool_t __free_image(NGGimage *image)
{
    unsigned char *ptr = (unsigned char *)image;
    if (ptr && (ptr != (unsigned char *)&skin_err)) {
        ptr = ptr - offsetof(NGGframe, frame_data) - sizeof(void *);
        pw_free(ptr);
        return TRUE;
    }
    return FALSE;
}

/*-----------------------------------------------------------------------------
  utility routine for "skins" command (print if files are missing or not)
  ---------------------------------------------------------------------------*/
static char *__skins_check(char *output)
{
    char *p = output;
    int   m;

    m = 0;
    while(skins_descr[m].model != UND) {
        int i;
        for(i = 0 ; (i < skins_descr[m].count) ; i++) {
            skin_descr_t *descr = (skin_descr_t *)&skins_descr[m];
            char *s = descr->names[i];
            if (s) {
                if (descr->skins[i] == (NGGimage *)&skin_err)
                    p += sprintf(p, "not found: %s\n", s);
            }
        }
        m++;
    }
    m = 0;
    while(skins_image[m].model != UND) {
        char *s = skins_image[m].fname;
        if (s) {
            if (skins_image[m].image == (NGGimage *)&skin_err)
                p +=sprintf(p, "not found: %s\n", s);
        }
        m++;
    }
    return output;
}

/*-----------------------------------------------------------------------------
  P U B L I C  A P I
  ---------------------------------------------------------------------------*/
/*-----------------------------------------------------------------------------
  initialization
  ---------------------------------------------------------------------------*/
void skins_init(void)
{
    int m;

    m = 0;
    while(skins_descr[m].model != UND) {
        int i;
        for(i = 0; (i < skins_descr[m].count) ; i++)
            skins_descr[m].skins[i] = NULL;
        m++;
    }

    m = 0;
    while(skins_image[m].model != UND) {
        skins_image[m].image = NULL;
        m++;
    }

    skinsinfo_init();

    fl_init = TRUE;
}

/*-----------------------------------------------------------------------------
  skins loading
  ---------------------------------------------------------------------------*/
void skins_load(void)
{
    LOGI("skins: load   (init=%d, load=%d)", fl_init, fl_load);

    if (fl_init && ! fl_load) {
        int m;

        m = 0;
        while(skins_descr[m].model != UND) {
            if (isfor(skins_descr[m].model)) {
                int i;
                for(i = 0 ; (i < skins_descr[m].count) ; i++) {
                    char     **names = skins_descr[m].names;
                    NGGimage **skins = skins_descr[m].skins;

                    skins[i] = __load_image(names[i]);
                }
            }
            m++;
        }
        m = 0;
        while(skins_image[m].model != UND) {
            if (isfor(skins_image[m].model))
                skins_image[m].image = __load_image(skins_image[m].fname);
            m++;
        }

        fl_load = TRUE;
    }
}

/*-----------------------------------------------------------------------------
  skins unloading
  ---------------------------------------------------------------------------*/
void skins_unload(void)
{
    int m;

    LOGD("skins: unload (init=%d, load=%d)", fl_init, fl_load);

    if (fl_init && fl_load) {
        m = 0;
        while(skins_descr[m].model != UND) {
            int i;
            for(i = 0 ; (i < skins_descr[m].count) ; i++)
                __free_image(skins_descr[m].skins[i]);
            m++;
        }
        m = 0;
        while(skins_image[m].model != UND) {
            __free_image(skins_image[m].image);
            m++;
        }
        fl_load = FALSE;
    }
}

/*-----------------------------------------------------------------------------
  skins unloading (alias)
  ---------------------------------------------------------------------------*/
void skins_finalize(void)
{
    skins_unload();
}

/*-----------------------------------------------------------------------------
  skins reloading
  ---------------------------------------------------------------------------*/
void skins_reload()
{
    LOGD("skins: reload (init=%d, load=%d)", fl_init, fl_load);

    skinsinfo_load(ID_CURR_SKIN);

    icons_reload();

    skins_unload();
    skins_load  ();

    if (__on_reload_cb)
        __on_reload_cb();
}

/*-----------------------------------------------------------------------------
  getter: background image
  ---------------------------------------------------------------------------*/
NGGimage *skins_get_image(skin_image_id_t id)
{
    int i = 0;

    LOGD("skins: get_image(%d) (init=%d, load=%d)", id, fl_init, fl_load);

    if (fl_init && fl_load) {
        while(skins_image[i].model != UND) {
            skin_image_t *p = (skin_image_t *)&skins_image[i];
            if (p->id == id)
                return p->image;
            i++;
        }
    }
    return NULL;
}

/*-----------------------------------------------------------------------------
  setter: reload event callback
  ---------------------------------------------------------------------------*/
void skins_on_reload_set_callback(skins_on_reload_cb_t cb)
{
    __on_reload_cb = cb;
}

#else

int main(int argc, char *argv[])
{
    int m;

    // skins (widgets)
    m = 0;
    while(skins_descr[m].model != UND) {
        int i;
        for(i = 0; (i < skins_descr[m].count) ; i++) {
            char *s = skins_descr[m].names[i];
            if (s)
                printf("%s\n", s);
        }
        m++;
    }

    // images (backgrounds)
    m = 0;
    while(skins_image[m].model != UND) {
        char *s = skins_image[m].fname;
        if (s)
            printf("%s\n", s);
        m++;
    }
    return 0;
}

#endif
