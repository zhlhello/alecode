/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/26 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>

/* Alcatel */
#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"
#include "mem_wrapper.h"

#include "configs.h"
#include "display.h"
#include "disp_priv.h"

//XTSce50998
#include <ngwalc.h>


/*-----------------------------------------------------------------------------
  definition des grilles
  ---------------------------------------------------------------------------*/

#define MAX_Y_GRID_1    5
#define MAX_H_GRID_1    (MAX_Y_GRID_1+1)
#define MAX_Y_GRID_2    9
#define MAX_H_GRID_2    (MAX_Y_GRID_2+1)
#define MAX_X_GRID      9
#define MAX_W_GRID      (MAX_X_GRID+1)

#define CELL_W            64

static const int grid_1[MAX_Y_GRID_1 + 2] =
    { 0,
      36,
      36+74,
      36+74+74,
      36+74+74+74,
      36+74+74+74+74,
      36+74+74+74+74+74 // =406
    };

static const int grid_2[MAX_Y_GRID_2 + 2] =
    { 0,
      37,
      37+74,
      37+74+37,
      37+74+37+37,
      37+74+37+37+37,
      37+74+37+37+37+37,
      37+74+37+37+37+37+37,
      37+74+37+37+37+37+37+37,
      37+74+37+37+37+37+37+37+37,
      37+74+37+37+37+37+37+37+37+37, // =406
    };


gridinfo_t gridinfo;

static int cell_w= CELL_W;

static const int telephonicbox_offset_latin = 0;
static const int telephonicbox_offset_chinese =0;

static int telephonicbox_offset = 0;

//XTSce50998+
static const int framebox_offset_latin_h = 0;
static const int framebox_offset_enlarged_h = 0;
static const int framebox_offset_reduced_h = 0; 
static const int framebox_offset_enlarged_appli_h = 0; 

static const int framebox_offset_latin_y = 0;
static const int framebox_offset_enlarged_y = 0;
static const int framebox_offset_reduced_y = 0; 
static const int framebox_offset_enlarged_appli_y = 0;

static int framebox_offset_h = 0;
static int framebox_offset_y = 0;
//XTSce50998-

//XTSce54356
static const int listbox_reduced_y = 0;


int disp_grid_get_cell_width(void)
{
    return cell_w;
}

int disp_grid_get_row_height(enum_grid_type_t grid, int row)
{
    return YGRID(grid)[row+1] - YGRID(grid)[row];
}

void disp_telephonicbox_set_offset(int offset)
{
    telephonicbox_offset = offset;
}

int disp_telephonicbox_get_offset(void)
{
    return telephonicbox_offset;
}

void disp_telephonicbox_update_offset(NGWPdata chinese)
{
    if (chinese)
        telephonicbox_offset = telephonicbox_offset_chinese;
    else
        telephonicbox_offset = telephonicbox_offset_latin;
}

//XTSce50998+
void disp_framebox_set_offset_h(int offset)
{
    framebox_offset_h = offset;
}

void disp_framebox_set_offset_y(int offset)
{
    framebox_offset_y = offset;
}

int disp_framebox_get_offset_h(void)
{
    return framebox_offset_h;
}

int disp_framebox_get_offset_y(void)
{
    return framebox_offset_y;
}
//XTSce50998-


//XTSce54356+
int disp_listbox_get_reduced_y(void)
{
    return listbox_reduced_y;
}
//XTSce54356-


void disp_framebox_update_offset(NGWPdata flag_size)
{
    if (flag_size == F_ENLARGED)
    {
        framebox_offset_h = framebox_offset_enlarged_h;
        framebox_offset_y = framebox_offset_enlarged_y;
    }
    else if (flag_size == F_ENLARGED_APPLI) /*XTSce57598*/
    {
        framebox_offset_h = framebox_offset_enlarged_appli_h;
        framebox_offset_y = framebox_offset_enlarged_appli_y;
    }
    else if (flag_size == F_REDUCED) /*XTSce53704*/
    {
        framebox_offset_h = framebox_offset_reduced_h;
        framebox_offset_y = framebox_offset_reduced_y;
    }
    else    /*framebox latine*/
    {
        framebox_offset_h = framebox_offset_latin_h;
        framebox_offset_y = framebox_offset_latin_y;
    }
}


/*-----------------------------------------------------------------------------
  initialization des informations sur la grilles
  ---------------------------------------------------------------------------*/
void disp_init_gridinfo(void)
{
    // set the default offset for the telephonicbox
    X_MAX(GRID_TYPE1) = X_MAX(GRID_TYPE2) = MAX_X_GRID;
    W_MAX(GRID_TYPE1) = W_MAX(GRID_TYPE2) = MAX_W_GRID;

    Y_MAX(GRID_TYPE1) = MAX_Y_GRID_1;
    H_MAX(GRID_TYPE1) = MAX_H_GRID_1;
    YGRID(GRID_TYPE1) = (int *)grid_1;

    Y_MAX(GRID_TYPE2) = MAX_Y_GRID_2;
    H_MAX(GRID_TYPE2) = MAX_H_GRID_2;
    YGRID(GRID_TYPE2) = (int *)grid_2;

    cell_w= CELL_W;
}

/*-----------------------------------------------------------------------------
  Position y converter from one grid to another
  abs_y given in old_grid, returned in new_grid (rounded to upper position if forbidden)
  Returned value : position compatibility (TRUE if possible, FALSE if forbidden)
  ---------------------------------------------------------------------------*/
bool_t disp_grid_converter(
    enum_grid_type_t old_grid, enum_grid_type_t new_grid, uint8_t *abs_y
)
{
    bool_t compatibility = TRUE;

    if (old_grid != new_grid && *abs_y >= 2)
    {
        // NEW GRID is TYPE2 (always possible)
        if (old_grid == GRID_TYPE1)
        {
            *abs_y = 2 + (*abs_y - 2) * 2;
        }
        // NEW GRID is TYPE1 (test compatibility)
        // if position in grid1 is compatible with position in grid2
        else
        {
            if ((*abs_y & 0x1) == 0)
                compatibility = FALSE;
            *abs_y = 2 + (*abs_y - 1) / 2;
        }
    }
    return compatibility;
}

