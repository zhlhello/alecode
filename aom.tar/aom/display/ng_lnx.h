/*****************************************************************************

   SccsId=         @(#)ng_lnx.h	1.21  04/08/06

 *****************************************************************************/

#include <ngdefs.h>
#include <ngcore/timerdrv.h>
#include <nggcolor.h>

/*---------------------------------------------------------------------------*/
/*                                 NexGenGRAPH                               */
/*---------------------------------------------------------------------------*/

#ifdef NG_RTOS
#define DEVKBD_TASK_PRIO    0
#define DEVKBD_STK_SIZE     2048
#endif

#include <ngosdrvs.h>

/*-------------------- VIDEO DRIVER --------------------*/
#include <nglnxfb.h>

#define VIDEO_DATA_TYPE		NGGvid_lnxfb_data

// SPEC1   : bytes per line (not used)
// SPEC2   : offscreen(1, default) or direct(0)
// SPECPTR1: device name

#define VIDEO_DRIVER                                          \
  NG_CFG( NG_CFG_MOD_ADD,        &ngVidDrv_LinuxFB),            \
  NG_CFG( NG_CFG_MOD_DATA,       &vid_data),                    \
  NG_CFG( NGG_VIDO_LOCK,         &vid_lock),                    \
  NG_CFG( NGG_VIDO_XRES,         480),                          \
  NG_CFG( NGG_VIDO_YRES,         854),                          \
  NG_CFG( NGG_VIDO_SPEC2,        1),                            \
  NG_CFG( NGG_VIDO_SPECPTR1,     "/dev/fb0"),

/*---------------------------------------------------------------------------*/
/*                                 NexGenCOREGUI                             */
/*---------------------------------------------------------------------------*/

#define GUIO_INPUT_TASK_PRIO     202
#define GUIO_INPUT_STK_SIZE      2048

/* Timer Module */
#define TIMERO_TASK_PRIO         70
#define TIMERO_STK_SIZE          2048


/*---------------------------------------------------------------------------*/
/*                                 NexGenWIDGETK                             */
/*---------------------------------------------------------------------------*/

    /* allocate a 4*64 Kb heap, partitionned in 32 bytes cells. */
#define NGW_HEAP_SIZE            (4 * 0x10000)
#define NGW_HEAP_ADDED           (4 * 0x10000)

#define NGW_HEAP_BLOCK_SIZE      0x20
