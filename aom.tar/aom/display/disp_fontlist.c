/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/26 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------
   PUBLIC NAMES: file with font list descriptions
  ---------------------------------------------------------------------------*/

//
// wildcard (chi, kor, jap, ...) -----+
//                                    |
//                                    v
#define L10N_FONT_LIST_CHI      "l10n_chi_fontlist.txt" //"l10n_*_fontlist.txt"
#define L10N_FONT_LIST_JPN      "l10n_jpn_fontlist.txt"
#define L10N_FONT_LIST_KOR      "l10n_kor_fontlist.txt"

#define BASE_FONT_LIST          "base_fontlist.txt"

/*-----------------------------------------------------------------------------
   PUBLIC NAMES: strings to build the font named above
  ---------------------------------------------------------------------------*/

#define PATTERN_LIST            "FONT_LIST"


/*-----------------------------------------------------------------------------
   le fichier d'entree:

FONTLIST 1

#----------------------------------------------------------------------
# for the lists after the filenames,
# they indicate in which list a font must be added
# 1 <-> regular
# 2 <-> bold
# 6 <-> download3
#
# if the value is positive, it's added at the end of the list.
# if negative, it's added at the start of the list.
# (this explains why they are not numbered from 0 to 5)
#----------------------------------------------------------------------

FONT_LIST_D:

#--------------------- partie libre
12=NOEchineseDPriv.ngf    1  2  3  5  6
11=CyrD30.ngf            -3 -5
10=CyrD22.ngf            -1 -2 -6
9=GrecD30.ngf            -3 -5
8=GrecD22.ngf            -1 -2 -6
7=noeDspecial22.ngf      +1 +2 +3 +4 +5 +6

#--------------------- partie imposee
6=default
5=20thNormal22.ngf      -6
4=20thNormal30.ngf      -5
3=GoodTime.ngf          -4
2=20thNormal30.ngf      -3
1=20thNormal22.ngf      -2
0=20thNormal22.ngf      -1


FONT_LIST_BC:

#--------------------- partie libre
14=NOEchineseCPriv.ngf          1  2  3  4  5  6
13=NOEspe.ngf                   1  2  3  4  5  6
12=NOEcyrillic02Bold.ngf       -3 -5
11=NOEcyrillic01Bold.ngf       -3 -5
10=NOEgreekBold.ngf            -3 -5
9=NOEcyrillic02.ngf            -1 -2 -4 -6
8=NOEcyrillic01.ngf            -1 -2 -4 -6
7=NOEgreek.ngf                 -1 -2 -4 -6

#--------------------- partie imposee
6=default
5=NOEregular.ngf        -6
4=NOEextrabold.ngf      -5
3=NOEregular.ngf        -4
2=NOEextrabold.ngf      -3
1=NOEhomebar.ngf        -2
0=NOEregular.ngf        -1

-----------------------------------------------------------------------------*/
#include <stdlib.h>
#include <stdio.h>

#include "stdinc.h"
#include "log.h"
#include "configs.h"
#include "rofs.h"

#if defined(DISPLAY)

/* NexGenOS includes */
#include <ngos2.h>
#include <ngerrno.h>
#include <ngstdlib.h>
#include <ngfsio.h>
#include <ngshell.h>

#include <ngos.h>
#include <nggraph.h>
#include <ngfonts.h>
#include <nggraph/bmfm2.h>

#endif

#include "display.h"
#include "disp_priv.h"

/*-----------------------------------------------------------------------------
   LOCAL DEFAULT CONSTANTS: last chance fonts
  ---------------------------------------------------------------------------*/
#include "font_default_C.h"
#if defined(NOE_D)
#  include "font_default_D.h"
#endif

/*-----------------------------------------------------------------------------

public strutures, shared between noe & nexgen:

  1) le virtual file system avec la liste des fichiers:

     NGvfsimage disp_vfs_fonts

  2) le tableau des pointeurs vers les listes de substitution:

     int * nggNOEP2NexGen[2][MAX_ENUM_fontid]

  3) le compteur de fontes:

     disp_fonts_max

  4) le flag de transcodage prive

     ngg_prv2std_enable
-----------------------------------------------------------------------------*/

// XTSce65689+
//bool_t ngg_prv2std_enable = TRUE;
bool_t ngg_prv2std_enable = FALSE;
// XTSce65689-

uint32_t disp_max_fonts= 0;

int * nggNOEP2NexGenSubst[MAX_ENUM_fontid] = {
                    NULL,      //FONT_REGULAR
                    NULL,      //FONT_BOLD
                    NULL,      //FONT_EXTRABOLD
                    NULL,      //FONT_DOWNLOAD1
                    NULL,      //FONT_DOWNLOAD2
                    NULL       //FONT_DOWNLOAD3

           };

NGvfsimage disp_vfs_fonts =
{
  NULL,         /* const NGvfsfile *vfsimg_data;       list of files */
  NULL          /* const NGushort  *vfsimg_compdata;   compression info */
};


/*---------------------------------------------------------------------------
                         Pseudo file system, for fonts

  > quand on a 15 fontes, on fait
  >
  > NGW_CFG( NGWP_DTEXT_FONT_MAX, 14)     0 a 14

 ---------------------------------------------------------------------------*/


/*-----------------------------------------------------------------------------
   LOCAL DEFAULT VALUES: to be used when description files are missing
  ---------------------------------------------------------------------------*/

#if defined(NOE_D)

static const int default_NOED_Regular_FontId  [] = { 0, NGG_INVALID_FONTID};
static const int default_NOED_Bold_FontId     [] = { 1, NGG_INVALID_FONTID};
static const int default_NOED_ExtraBold_FontId[] = { 2, NGG_INVALID_FONTID};
static const int default_NOED_Download1_FontId[] = { 3, NGG_INVALID_FONTID};
static const int default_NOED_Download2_FontId[] = { 4, NGG_INVALID_FONTID};
static const int default_NOED_Download3_FontId[] = { 5, NGG_INVALID_FONTID};

static const NGvfsfile default_ngvfs_file_tabD[] = {

  { "/defaultD", NG_VFSFILE_NORMAL, (unsigned char*)font_default_D, FONT_DEFAULT_D_SIZE, FONT_DEFAULT_D_CTIME},    // 6
  { "/defaultD", NG_VFSFILE_NORMAL, (unsigned char*)font_default_D, FONT_DEFAULT_D_SIZE, FONT_DEFAULT_D_CTIME},    // 5
  { "/defaultD", NG_VFSFILE_NORMAL, (unsigned char*)font_default_D, FONT_DEFAULT_D_SIZE, FONT_DEFAULT_D_CTIME},    // 4
  { "/defaultD", NG_VFSFILE_NORMAL, (unsigned char*)font_default_D, FONT_DEFAULT_D_SIZE, FONT_DEFAULT_D_CTIME},    // 3
  { "/defaultD", NG_VFSFILE_NORMAL, (unsigned char*)font_default_D, FONT_DEFAULT_D_SIZE, FONT_DEFAULT_D_CTIME},    // 2
  { "/defaultD", NG_VFSFILE_NORMAL, (unsigned char*)font_default_D, FONT_DEFAULT_D_SIZE, FONT_DEFAULT_D_CTIME},    // 1
  { "/defaultD", NG_VFSFILE_NORMAL, (unsigned char*)font_default_D, FONT_DEFAULT_D_SIZE, FONT_DEFAULT_D_CTIME},    // 0

  { NULL                    , 0, NULL, 0UL, 0UL }
};

#endif

static const int default_NOEBC_Regular_FontId  [] = { 0, NGG_INVALID_FONTID};
static const int default_NOEBC_Bold_FontId     [] = { 1, NGG_INVALID_FONTID};
static const int default_NOEBC_ExtraBold_FontId[] = { 2, NGG_INVALID_FONTID};
static const int default_NOEBC_Download1_FontId[] = { 3, NGG_INVALID_FONTID};
static const int default_NOEBC_Download2_FontId[] = { 4, NGG_INVALID_FONTID};
static const int default_NOEBC_Download3_FontId[] = { 5, NGG_INVALID_FONTID};

static const NGvfsfile default_ngvfs_file_tabBC[] = {

  { "/defaultC", NG_VFSFILE_NORMAL, (unsigned char*)font_default_C, FONT_DEFAULT_C_SIZE, FONT_DEFAULT_C_CTIME},    // 6
  { "/defaultC", NG_VFSFILE_NORMAL, (unsigned char*)font_default_C, FONT_DEFAULT_C_SIZE, FONT_DEFAULT_C_CTIME},    // 5
  { "/defaultC", NG_VFSFILE_NORMAL, (unsigned char*)font_default_C, FONT_DEFAULT_C_SIZE, FONT_DEFAULT_C_CTIME},    // 4
  { "/defaultC", NG_VFSFILE_NORMAL, (unsigned char*)font_default_C, FONT_DEFAULT_C_SIZE, FONT_DEFAULT_C_CTIME},    // 3
  { "/defaultC", NG_VFSFILE_NORMAL, (unsigned char*)font_default_C, FONT_DEFAULT_C_SIZE, FONT_DEFAULT_C_CTIME},    // 2
  { "/defaultC", NG_VFSFILE_NORMAL, (unsigned char*)font_default_C, FONT_DEFAULT_C_SIZE, FONT_DEFAULT_C_CTIME},    // 1
  { "/defaultC", NG_VFSFILE_NORMAL, (unsigned char*)font_default_C, FONT_DEFAULT_C_SIZE, FONT_DEFAULT_C_CTIME},    // 0

  { NULL                    , 0, NULL, 0UL, 0UL }
};

/*-----------------------------------------------------------------------------
   UTILITY LOCAL VARIABLES:
  ---------------------------------------------------------------------------*/

/* the following two variables are used only when cretaing the
 * substitution lists. they could be dynamically allocated and freed
 */
static unsigned char fontlist_mallocSize[MAX_ENUM_fontid] = {
        0,
        0,
        0,
        0,
        0,
        0
    };

static unsigned char fontlist_usedSize[MAX_ENUM_fontid] = {
        0,
        0,
        0,
        0,
        0,
        0
    };

/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: read whole file in a malloc'ed buffer.

   this is needed by the analysis fonction which replaces end of lines
   with '\0' characters.
  ---------------------------------------------------------------------------*/

static char *getfile(const char *name, int *len)
{
    FILE_t *file;

    file = rofs_open(ROFS_RSC_FONT, (char *)name);
    if (file != NULL)
    {
        int   buflen = (rofs_fsize(file) + 1);
        char *bufptr = pw_malloc(buflen);

        rofs_fread(file, bufptr, buflen);

        *len = buflen;
        rofs_close(file);
        return bufptr;
    }
    *len = 0;
    return NULL;
}


/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: read one line from the file

   returns a pointer to the beginning of the line.
   the end of the line is marked with a '\0'
  ---------------------------------------------------------------------------*/

static char *__getline(int len, char *buf)
{
    char *ptr = buf;

    if ('\0' == *ptr)
        return NULL;

    while(len)
    {
        if ((*ptr == '\n') || (*ptr == '\r') || (*ptr == '\0'))
        {
            *ptr = '\0';
            return buf;
        }
        len--;
        ptr++;
    }
    return NULL;
}


/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: extend a font substitution list if needed

  should never occur.
  ---------------------------------------------------------------------------*/
static void substlist_extend_if_needed(unsigned int listIndex)
{
    if ((1 + fontlist_usedSize[listIndex]) > fontlist_mallocSize[listIndex])
    {
        fontlist_mallocSize[listIndex] += (10 * sizeof(int));
        if (nggNOEP2NexGenSubst[listIndex] == NULL){
        nggNOEP2NexGenSubst[listIndex] = pw_malloc(
                             fontlist_mallocSize[listIndex]);
        }
        else{
        nggNOEP2NexGenSubst[listIndex] = pw_realloc(nggNOEP2NexGenSubst[listIndex],
                             fontlist_mallocSize[listIndex]);
        }
        LOGI("nggNOEP2NexGenSubst[%d] allocate memory: %d",
            listIndex, fontlist_mallocSize[listIndex]);
    }
}

/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: append a value in a font substitution list
  ---------------------------------------------------------------------------*/
static void substlist_append(unsigned int listIndex, unsigned int fontId)
{
    substlist_extend_if_needed(listIndex);

    nggNOEP2NexGenSubst[listIndex][fontlist_usedSize[listIndex]]= fontId;
    fontlist_usedSize[listIndex] ++;
}


/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: prepend a value in a font substitution list

   or put it at the specified place, shifting right all values from there
  ---------------------------------------------------------------------------*/
static void substlist_prepend(unsigned int listIndex, unsigned int fontId, unsigned int where)
{
    substlist_extend_if_needed(listIndex);

    memmove(    &nggNOEP2NexGenSubst[listIndex][where+1],
                &nggNOEP2NexGenSubst[listIndex][where],
                (fontlist_usedSize[listIndex] - where) * sizeof(int));

    nggNOEP2NexGenSubst[listIndex][where]= fontId;
    fontlist_usedSize[listIndex] ++;
}

/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: parse a substitution line and fill the appropriate
                    substitution lists
  ---------------------------------------------------------------------------*/

static void substlist_parse(unsigned int fontId, char *line)
{
    const char *sep= " \t";

    char *tok = NULL;
    char *bkt = NULL;

    tok = strtok_r(line, sep, &bkt);

    while (NULL != tok)
        {
        int substitutedFontId = 0;
        int where = 0;
        int nb;
        nb = sscanf(tok, "%d=%d", &substitutedFontId, &where);
        if (2 == nb)
        {
            substlist_prepend(substitutedFontId - 1, fontId, where);
        }
        else
        {
            if (substitutedFontId > 0)
                {
                substlist_append(substitutedFontId - 1, fontId);
                }
            else
                {
                substlist_prepend(-substitutedFontId - 1, fontId, where);
                }
        }
        tok = strtok_r(NULL, sep, &bkt);
    }

    return;
}
/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: find the font file and fill the vfs entry

   If the font file is not found, it is replaced by the default font
   from code, which is always present.
   This is done with a warning, except if the file name is "default",
   to allow the insertion of the default font in the list on purpose.
  ---------------------------------------------------------------------------*/


static void find_fontfile(unsigned int listIndex, const char *fontname)
{
    FILE_t    *file      = NULL;
    char      *fn        = NULL;
    NGvfsfile *vfs_entry = (NGvfsfile *)&(disp_vfs_fonts.vfsimg_data[listIndex]);

    if (NULL != vfs_entry->vf_path)
    {
        LOGE("index %d already in use by %s!",
            listIndex, vfs_entry->vf_path);
    }

    fn = pw_malloc(strlen(fontname)+2);
    if (NULL == fn)
    {
        return;
    }

    sprintf(fn, "/%s", fontname);
    vfs_entry->vf_path = fn;
    LOGI("fontname: %s, listIndex: %d,vfs_entry->vf_path: %s",
        fontname, listIndex, vfs_entry->vf_path);

    if (strcasecmp(fontname, "default") != 0)
        file = rofs_open(ROFS_RSC_FONT, fontname);

    if (file == NULL)
    {
        if (strcasecmp(fontname, "default") != 0)
        {
            LOGE("%s replaced!", fontname);
        }

        // on prend la petite police embarquée avec le code lui meme:
        vfs_entry->vf_data = (unsigned char *)font_default_D;
        vfs_entry->vf_len  = FONT_DEFAULT_D_SIZE;
        LOGI("fontlist[%d]: default", listIndex);
    }
    else
    {
        vfs_entry->vf_len  = rofs_fsize(file);
        vfs_entry->vf_data = pw_malloc(vfs_entry->vf_len);

        rofs_fread(file, (char *)vfs_entry->vf_data, vfs_entry->vf_len);
        rofs_close(file);
        LOGI("fontlist[%d]: %s", listIndex, fontname);
    }
}


/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: parse fontlist file

   un poil de plus et je passe a lex et yacc... ce serait plus simple!
  ---------------------------------------------------------------------------*/

#define PREP_LINE_AND_NEXT_LINE \
        l = strlen(str);        \
        len -= (l + 1);         \
        ptr += (l + 1);

static bool_t parse_file(char *filename)
{
    int   buflen;
    char *bufptr;
    const char *set_pattern;
    int   new_max_fonts= 0;
    int   old_max_fonts= disp_max_fonts;

    /* automaton states:
      +--------+--------+---------------------------+
      | found1 | found2 |
      +--------+--------+---------------------------+
      |   0    |   0    | initial state
      |   1    |   0    | parsing list
      |   1    |   1    | fini
      +--------+--------+---------------------------+
     */
    int found1= 0;
    int found2= 0;

    set_pattern = PATTERN_LIST;

    LOGI("FONTLIST: parse_file (%s)", filename);
    bufptr = getfile(filename, &buflen);
    if (bufptr != NULL)
    {
        int   l;
        int   len = buflen;
        char *ptr = bufptr;
        char *str = NULL  ;

        /* FIRST, we insist in verifying the magic mark at the start of the file */
        str = __getline(len, ptr);

        if ((NULL == str) || (strncasecmp(str, "FONTLIST ", 9) != 0))
        {
            pw_free(bufptr);
            LOGE("not a FONTLIST file %s!", filename);
            return FALSE;
        }

        PREP_LINE_AND_NEXT_LINE;

        /* SECOND, we read the file one line at a time */
        int linenum = 1;
        while((str = __getline(len, ptr)) != NULL)
        {
            linenum++;
            PREP_LINE_AND_NEXT_LINE;

            if (str[0] == '#' ) continue;
            if (str[0] == '\n') continue;

            if (found2 >= 1)
                {
                continue;
                }

            if (found1 >= 1)  /* we start reading the font list */
                {
#define FONTNAME_MAX_LEN 80
                char fontname [FONTNAME_MAX_LEN+1];
                char fontsubst[FONTNAME_MAX_LEN+1];
                int res;
                int fontId;
                int i,j;
                /* syslog(FLUX_DISPLAY, LOG_DEBUG, "parsing %s!", str); */

                memset(fontname , 0, sizeof(fontname));
                memset(fontsubst, 0, sizeof(fontsubst));

                /* looking for '=' to know if it is a font line or not: */
                for (i= 0 ; i < l ; i++)
                {
                    if (str[i] == '=') break;
                }
                if (i == l)
                {
                    LOGD("not a font line: skipping (%s:%d) at line %d", str, l, linenum);
                    continue;
                }

                /* extract before the '=' */
                str[i++]= '\0';
                fontId= (int)atol(str) - 1; /* dans le fichier 1..max */

                /* is there a substitution list? */
                for (j= i ; j < l ; j++)
                    {
                    if ((str[j] == ' ') || (str[j] == '\t')) break;
                    }
                if (j == l) /* no */
                    {
                    strncpy(fontname, &str[i], FONTNAME_MAX_LEN);
                    fontsubst[0] = '\0';
                    res= 2;
                    }
                else /* yes */
                    {
                    str[j++]= '\0';
                    strncpy(fontname , &str[i], FONTNAME_MAX_LEN);
                    strncpy(fontsubst, &str[j], FONTNAME_MAX_LEN);
                    res= 3;
                    }
                /* line parsing is done */

                    {
                    if (found1 == 1)
                        {
                        int size;
                        // exemple: 1 fonte  1=xxx, on se retrouve avec fontId= 0!
                        new_max_fonts   = fontId;
                        disp_max_fonts += fontId + 1;
                        if (disp_vfs_fonts.vfsimg_data == NULL)
                            {
                            disp_vfs_fonts.vfsimg_data = pw_malloc(
                                (disp_max_fonts+1)*sizeof(NGvfsfile));
                            if (disp_vfs_fonts.vfsimg_data == NULL)
                                  {
                                    LOGE("malloc failed");
                                    pw_free(bufptr);
                                    return FALSE;
                                  }
                            }
                        else
                            {
                            disp_vfs_fonts.vfsimg_data= pw_realloc(
                                (uint8_t *)disp_vfs_fonts.vfsimg_data,
                                (disp_max_fonts+1)*sizeof(NGvfsfile));
                            }
                        if (old_max_fonts > 0)
                            {
                            memmove(
                                (uint8_t *)&(disp_vfs_fonts.vfsimg_data[new_max_fonts+1]),
                                &(disp_vfs_fonts.vfsimg_data[0]),
                                (old_max_fonts+1)*sizeof(NGvfsfile));
                            memset(
                                  (uint8_t *)&(disp_vfs_fonts.vfsimg_data[0]),
                                  0,
                                  (new_max_fonts+1)*sizeof(NGvfsfile));
                            LOGI("FONTLIST: clearing %d entries", new_max_fonts+1);
                            }
                        size = disp_max_fonts * sizeof(int);
                        {
                        int k;
                        for (k= 0 ; k < MAX_ENUM_fontid ; k++)
                            {
                            if ( nggNOEP2NexGenSubst[k] == NULL )
                                {
                                nggNOEP2NexGenSubst[k]= pw_malloc(size);
                                }
                            else
                                {
                                nggNOEP2NexGenSubst[k]= pw_realloc(
                                    nggNOEP2NexGenSubst[k], size);
                                }
                            LOGI("nggNOEP2NexGenSubst[%d] allocate memory: %d", k, size);
                            fontlist_mallocSize[k]= size;
                            }
                        }
                        }
                    found1 ++;
                    if (res == 3)
                        {
                        /* there is a substitution list */
#if 0
                        syslog(FLUX_DISPLAY, LOG_ANOMALY,
                              "font %s: goes in %s", fontname, fontsubst);
#endif
                        substlist_parse(fontId+old_max_fonts, fontsubst);
                        }
                    if (0 == fontId)
                        {
                        found2= 1;
                        }
                    find_fontfile(new_max_fonts - fontId, fontname);
                    }
                continue;
                }

            // loop until interesting part is found:
            if (strncasecmp(set_pattern, str, strlen(set_pattern)) == 0)
                {
                found1 = 1;
                continue;
                }
        }
        pw_free(bufptr);
        // sanity check: we could have missed some of the fonts
        if (found2)
            {
            int i;
            // add the end of substitution list mark in all lists
            for (i= 0 ; i < MAX_ENUM_fontid ; i++)
                {
                nggNOEP2NexGenSubst[i][fontlist_usedSize[i]]= NGG_INVALID_FONTID;
                }
            LOGI("FONTLIST: parse_file done OK");
            return TRUE;
            }
        else
            {
            LOGE("FONTLIST: parse_file done KO");
            return FALSE;
            }
    }
    LOGE("FONTLIST: parse_file: file not found <%s> !", filename);
    return FALSE;
}

/*-----------------------------------------------------------------------------
   LOCAL PROCEDURE: set default values from code constants (bof)

  in fact, this proc sets all defaults that could have not been settled
  elsewhere: if the pointer is null, it is initialized with the default;
  else, it is kept unchanged.

  ---------------------------------------------------------------------------*/
#define mallocCpyDefaults(i,r)                                                     \
  if (NULL == nggNOEP2NexGenSubst[i])                                      \
    {nggNOEP2NexGenSubst[i] = pw_malloc(sizeof(default_##r));                 \
     memcpy(nggNOEP2NexGenSubst[i], default_##r, sizeof(default_##r)); }

static void setDefaults(void)
{
    mallocCpyDefaults(0,NOED_Regular_FontId)
    mallocCpyDefaults(1,NOED_Bold_FontId)
    mallocCpyDefaults(2,NOED_ExtraBold_FontId)
    mallocCpyDefaults(3,NOED_Download1_FontId)
    mallocCpyDefaults(4,NOED_Download2_FontId)
    mallocCpyDefaults(5,NOED_Download3_FontId)

    if (NULL == disp_vfs_fonts.vfsimg_data)
    {
        disp_vfs_fonts.vfsimg_data= pw_malloc(sizeof(default_ngvfs_file_tabD));
        memcpy((unsigned char*)disp_vfs_fonts.vfsimg_data, default_ngvfs_file_tabD, sizeof(default_ngvfs_file_tabD));
    }

    disp_vfs_fonts.vfsimg_compdata= NULL;
}


/*-----------------------------------------------------------------------------
   PRIVATE PROCEDURE: do the real job
  ---------------------------------------------------------------------------*/
static bool_t _fontlist_init(void)
{
    disp_max_fonts= 0;

    // do not load any loc font if no base fonts
    //TODO: if (rofs_is_valid(ROFS_APPDATA))
    if (! parse_file(BASE_FONT_LIST))
    {
        LOGE("no or bad %s file!", BASE_FONT_LIST);
    }

    // try to read base description:
    setDefaults();

    return FALSE;
}

/*-----------------------------------------------------------------------------
   PUBLIC PROCEDURE: do the real job
  ---------------------------------------------------------------------------*/
void disp_fontlist_init(void)
{
    int        Index= 0;
    NGvfsfile *ngvfs_file_tab;
    bool_t     res;

    res= _fontlist_init();
    LOGD("_fontlist_init() return %d", res);

    ngvfs_file_tab= (NGvfsfile *)disp_vfs_fonts.vfsimg_data;

    // on recompter les fontes pour etre vraiment sur!

    while(ngvfs_file_tab[Index].vf_path != NULL)
    {
        Index ++;
    }

    if (disp_max_fonts != (Index - 1))
        {
        LOGI("disp_max_fonts bad: %d != %d",
               disp_max_fonts, Index - 1);
        }

    disp_max_fonts= Index - 1;

    LOGI("nb individual fonts: %d [0..%d]",
                Index, disp_max_fonts);
}

/*-----------------------------------------------------------------------------
   PUBLIC PROCEDURE: on host mainly, destroy all dinamically allocated strings
  ---------------------------------------------------------------------------*/

void disp_fontlist_end(void)
{
    int i;

    /* les chaines de substitution sont dynamique */
    for(i = 0 ; i < MAX_ENUM_fontid ; i++)
    {
        if (NULL != nggNOEP2NexGenSubst[i])
        {
            pw_free(nggNOEP2NexGenSubst[i]);
            nggNOEP2NexGenSubst[i]= NULL;
        }
    }

    /* les noms de fichiers sont dynamiques */

    i = 0;

    /* la structure principale du rofs est dynamique */

    if (NULL != disp_vfs_fonts.vfsimg_data)
    {
        while(NULL != disp_vfs_fonts.vfsimg_data[i].vf_path)
        {
            pw_free(disp_vfs_fonts.vfsimg_data[i].vf_path);
            i++;
        }
        pw_free(disp_vfs_fonts.vfsimg_data);
        disp_vfs_fonts.vfsimg_data = NULL;
    }
}
