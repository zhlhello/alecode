/*-----------------------------------------------------------------------------

   COMPONENT:      NOEMMI

   MODULE:         rofs_r.c

   DATED:          2012/08/24

   AUTHOR:         G. Yu

   DESCRIPTION:    to replace the NOE read-only file system implementation

   HISTORY:

    - creation   2012/08/24

    - 2016/06/08 bertin
      Refactor (mainly rofs_list() and rofs_close_fp() routines)

    - 2016/12/15 cbacher
      Refactor rofs_open / rofs_list functions
      Add function to create path to file depending of resource type and custo
      Add defines about resources type directory

-----------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <stdlib.h>
#include <dirent.h>
#include <unistd.h>

#include "stdinc.h"
#include "log.h"
#include "configs.h"

#include "rofs.h"
#include "skins.h"

//
// root path to resources
//
#if defined(HOST)
#  define ROOT_RESOURCES_DIR   "resources"
#else
#  define ROOT_RESOURCES_DIR   "/oem/resources"
#endif

#define ROOT_RESOURCES_DIR_CUST "/data/cust"

#define BOOT_DIR        "image.png"
#define BOOT_DIR_CUST   "display/boot"
#define IMG_DIR         "image.png"
#define IMG_DIR_CUST    "display/screensaver"
#define SKIN_DIR        "skins.png"
#define SKIN_DIR_CUST   "display/skin"
#define ICON_DIR        "icons.png"
#define ICON_DIR_CUST   "display/icons"
#define AUDIO_DIR       ""
#define AUDIO_DIR_CUST  "audio/ringing"

#define FONT_DIR        "fonts.ngf"
#define DICT_DIR        "languages"

/*-----------------------------------------------------------------------------
  Create path to file
  ---------------------------------------------------------------------------*/
char * rofs_make_path(char *dest, rofs_rsc_t rsc_type, const char* filename, bool_t custo)
{
    char *p = dest;

    if (custo) {
        p += sprintf(p, "%s/", ROOT_RESOURCES_DIR_CUST);
        switch (rsc_type) {
            case ROFS_RSC_BOOTIMAGE:
                p += sprintf(p, "%s/", BOOT_DIR_CUST);
                break;
            case ROFS_RSC_IMAGE:
                p += sprintf(p, "%s/", IMG_DIR_CUST);
                break;
            case ROFS_RSC_SKIN:
            case ROFS_RSC_SKININFO:
                p += sprintf(p, "%s/", SKIN_DIR_CUST);
                break;
            case ROFS_RSC_ICON:
                p += sprintf(p, "%s/", ICON_DIR_CUST);
                break;
            case ROFS_RSC_AUDIO:
                p += sprintf(p, "%s/", AUDIO_DIR_CUST);
                break;
            default:
                p += sprintf(p, "%s/", "");
                LOGW("rofs_make_path: %d type doesn't support customization", rsc_type);
                break;
        }
    } else {
        p += sprintf(p, "%s/" , ROOT_RESOURCES_DIR);
        switch (rsc_type) {           
            case ROFS_RSC_BOOTIMAGE:
                p += sprintf(p, "%s/", BOOT_DIR);
                break;
            case ROFS_RSC_IMAGE:
                p += sprintf(p, "%s/", IMG_DIR);
                break;
            case ROFS_RSC_SKIN:
                p += sprintf(p, "%s/%d/", SKIN_DIR, skinsinfo_get_baseskin(ID_CURR_SKIN));
                break;
            case ROFS_RSC_SKININFO:
                p += sprintf(p, "%s/", SKIN_DIR);
                break;
            case ROFS_RSC_ICON:
                p += sprintf(p, "%s/%d/", ICON_DIR, skinsinfo_get_iconsset(ID_CURR_SKIN));
                break;
            case ROFS_RSC_AUDIO:
                p += sprintf(p, "%s/", AUDIO_DIR);
                break;
            case ROFS_RSC_FONT:
                p += sprintf(p, "%s/", FONT_DIR);
                break;
            case ROFS_RSC_DICT:
                p += sprintf(p, "%s/", DICT_DIR);
                break;
            default:
                p += sprintf(p, "%s/", "");
                LOGW("rofs_make_path: %d type doesn't support customization", rsc_type);
                break;
        }
    }

    p += snprintf(p, _MAX_FILENAME_LEN_, "%s", filename);

    return dest;
}

/*-----------------------------------------------------------------------------
  Open file
  ---------------------------------------------------------------------------*/
static FILE_t *__rofs_open_file(const char *path, bool_t custo)
{
    FILE_t *file;

    if (path == NULL) {
        LOGE("rofs_open_file: filename = null");
        return NULL;
    }

    if (strlen(path) >= _MAX_FILENAME_LEN_)
    {
        LOGE("Filename %s length error", path);
        return NULL;
    }

    file = pw_malloc(sizeof(FILE_t));
    if (file == NULL) {
        LOGE("rofs_open_file: pw_malloc failed");
        return NULL;
    }

    //Add a test to check if the file exist before try to open it
    //Custo : Avoid logs in Defence when file isn't customized
    //Not Custo : Error - should be checked
    if( access( path, F_OK ) == -1 ) {
        if (custo) {
            LOGI("rofs_open_file: file(%s) doesn't exist in customization", path);
            pw_free(file);
            return NULL;
        } else {
            LOGE("rofs_open_file: file(%s) doesn't exist", path);
            pw_free(file);
            return NULL;
        }
    }

    file->fp = fopen(path, "r");
    if (file->fp == NULL) {
        LOGE("rofs_open_file: open(%s) failed", path);
        pw_free(file);
        return NULL;
    }
    

    fseek(file->fp, 0, SEEK_END);
    file->file_size = ftell(file->fp);
    fseek(file->fp, 0, SEEK_SET);

    strcpy(file->file_name, path);

    return file;
}

/*-----------------------------------------------------------------------------
  Open file
  ---------------------------------------------------------------------------*/
FILE_t *rofs_open(rofs_rsc_t rsc_type, const char *filename)
{
    char pathname[_MAX_FILENAME_LEN_] = "";
    FILE_t *file;

    switch (rsc_type) {
        case ROFS_RSC_BOOTIMAGE:
        case ROFS_RSC_AUDIO:
            break;
        case ROFS_RSC_IMAGE:
        case ROFS_RSC_SKIN:
            if (CONFIG_get_use_customisation() == TRUE){
                rofs_make_path(pathname, rsc_type, filename, TRUE);
                file = __rofs_open_file(pathname, TRUE);
                if (file == NULL) {
                    rofs_make_path(pathname, rsc_type, filename, FALSE);
                    file = __rofs_open_file(pathname, FALSE);
                }
            } else {
                rofs_make_path(pathname, rsc_type, filename, FALSE);
                file = __rofs_open_file(pathname, FALSE);
            }
            break;
        case ROFS_RSC_ICON:
            rofs_make_path(pathname, rsc_type, filename, TRUE);
            file = __rofs_open_file(pathname, TRUE);
            if (file == NULL) {
                rofs_make_path(pathname, rsc_type, filename, FALSE);
                file = __rofs_open_file(pathname, FALSE);
            }
            break;            
        case ROFS_RSC_FONT:
        case ROFS_RSC_DICT:
            rofs_make_path(pathname, rsc_type, filename, FALSE);
            file = __rofs_open_file(pathname, FALSE);
            break;
        default:
            LOGW("Unknown resources type : %d", rsc_type);
            file = NULL;
            break;
    }
    return file;
}


/*-----------------------------------------------------------------------------
  Close file
  ---------------------------------------------------------------------------*/
int rofs_close(FILE_t *file)
{
    if (file == NULL) {
        LOGE("rofs_close: handle = null");
        return -1;
    }

    if (file->fp != NULL)
        fclose(file->fp);

    if (file->faddr_mem != NULL)
        pw_free(file->faddr_mem);

    memset(file, 0, sizeof(FILE_t));
    pw_free(file);

    return 0;
}

/*-----------------------------------------------------------------------------
  Return file size
  ---------------------------------------------------------------------------*/
int rofs_fsize(FILE_t *file)
{
    if (file == NULL) {
        LOGE("rofs_fsize: handle = null");
        return -1;
    }
    return file->file_size;
}

/*-----------------------------------------------------------------------------
  Read file content and return a pointer to internal allocated memory.
  This memory is deallocated when file is closed (rofs_close)
  ---------------------------------------------------------------------------*/
const unsigned char *rofs_faddr(FILE_t *file)
{
    if (file == NULL) {
        LOGE("rofs_faddr: handle = null");
        return NULL;
    }

    if (file->faddr_mem == NULL) {
        int size = rofs_fsize(file);

        if (size > 0) {
            int r;

            file->faddr_mem = (char *)pw_malloc(size);
            if (file->faddr_mem == NULL) {
                LOGE("rofs_faddr: pw_malloc failed");
                return NULL;
            }
            r = fread(file->faddr_mem, 1, size, file->fp);
            if (r != size) {
                LOGE("rofs_faddr: read failed");
                pw_free(file->faddr_mem);
                file->faddr_mem = NULL;
                return NULL;
            }
        }
    }
    return (unsigned char *)file->faddr_mem;
}

/*-----------------------------------------------------------------------------
  Read file content into the provided memory
  ---------------------------------------------------------------------------*/
int rofs_fread(FILE_t *file, char *dstptr, int dstlen)
{
    int size;

    if (file == NULL) {
        LOGE("rofs_fread: handle = null");
        return -1;
    }

    if (dstptr == NULL) {
        LOGE("rofs_fread: dstptr = null");
        return -1;
    }

    size = rofs_fsize(file);
    if (dstlen < size) {
        LOGE("rofs_fread: dstptr is too small");
        return -1;
    }

    if (size > 0) {
#if 1
        int r;
        r = fread(dstptr, 1, size, file->fp);
        if (r != size) {
            LOGE("rofs_fread: read failed");
            return -1;
        }
#else
        memcpy(dstptr, rofs_faddr(file), dstlen);
#endif
    }
    return size;
}

/*-----------------------------------------------------------------------------
  Iterate the specified directory and callback when a file matching the given
  prefix is found
  ---------------------------------------------------------------------------*/
int rofs_list(rofs_rsc_t rsc_type, const char *prefix,
    void (*cb)(const char *prefix, const char *filename)
)
{
    char           dirname[_MAX_FILENAME_LEN_];
    DIR           *dir;
    struct dirent *dirent;

    if (cb == NULL) {
        LOGE("rofs_list: cb = null");
        return -1;
    }

    switch (rsc_type) {
        case ROFS_RSC_ICON:
            rofs_make_path(dirname, rsc_type, "", FALSE);
            break;
        default:
            LOGE("rofs_list: rsc_type(%d) not supported", rsc_type);
            break;
    }
    dir = opendir(dirname);
    if (dir == NULL) {
        LOGE("rofs_list: opendir(%s) failed", dirname);
        return -1;
    }

    while(NULL != (dirent = readdir(dir))) {
        if ((dirent->d_type == DT_REG) ||(dirent->d_type == DT_LNK) ||(dirent->d_type == DT_UNKNOWN)) {//for AOM, icon is a softlink
            if (strncmp(prefix, dirent->d_name, strlen(prefix)) == 0)
                cb(prefix, dirent->d_name);
        }
    }
    closedir(dir);
    return 0;
}

/*-----------------------------------------------------------------------------
  Initialization
  ---------------------------------------------------------------------------*/
void init_rofs()
{
}

/*-----------------------------------------------------------------------------
  Cleanup
  ---------------------------------------------------------------------------*/
void term_rofs()
{
}

/*-----------------------------------------------------------------------------
  Returns TRUE if the specified ROFS exists
  ---------------------------------------------------------------------------*/
bool_t rofs_is_present(rofs_id_t id)
{
    LOGI("rofs_is_present(%id)", id);
    return TRUE;
}


/*-----------------------------------------------------------------------------
  O L D  S T U F F S
  ---------------------------------------------------------------------------*/
bool_t __rofs_check__(const char *p_binary)
{
    LOGI("TODO: __rofs_check__()");
    return TRUE;
}

void rofs_invalidate(rofs_id_t rofs_id)
{
    LOGI("TODO: rofs_invalidate()");
}
