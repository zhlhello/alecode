/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/26 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>

#include "stdinc.h"
#include "log.h"
#include "configs.h"

#if defined(DISPLAY)

/* NexGenOS includes */
#include <ngos2.h>
#include <ngerrno.h>
#include <ngstdlib.h>
#include <ngfsio.h>
#include <ngshell.h>

#include <ngos.h>
#include <ngfsio.h>
#include <ngshell.h>
#include <nggraph.h>
#include <ngvid.h>
#include <ngfonts.h>
#include <nggraph/region.h>
#include <ngwchar.h>
#include <nggraph/bmfm2.h>

extern NGGbmfontdata2  fm_data; // nginit.c

#include "noep/enums_defs.h"
extern int * nggNOEP2NexGenSubst[MAX_ENUM_fontid];

#endif

#include "display.h"
#include "disp_priv.h"


/*****************************************************************************
 * liste l'ensemnle des fontes disponibles
 *****************************************************************************/

size_t dispFontList(char *outputBuf)
{
  char * p= outputBuf;

#if defined(DISPLAY)

  NGGbitmapfont2 **font;
  int nb, i;

  const NGvfsfile *vfsFilePtr;

  vfsFilePtr= disp_vfs_fonts.vfsimg_data + disp_max_fonts;

  font = NG_BM2FONT_DATA(&fm_data, md_fonttable);
  nb = NG_BM2FONT_DATA(&fm_data, md_nbfont);

  p += sprintf(p,
  "\n FID|     Font name      |Height|Mono|Bold|loaded|    filename           | size\n");
  p += sprintf(p,
    "----|--------------------+------+----+----+------+-----------------------+-----\n");


  for(i=0; i<nb; i++)
    {
      p += sprintf(p, "%4d|%20s|%5d |",i,
                       NG_BITMAPFONT2_DATA(*(font + i),font_name),
                       NG_BITMAPFONT2_DATA(*(font + i),font_height));
      if(NG_BITMAPFONT2_DATA(*(font + i),font_style) & NGG_FONT_MONOSPACED)
          p += sprintf(p, " XX |");
      else
          p += sprintf(p, "    |");
      if(NG_BITMAPFONT2_DATA(*(font + i),font_style) & NGG_FONT_BOLD)
          p += sprintf(p, " XX |");
      else
          p += sprintf(p, "    |");
      if(NG_BM2FONT_IS_DATA_LOADED(*(font + i)))
          p += sprintf(p, "  XX  |");
      else
          p += sprintf(p, "      |");
      p += sprintf(p, "%23s|", &(vfsFilePtr->vf_path[1]));
      p += sprintf(p, "%6d\n", (unsigned int)vfsFilePtr->vf_len);
      vfsFilePtr--;
    }
  p += sprintf(p, "\n");

#endif /* DISPLAY */

  return (size_t)(p - outputBuf);
}


/*****************************************************************************
 * liste les propri�t�s d'une fonte donn�e
 *****************************************************************************/

#if defined(DISPLAY)

size_t dispFontInfo(char *outputBuf, NGGfontid fid)
{
  char * p= outputBuf;

  NGGfontctx *fctx;
  NGGfontinfo finfo;
  NGGfontstyle  fstyle;
  NGGbitmapfont2 **font;
  int nb, i;

  font = NG_BM2FONT_DATA(&fm_data, md_fonttable);
  nb = NG_BM2FONT_DATA(&fm_data, md_nbfont);

  if ((fid < 0) || (fid >= nb))
    {
    p += sprintf(p, "No font ID %d found (id must be between 0 and %d)!\n",
                 fid, nb - 1);
    return (size_t)(p - outputBuf);
    }

  fctx = nggDrawGetFontCtx(global_w_ctx->drawctx);

  p += sprintf(p, "Font ID %d  ", fid);

  if(NG_EOK != nggFontGetInfo(fctx, fid, &finfo)) {
    p += sprintf(p, "nggFontGetInfo() failed !\n");
    return (size_t)(p - outputBuf);
  }

  p += sprintf(p, "-> %s\n", finfo.font_name);

  p += sprintf(p, "  font style       :");
  fstyle = finfo.font_style;
  if      (fstyle & NGG_FONT_NORMAL) p += sprintf(p, " NGG_FONT_NORMAL");
  else if (fstyle & NGG_FONT_BOLD  ) p += sprintf(p, " NGG_FONT_BOLD");
  else if (fstyle & NGG_FONT_ITALIC) p += sprintf(p, " NGG_FONT_ITALIC");

  if (fstyle & NGG_FONT_MONOSPACED) p += sprintf(p, " NGG_FONT_MONOSPACED");

  p += sprintf(p, "\n");
  p += sprintf(p, "  font name        : %s\n", finfo.font_name);
  p += sprintf(p, "  typographic size : %d\n", finfo.font_size);
  p += sprintf(p, "  font baseline    : %d pixels\n",
                 finfo.font_baseline);
  p += sprintf(p, "  font height      : %d pixels\n", finfo.font_height);
  p += sprintf(p, "  underline pos.   : %d pixels\n",
                 finfo.font_underl_pos);
  p += sprintf(p, "  underline thick. : %d pixels\n",
                 finfo.font_underl_thick);
  p += sprintf(p, "  nb of range      : %d \n",
                 (int)NG_BITMAPFONT2_DATA(*(font + fid),font_nb_range));
  for(i=0; i<NG_BITMAPFONT2_DATA(*(font + fid),font_nb_range); i++) {
    p += sprintf(p, "    range %2d: start= %5d (U+%.4x), length= %5d\n",
                 i+1,
                 NG_BITMAPFONT2_DATA(*(font + fid), font_range[i]).bmpfr_first_char,
                 NG_BITMAPFONT2_DATA(*(font + fid), font_range[i]).bmpfr_first_char,
                 NG_BITMAPFONT2_DATA(*(font + fid), font_range[i]).bmpfr_nb_char);
  }

  p += sprintf(p,"\n");

  return (size_t)(p - outputBuf);
}

#endif /* DISPLAY */


/*-----------------------------------------------------------------------------
  font command
  ---------------------------------------------------------------------------*/
#if defined(HOST) && defined(DISPLAY) && defined(PAS_POUR_L_INSTANT)
//CAP+ can not link (ld) when this define is set
//#  define WANT_ALPHA_EXPERIMENTS  1
//CAP-
#endif

#if defined(WANT_ALPHA_EXPERIMENTS)

extern NGGpixval alphaCorrection[16];

static NGGpixval alpha0[16]={ 0, 1, 2, 3, 4, 5, 6, 7, 9,10,11,12,13,14,15,16};
static NGGpixval alpha1[16]={ 1, 1, 2, 3, 4, 5, 6, 7, 9,10,11,12,13,14,15,15};
static NGGpixval alpha2[16]={ 0, 0, 1, 2, 3, 4, 5, 6, 9,10,11,12,13,14,15,16};
static NGGpixval alpha3[16]={ 0, 0, 0, 1, 2, 3, 5, 7, 9,10,11,12,13,14,15,16};
static NGGpixval alpha4[16]={ 0, 0, 0, 0, 1, 3, 5, 7, 9,10,11,12,13,14,15,16};
static NGGpixval alpha5[16]={ 0, 0, 0, 0, 0, 3, 5, 7, 9,10,11,12,13,14,15,16};
static NGGpixval alpha6[16]={ 0, 0, 0, 0, 0, 0, 0, 2, 4, 6, 9,12,13,14,15,16};
static NGGpixval alpha7[16]={ 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 6, 9,12,14,16};
static NGGpixval alpha8[16]={ 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,16};
static NGGpixval alpha9[16]={ 0,15,15,15,15,15,15,15,15,15,15,15,15,15,15,15};

typedef NGGpixval alpha_t[16];

static char cmd_fontHelp[]= "[ngId | subst | dbglvl val | alpha idx]\n";

#else

static char cmd_fontHelp[]= "[ngId | subst | dbglvl val]\n";

#endif

#if defined(DISPLAY)

/*-----------------------------------------------------------------------------
  utility function: convert from protocol font id to nexgen font id
 ----------------------------------------------------------------------------*/
int disp_i_fontIdNoe2fontIdNg(int fontIdNoep)
{
    switch (fontIdNoep)
    {
        case FONT_REGULAR        : return 0; break;
        case FONT_BOLD           : return 1; break;
        case FONT_EXTRABOLD      : return 2; break;
        case FONT_DOWNLOAD1      : return 3; break;
        case FONT_DOWNLOAD2      : return 4; break;
        case FONT_DOWNLOAD3      : return 5; break;

        case MAX_ENUM_fontid     : /* last chance font, also used for shell.
                                * special handling in gfontid2.c
                                */
                               return 6; break;

        default:
        {
            LOGE("unknown font: id=%d mapped to ROM font", fontIdNoep);
        }
        break;
    }

    return MAX_ENUM_fontid; /* default ROM font */
}


/*-----------------------------------------------------------------------------
  changement de la font de base d'un widget
 ----------------------------------------------------------------------------*/
void disp_i_setFont(NGWinstance *widget, uint8_t fontIdNoep)
{
    int fontIdNg;

    fontIdNg= disp_i_fontIdNoe2fontIdNg(fontIdNoep);

    disp_i_setprop(widget, NGWP_FONTID, (NGWPdata) fontIdNg);
}

#endif
