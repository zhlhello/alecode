/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#ifndef _DISP_PRIV_H_
#define _DISP_PRIV_H_

#include "objmgr.h"
#include "enums_defs.h"
/*=====================================================================
 * avec ou sans emulation 3g
 *=====================================================================*/
#define DISP_EMUL_3G    0    // syntaxe: 0 ou 1

#if defined(DISPLAY)


/*=====================================================================
  cree le contexte global

  Le calcul de dimensionnement du heap des fontes est le suivant:

  Pour la partie utile, il faut au minimum:

    (nb_fonts * (156 + len(font_name) + len(font_file_name))) + taille_max_font

    la granularite est de 16 .

    en general len(font_name) < 16 et len(font_file_name) < 32 (2*16)

    ce qui donne:

    (nb_fonts * (160 + 16 + 32)) + taille_max_font

    le strict minimum fonctionnel est de prendre taille_max_font egal a la
    taille de la plus grande des fontes possibles

    Ceci garantit de pouvoir charger n'importe quelle fonte, mais pour passer
    a une autre fonte, il faudra swapper.

    Le maximum utile est taille_max_font= somme des tailles pour toutes
    les police embarquees.

    taille_max_font est en fait une copie des tables internes de la fonte +
    sizeof(nggImage) - l'entete de la font

    On constate que taille_max_font est tres peu different de taille_fichier:

                        | fichier  |   malloc |
              +---------+----------+----------+
              | regular |  2950    |   2852   |
              | grec    |  1382    |   1336   |
              +---------+----------+----------+


    exemple: le strict minimum pour un C avec chinois est:

      11 * (160 + 16 + 32) + taille_fichier_chinois
      2288 + taille_fichier_chinois


  Mais il y a aussi le cout de gestion heap/malloc:

    3 mallocs_par_font x 16 octets_d'overhead_par_malloc

    soit mine de rien 528 octets pour 11 fontes, utilises rien que pour
    la gestion par malloc de ses listes de blocs, auquels il faut rajouter
    la taille du descripteur de heap, mais c'est pas grand chose
    seulement 56 octets si j'ai bien compte (dont une moitie pour
    les stats). soit au total 584 octets + 1 descripteur pour le dernier
    bloc libre (16 octets).

    (nb_fonts * 3 * 16) + 56 + 16 = nb_fonts * 48 + 72

    cout de gestion total pour 11 fontes: 600 octets

  =====================================================================

  la formule finale est donc:

  nbfonts * (256) + 74 + somme(tailles fichiers simultanes)

  =====================================================================

  exemple sur D en 2.13.02 pour ne pas swapper du tout

  8 * 256 + 74 + (35214 + 47014 + 16478 + 24170 + 2574 + 11154 + 16510 + 11142)
  = 166378

  exemple sur C en 2.13.02 pour ne pas swapper du tout

  10 * 256 + 74 + (1562 + 1862 + 1474 + 1730 + 3602 + 1382 + 1622 + 3018 + 3018 + 826)
  = 22730


 *=====================================================================*/
#include <ngvfs.h>

#define TEST_PATTERN_NEXGEN_HEAP 0x5a


//XTSce54289
/*
 * il ne faut pas etre trop optimiste:
 * sans le full chinois, on a deja 15 fontes
 * le full chinois va en faire une bonne dizaine en plus
 * soit disons 30 fonts auxquelles on rajoute 10 fontes de reserve
 * soit 40 fontes
 * en admettant que la structure de fonte n'a pas grossi, le calcul
 * reste (256 * nb_fonts) + 74
 * soit un minimum de :
 */
#define FONT_HEAP_SIZE    105000
//XTSce54348-

extern NGmemheap wdk_mh;
extern NGubyte * wdk_mh_extension;

extern NGGbmfontdata2 fm_data;
extern NGubyte        fm_heap [];

extern NGvfsimage disp_vfs_fonts ;

extern void disp_fontlist_init(void);
extern void disp_fontlist_end (void);

extern NGWctx  * disp_createContext(const char *comment);

#endif

/*-----------------------------------------------------------------------------
  enregistrement des objets
  ---------------------------------------------------------------------------*/
typedef enum
{
  DISP_TYPE_CONTEXT,
  DISP_TYPE_ENTRY,
  DISP_TYPE_FRAMEBOX,
  DISP_TYPE_ICON,
  DISP_TYPE_IMAGE,
  DISP_TYPE_LABEL,
  DISP_TYPE_LIST,
  DISP_TYPE_PINBOARD,
  DISP_TYPE_PROGRESS,
  DISP_TYPE_SLIDER,
  DISP_TYPE_STACK,
  DISP_TYPE_UNKNOWN,
  DISP_TYPE_CHECK,
  DISP_TYPE_ACTION,
  DISP_TYPE_TEXT,
  DISP_TYPE_DATE,
  DISP_TYPE_TIMER,
  DISP_TYPE_WINDOW,
  DISP_TYPE_POPUP,
  DISP_TYPE_TEL,
  DISP_TEL_ITEM,
  DISP_TYPE_DIALOG,
  DISP_TYPE_TAB,
  DISP_TYPE_HEADER
} disp_register_t;

typedef struct s_registerItem registerItem;

struct s_registerItem
{
    void            *objId;
    disp_register_t  type;
#if defined(DISPLAY)
    NGGpoint         position;
    NGGsize          size;
    NGWpalette       palette;
    uint8_t          abs_x, abs_y; // absolute coordinates
    uint8_t          width, height;// actual width and height (grid & position dependant)
    void            (*skins_on_reload_cb)(registerItem *item);
#endif
    void            *data;
    void            *hook;
    void            *callback;
    void            *cb_touch;
};


#define PRIV    ((registerItem*)item->objpriv)
#define OID     (((C_widget_t*)item->objdata)->objectid)

#define CUR_PRIV    ((registerItem*)cur_item->objpriv)
#define NEW_PRIV    ((registerItem*)new_item->objpriv)

/*-----------------------------------------------------------------------------
  variantes de la partie data d'un registerItem
  ---------------------------------------------------------------------------*/
#define ONGLETS_MAX 16

/*-----------------------------------------------------------------------------
  informations dimensions de la grille
  ---------------------------------------------------------------------------*/
typedef struct s_gridinfo
{
    uint8_t  x_max[2];
    uint8_t  y_max[2];
    uint8_t  w_max[2];
    uint8_t  h_max[2];

    int     *ygrid[2];
} gridinfo_t;

extern gridinfo_t gridinfo;

#define X_MAX(grid)    gridinfo.x_max[grid]
#define Y_MAX(grid)    gridinfo.y_max[grid]
#define W_MAX(grid)    gridinfo.w_max[grid]
#define H_MAX(grid)    gridinfo.h_max[grid]
#define YGRID(grid)    gridinfo.ygrid[grid]

extern int disp_grid_get_cell_width(void);
extern int disp_grid_get_row_height(enum_grid_type_t grid, int row);

/*-----------------------------------------------------------------------------
   gestion de la liste des objets graphiques créés

   à priori, les objets sont des 'NGWinstance *'
  ---------------------------------------------------------------------------*/
extern bool_t disp_verbose;
extern bool_t disp_hex_format;
extern size_t dispRegisterPrint(char *outBuf);

/*-----------------------------------------------------------------------------
    nettoie une structure privee du display
-----------------------------------------------------------------------------*/
extern void disp_item_delete(registerItem *rI);

#if defined(DISPLAY)

extern const NGGsize SIZE_B;
extern const NGGsize SIZE_C;
#if defined(NOE_D)
extern const NGGsize SIZE_D;
#endif

/*=====================================================================
 * supplements fournis par Nexgen
 *=====================================================================*/
extern int ngwRawWindowForceFront( NGWinstance * self, int state);

/*=====================================================================
 * creation de widgets divers
 *=====================================================================*/
extern registerItem *disp_w_list(NGWinstance *ctnr, const char *comment);

extern void nggHeaderFormat (NGGimage * pMemImage);

extern NGGimage *disp_decode(objmgr_item_t *item,
                             const unsigned char *ptrImg,
                             unsigned int sizeImg,
                             unsigned int format);

extern bool_t getNGGimage (char *, NGGimage *);

extern NGWinstance *disp_w_imagePng(
                     const unsigned char *ptrImg,
                     unsigned int sizeImg,
                     NGWinstance *conteneur, // or NULL to get a window
                     const char *comment);

extern NGWinstance *disp_w_imageNgg(const unsigned char *ptrImg,
                                    unsigned int sizeImg,
                                    NGWinstance *conteneur,
                                    const char *comment);

extern void disp_w_image_free(NGGimage *ptrImg);
extern NGGimage *disp_i_load_image(char *imagename);

extern NGGimage *disp_i_load_boot_image(char *imagename);

extern registerItem *disp_w_pinboard(NGWinstance * ctnr, const char * comment);

extern registerItem *disp_w_iconbox(NGWinstance *ctnr, const char *comment);

#define BASIC_CREATE(object,name) /* empty */

#define UPDATE_POSITION  0x01
#define UPDATE_SIZE      0x02
#define UPDATE_SIZE_HEIGHT 0x04

/*=====================================================================
 * les principaux objets globaux
 *=====================================================================*/
extern NGWinstance * dispWindow_noe;

extern uint32_t disp_max_fonts;  // ajout pour XTSce25353

/*=====================================================================
 * les palettes principales
 *=====================================================================*/

/* ces palettes servent a garantir que la conversion des images est
 * compatible avec la palette du driver video
 */
extern const NGGcolor grisNoe_palette[4];
extern const NGGcolor bwNoe_palette  [4];
extern const NGGcolor blackNoe_palette[2];

/* celles ci sont des palettes widgets
 */
extern const NGWpalette ngwPalette12bpp ;
extern const NGWpalette ngwPalette2bpp ;
extern const NGWpalette ngwPalette1bpp ;

/*=====================================================================
 * les tailles et positions principales
 *=====================================================================*/

extern const NGGsize SIZE_UNKNOWN;
extern const NGGsize SIZE_FLOAT  ;

extern const NGGpoint POS_ORIGIN;
extern const NGGpoint POS_UNKNOWN;
extern const NGGpoint POS_FLOAT;

extern NGGsize disp_size; // en pixels

extern void
__disp_i_setprop(const char  *file  , int line,
                 NGWinstance *widget, NGWpropId pid, NGWPdata data);

extern void __set_background_opaque(NGWinstance *container, bool_t b);

extern void __set_background_image(NGWinstance *container, NGGimage *imageptr);

#define disp_i_setprop(w, p, d) __disp_i_setprop(__FILE__, __LINE__, w, p, d)

/* set prop telephonic box */
#define disp_i_setpropTelnoeTab(w, i, p, d) __disp_i_setpropTelnoeTab(__FILE__, __LINE__, w, i, p, d)

extern void __disp_i_setpropTelnoeTab(const char  *file  , int line,
                               NGWinstance *widget, int idx, NGWpropId pid, NGWPdata data);

/* revoie l'item telephonicbox */
extern objmgr_item_t *telephonicbox_get_item(void);

/* renvoie l'index de la telephonicbox item */
extern int tab_id2idx( NGWinstance *tn, int id0 );

extern void
__disp_i_getprop(const char  *file  , int line,
                 NGWinstance *widget, NGWpropId pid, NGWPdata *data);

#define disp_i_getprop(w, p, d) __disp_i_getprop(__FILE__, __LINE__, w, p, d)


/*-----------------------------------------------------------------------------
  changement de la font de base d'un widget
 ----------------------------------------------------------------------------*/
extern void disp_i_setFont(NGWinstance *widget, uint8_t fontIdNoep);

/* utility function: convert from protocol font id to nexgen font id */
extern int disp_i_fontIdNoe2fontIdNg(int fontIdNoep);

/*-----------------------------------------------------------------------------
  changement de l'alignement du texte
 ----------------------------------------------------------------------------*/
extern void disp_i_halign(NGWinstance * widget, uint8_t halign);
extern void disp_i_valign(NGWinstance * widget, uint8_t valign);

/*-----------------------------------------------------------------------------
  changement de la visibilité d'un widget
 ----------------------------------------------------------------------------*/
extern bool_t disp_i_ngGetVisible(NGWinstance *widget);

/*-----------------------------------------------------------------------------
  changement de la bordure d'un widget
 ----------------------------------------------------------------------------*/
extern void disp_i_setBorder(objmgr_item_t *item, uint8_t border);

/*-----------------------------------------------------------------------------
  retourne le nb de pixels utilises par une bordure sur les 4 cotes
 ----------------------------------------------------------------------------*/
typedef struct
{
    int N; // north
    int E; // east
    int S; // south
    int W; // west
    uint8_t border;

} border_sizes_t;

extern void disp_i_getBorderSizes(objmgr_item_t *item, border_sizes_t *sizes);

/* [XTSce15476 */
/*-----------------------------------------------------------------------------
  retourne le nb de pixels utilises par une bordure sur 1 cote
 ----------------------------------------------------------------------------*/
extern uint32_t disp_i_getBorderSize(NGWinstance *widget);
/* XTSce15476] */

/*-----------------------------------------------------------------------------
  changement du texte d'un widget
 ----------------------------------------------------------------------------*/
extern void disp_i_setTexte(NGWinstance *widget, char **texte);

// la chaine retournee par cette fonction a ete obtenue par malloc!
extern unsigned char *disp_i_noeTxt2ngTxt(const char *texte, bool_t *trunc_allowed);

// return hebrew status
extern bool_t is_hebrew_enabled();

// retourne length after conversion or < 0 en cas d'erreur
// si outText n'est pas NULL une chaine mallocee est retourne dedans
// sinon la chine est liberee dans la fonction
extern int disp_i_utf8ok(const unsigned char *inText, NGwchar **outText);

/*-----------------------------------------------------------------------------
  changement de la palette d'un widget par changement du fond
 ----------------------------------------------------------------------------*/
extern void disp_i_setWidgetBackground(registerItem *item,
                                       NGWinstance *widget,
                                       uint8_t background);
#define disp_i_setBackground(I, B) disp_i_setWidgetBackground((I), NULL, (B))

/*---------------------------------------------------------------------
     recalcul de tous les y des fils d'un container
  ---------------------------------------------------------------------*/
extern void disp_i_recalculeYsons(objmgr_item_t *item);

/*-----------------------------------------------------------------------------
  utilitaire pour l'acces aux icones
 ----------------------------------------------------------------------------*/
extern NGGimage * disp_i_iconDecode(uint16_t icon);



//XTSce50998+
extern void disp_telephonicbox_update_offset(NGWPdata chinese);
extern void disp_framebox_update_offset(NGWPdata flag_size);
//XTSce50998-
extern void disp_init_gridinfo(void);
extern bool_t disp_grid_converter(enum_grid_type_t old_grid,
                                  enum_grid_type_t new_grid,
                                  uint8_t *abs_y);
#endif /* defined(DISPLAY) */

/*-----------------------------------------------------------------------------
  verification que 'children' peut etre attache a 'parent'
 ----------------------------------------------------------------------------*/
extern bool_t disp_i_can_link(objmgr_item_t *children, objmgr_item_t *parent);



/*-----------------------------------------------------------------------------
  retourne le parent de 'children' ou NULL en cas d'erreur
  ---------------------------------------------------------------------------*/
extern objmgr_item_t *disp_i_get_parent(objmgr_item_t *children);


/*=====================================================================
 * divers
 *=====================================================================*/

#if DISP_EMUL_3G

    extern void disp_3g_create(void);

#  if defined(DISPLAY)

    extern NGWinstance *disp3g_window;
    extern NGWinstance *disp3g_pinboard;

    extern NGWinstance *disp_3gAlcatelLabel(unsigned int length,
                                    const unsigned char *buffer);
#  endif /* defined(DISPLAY) */

#endif

/*=====================================================================
 * les utilitaires amenés par disp_font.c
 *=====================================================================*/
extern size_t dispFontList(char *outputBuf);
extern size_t dispFontLoadedDataList(char *outputBuf);
extern size_t dispLsPrint(char *outputBuf, const char *fileName);

/*=====================================================================
 * les utilitaires amenés par nginit
 *=====================================================================*/
extern void disp_ng_classes(void);

/*=====================================================================
 * les utilitaires amenés par w_listbox.c
 *=====================================================================*/
#if defined(DISPLAY)

extern uint8_t disp_i_get_row_height(registerItem *item, int lineNb);
extern void disp_list_create_default(NGWinstance *widget,
                                     NGWPdata count,
                                     NGWPdata sb_count,
                                     NGWPdata sb_start,
                                     enum_ncolumns_t mode);
extern bool_t disp_list_delete_item_at(registerItem *item, int idx);
extern NGWinstance *disp_list_insert_item_at(registerItem *item, int idx, char const * text, void *data, uint8_t fontid);
extern NGWinstance *disp_list_change_item_at(registerItem *item, int idx, char const *text, void *data, uint8_t fontid);
#define NB_LINES(MODE, COUNT) ((MODE) == COLUMN_1 ? (COUNT) : ((COUNT+1)/2))

extern NGWinstance *disp_actionbox_get_left(void);
extern NGWinstance *disp_actionbox_get_right(void);
objmgr_item_t *disp_actionbox_get_item_left(void);
objmgr_item_t *disp_actionbox_get_item_right(void);
extern void onTabboxOrHeaderboxShown(NGWinstance *sender, NGWmsg msg,
                                     void *msgData, void *cbData);

void disp_telephonicbox_set_offset(int offset);
int disp_telephonicbox_get_offset(void);
//XTSce50998+
void disp_framebox_set_offset_h(int offset);
int disp_framebox_get_offset_h(void);
void disp_framebox_set_offset_y(int offset);
int disp_framebox_get_offset_y(void);
//XTSce50998-

//XTSce54356
int disp_listbox_get_reduced_y(void);

#endif

#endif /* _DISP_PRIV_H_ */
