/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <log.h>

#include <ngwdk/protect/object.h>
#include <ngwdb.h>
#include <errno.h>

#include "ng_lnx.h"
#include "stdinc.h"
#include "disp_priv.h"
#include "display.h"
#include "os_wrapper.h"
#include "ticks.h"
#include "i_skins.h"
#include "i_icon.h"
#include "skins.h"
#include "leddrv.h"
#include "hidmsg.h"

#include "common.h"
#include "log.h"

/* ICON ID definition */
#define AOM_NAME_AE20                           "AE20"

#define ALE_LOGO_ICON                (83|ICON_NOE)

#define PAGE_LABEL_DEFAULT      "..."

NGWctx *global_w_ctx = NULL;

/***************************************************/
//object for main screen
NGWinstance          *dispWindow_win             = NULL;
NGWinstance          *disppinboard_mainscreen             = NULL;
NGWinstance          *disppinboard_homepage           = NULL;
NGWinstance          *displist_aom     = NULL;
NGWinstance         *pageIcon[MAX_PAGES_CFG] = {NULL};

registerItem  *rI_pinboard_mainscreen = NULL;
registerItem  *rI_pinboard_homepage = NULL;
registerItem  *rI_list = NULL;
registerItem  *rI_pageIcon[MAX_PAGES_CFG] = {NULL};

/***************************************************/

/***************************************************/
//object for homebar
NGWinstance          *disppinboard_homebar           = NULL;
NGWinstance         *logoIcon = NULL;
 
registerItem  *rI_pinboard_homebar = NULL;
registerItem  *rI_logoIcon = NULL;

/***************************************************/
const NGGpoint POS_ORIGIN = { 0, 0 };
    
volatile bool_t fl_screen2refresh = TRUE;
volatile static bool_t screen_refresh_task_exit_request = FALSE;

static bool_t homebar_init_flag = FALSE;
static bool_t homepage_init_flag = FALSE;
static bool_t pageicon_init_flag = FALSE;

static uint8_t pages_base_icons[MAX_PAGES_CFG]={116, 119, 122, 125, 128, 131, 134, 137, 140, 113};

static uint8_t pages_configed = 0;

extern bool_t test_mode;
/********************************************************************************************/
void __set_background_image(NGWinstance *container, NGGimage *imageptr)
{
    if (imageptr) {
        disp_i_setprop(container, NGWP_MOTIF_IMAGE  , (NGWPdata)NULL);
        disp_i_setprop(container, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_NONE);
        disp_i_setprop(container, NGWP_MOTIF_IMAGE  , (NGWPdata)imageptr);
        disp_i_setprop(container, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_IMAGE);
    } else {
        disp_i_setprop(container, NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_NONE);
    }
}

void __set_background_opaque(NGWinstance *container, bool_t b)
{
    NGWPdata data = NGW_MOTIF_CONTENT_NONE;
    if (b)
        data = NGW_MOTIF_CONTENT_BACKGROUND;
    disp_i_setprop(container, NGWP_MOTIF_CONTENT, data);
}

void changeIcon(uint16_t Idx, uint16_t icon, char* label)
{   
    if (homepage_init_flag != TRUE)
        return;
    
    if (icon == ICON_NO)
        icon = 0;
    else
        icon = (icon|ICON_NOE);
    
    disp_list_change_item_at(rI_list, Idx, label, (icon != ICON_NOE) ? &icon : NULL, FONT_REGULAR);
}

/*-----------------------------------------------------------------------------
  initialization screen constructor
  ---------------------------------------------------------------------------*/
//main screen frame
//Aom screen contain three fields: top homebar, middle homepage, bottom page icons.
static void screen_create()
{    
    NGGpoint homebar_pos = { 0, 0 };
    NGGsize  homebar_size = {480, 43}; 
    
    NGGpoint homepage_pos = { 0, 45 };
    NGGsize  homepage_size = {480, 809}; 

    //main screen
    dispWindow_win = disp_w_window("aom window");
    rI_pinboard_mainscreen = disp_w_pinboard(dispWindow_win, "aom mainscreen");
    disppinboard_mainscreen = rI_pinboard_mainscreen->objId; 

    //homepage container for list
    rI_pinboard_homepage = disp_w_pinboard(disppinboard_mainscreen, "aom homepage");
    disppinboard_homepage = rI_pinboard_homepage->objId; 

    disp_i_setprop(disppinboard_homepage, NGWP_POSITION, (NGWPdata) &homepage_pos);
    disp_i_setprop(disppinboard_homepage, NGWP_SIZE    , (NGWPdata) &homepage_size);
    
    __set_background_opaque(disppinboard_homepage, TRUE);
    __set_background_image(disppinboard_homepage,  skins_get_image(IMG_SCREEN_BACKGROUND));

    //homebar container for top icons
    rI_pinboard_homebar = disp_w_pinboard(disppinboard_mainscreen, "aom homebar");
    disppinboard_homebar = rI_pinboard_homebar->objId; 

    __set_background_opaque(disppinboard_homebar, TRUE);
    __set_background_image(disppinboard_homebar,  skins_get_image(IMG_SCREEN_BACKGROUND));
    disp_i_setprop(disppinboard_homebar, NGWP_POSITION, (NGWPdata) &homebar_pos);
    disp_i_setprop(disppinboard_homebar, NGWP_SIZE, (NGWPdata) &homebar_size);    
}

static void homebar_create(void)
{  
    NGGpoint logo_icon_pos = { 0, 5 };

    if (homebar_init_flag != TRUE)
    {
        rI_logoIcon = disp_w_iconbox(disppinboard_homebar, "ALE logo");
        logoIcon = rI_logoIcon->objId;
        disp_i_setprop(logoIcon, NGWP_POSITION, (NGWPdata) &logo_icon_pos);
        disp_i_setprop(logoIcon, NGWP_TRANSPARENT  ,(NGWPdata)1);
        __set_background_image(logoIcon,  skins_get_image(IMG_SCREEN_BACKGROUND));
    
        disp_i_iconCreate(rI_logoIcon, ALE_LOGO_ICON, logoIcon, NGWP_IMAGE, 0);

        homebar_init_flag = TRUE;
    }  
}

static void homepage_create(key_disp_infor_t *disp_item)
{       
    NGGpoint list_pos = { 8, 0 };
    NGGsize  list_size = {464, 780}; 
    int i;
    
    key_disp_infor_t *head = disp_item;
    key_disp_infor_t *curr = NULL;

    if (homepage_init_flag != TRUE)
    {
        //create left list and icons
        rI_list = disp_w_list(disppinboard_homepage, "aom list");
        displist_aom = rI_list->objId;
        disp_list_create_default(displist_aom, ICON_NUM, ICON_NUM, 0, COLUMN_2);
        disp_i_setprop(displist_aom, NGWP_POSITION, (NGWPdata) &list_pos);
        disp_i_setprop(displist_aom, NGWP_SIZE, (NGWPdata) &list_size);
    
        disp_i_setprop(displist_aom, NGWP_LIST_COLOR_HIGHLIGHTED,
            (NGWPdata)skinsinfo_get_rgbtext(ID_CURR_SKIN, ID_RGBTEXT_HIGHLIGHTED_ITEMS)
            );
        disp_i_setprop(displist_aom, NGWP_LIST_COLOR_TEXT_HIGHLIGHTED,
            (NGWPdata)skinsinfo_get_rgbtext(ID_CURR_SKIN, ID_RGBTEXT_HIGHLIGHTED_ITEMS_LABEL)
            );
        disp_i_setprop(displist_aom, NGWP_LIST_COLOR_TEXT, (NGWPdata)0xFFFFFF);//set font white corlor

        disp_i_setprop(displist_aom, NGWP_TRANSPARENT  ,(NGWPdata)1);
        __set_background_image(displist_aom,  skins_get_image(IMG_SCREEN_BACKGROUND));
    
        for (i = 0 ; i < ICON_NUM ; i++)
        {
            uint8_t *text = NULL;
            uint16_t icon = ICON_NO;
                
            curr = get_key_disp_info_by_index(&head, i);
            if (curr != NULL)
            {
                if (curr->label.size >0)
                    text = curr->label.content;

                if (curr->icon_id != ICON_NO)
                    icon = (curr->icon_id|ICON_NOE);
            }

            //printf("PK%d: label = '%s', icon = 0x%x\n", i, (text ? text : PAGE_LABEL_DEFAULT), ((icon == ICON_NO) ? NULL : &icon));
            disp_list_insert_item_at(rI_list, NGW_LIST_INSERT_AT_END, (text ? text : PAGE_LABEL_DEFAULT), ((icon == ICON_NO) ? NULL : &icon), FONT_REGULAR);
        }
        homepage_init_flag = TRUE;
    }
}

static void pageicon_create(uint8_t icons[], uint8_t pages)
{
    int i;
    
    NGGpoint icon_pos = { 125, 780 };
    NGGsize  icon_size = {230, 29};

    //caculate position
    icon_pos.x += (MAX_PAGES_CFG - pages) * 11;

    if (pageicon_init_flag != TRUE)
    {
        if (pages > MAX_PAGES_CFG)
        {
            LOGW("maxinam page for %s is %d\n", AOM_NAME_AE20, MAX_PAGES_CFG);
            pages = MAX_PAGES_CFG;
        }

        pages_configed = pages;        
        for (i = 0; i < MAX_PAGES_CFG; i++)
        {
            rI_pageIcon[i] = disp_w_iconbox(disppinboard_homepage, "page icon");
            pageIcon[i] = rI_pageIcon[i]->objId;
            disp_i_setprop(pageIcon[i], NGWP_POSITION, (NGWPdata) &icon_pos);
            disp_i_setprop(pageIcon[i], NGWP_SIZE, (NGWPdata) &icon_size);
            disp_i_setprop(pageIcon[i], NGWP_MOTIF_BORDER, (NGWPdata) "");
            disp_i_setprop(pageIcon[i], NGWP_MOTIF_CONTENT, (NGWPdata)NGW_MOTIF_CONTENT_NONE);
            disp_i_setprop(pageIcon[i], NGWP_TRANSPARENT  ,(NGWPdata)1);
        }
        
        for (i = 0; i < pages_configed; i++)
        { 
            disp_i_iconCreate(rI_pageIcon[i], icons[i]|ICON_NOE, pageIcon[i], NGWP_IMAGE, 0);
        } 
        pageicon_init_flag = TRUE;
    }
}

static void pageicon_update(uint8_t icons[], uint8_t pages)
{
    int i;
    NGGpoint icon_pos = { 125, 780 };
    
    //caculate position
    icon_pos.x += (MAX_PAGES_CFG - pages) * 11;
        
    if (pageicon_init_flag == TRUE)
    {
        if (pages > MAX_PAGES_CFG)
        {
            LOGW("maxinam page for %s is %d\n", AOM_NAME_AE20, MAX_PAGES_CFG);
            pages = MAX_PAGES_CFG;
        }

        for (i = 0; i < pages_configed; i++)
        { 
            disp_i_iconErase(rI_pageIcon[i], pageIcon[i], NGWP_IMAGE, 0);
        }
        
        pages_configed = pages;
        //update page icon
        for (i = 0; i < pages; i++)
        {
            disp_i_setprop(pageIcon[i], NGWP_POSITION, (NGWPdata) &icon_pos);
            disp_i_iconCreate(rI_pageIcon[i], icons[i]|ICON_NOE, pageIcon[i], NGWP_IMAGE, 0);
        } 
    }
}

void update_key_info(key_disp_infor_t *disp_item)
{
    if (disp_item != NULL)
    {
        keyInd_t key_index = disp_item->key_index; //key index
        iconInd_t icon_id = disp_item->icon_id; //icon id
        ledSt_t led_stat = disp_item->led_stat;       // led status
        uint8_t* str_label = ((disp_item->label.content != NULL) && (disp_item->label.size > 0)) ? disp_item->label.content: NULL;

        //print_key_disp_info(disp_item);//test
        //update icon
        changeIcon(key_index, icon_id, str_label);

        //update led state
        switch (led_stat)
        {
            case LED_ON:
                drvled_onoff(key_index, TRUE);
            break;
            case LED_OFF:
                drvled_onoff(key_index, FALSE);
            break;
            case LED_BLINK:             
                drvled_blink(key_index, FALSE);
            break;
            case LED_FAST_BLINK:             
                drvled_blink(key_index, TRUE);
            break;
            case LED_NOP:
            default:
            break;
        }
    }
}

void update_default_key_info(keyInd_t key_index)
{
    if (key_index < PKEY_NUM)
    {
        changeIcon(key_index, ICON_NO, "..."); 
        drvled_onoff(key_index, FALSE);
    }
}

/*-----------------------------------------------------------------------------
  DISPLAY TASK

  this task has one purpose:
  - run the Nexgen event loop

  this task does not exist on A model

  It is required that this task gets run early, in order to be able to
  make easy display during initialisation phase.
  ---------------------------------------------------------------------------*/
#if defined(DISPLAY)
static void display_task_entry(void)
{
    thread_set_tid(THREAD_ID_display);
    LOGI("task for Nexgen events running");

    /* on lance la boucle sans fin de gestion du display Nexgen: */
    ngwRun(global_w_ctx);

    //syslog( FLUX_DISPLAY, LOG_NORMAL, "Thread Display Exit Gracefully" );
    thread_set_status(THREAD_ID_display, THREAD_IS_CLOSED);
    pthread_exit(NULL);
}
#endif /* DISPLAY */


/*-----------------------------------------------------------------------------
  Lorsque les premiers  messages  NOE  ont  ete  recus,  il  faut  detruire  la
  mecanique d'affichage des copyrights et l'ecran  d'init  (progressbar)  avant
  d'afficher les ecrans systemes

  Cette routine est appellee par la tache NOEP lors du premier BURST (sauf sur
  HOST)
  ---------------------------------------------------------------------------*/
#if defined(DISPLAY)
static void disp_noep_add_heap(void)
{
    extern NGmemstats wdk_mh_initstats;
    NGmemstats        wdk_mh_newstats;

    if (wdk_mh_extension == NULL)
    {
        wdk_mh_extension = (NGubyte *)pw_malloc(NGW_HEAP_ADDED *sizeof(NGubyte));

        if (wdk_mh_extension == NULL)
        {
            //defence(FATAL_MEMORIZE, "pw_malloc failed");
            return;
        }

        memset(
            wdk_mh_extension, TEST_PATTERN_NEXGEN_HEAP, NGW_HEAP_ADDED
        );

        ngMemAddBlock(
            &wdk_mh, wdk_mh_extension, (NGW_HEAP_ADDED * sizeof(NGubyte))
        );

        ngMemStatsGetFree( &wdk_mh, &wdk_mh_newstats);
        wdk_mh_initstats.ms_total_size += wdk_mh_newstats.ms_total_size;
    }
}
#endif

/*-----------------------------------------------------------------------------
  initialisation du display
  - grille
  - icones
  - callback de flashage
  - creation de l'objet screen
  - chargement des skins (premier niveau)
  - affichage des copyrights
  - affichage des l'ecran d'init (progressbar)
  ---------------------------------------------------------------------------*/
void disp_init(void)
{
    TIMING_VARIABLES

    ngwBegin(global_w_ctx);

    // initialisation des informations sur les grilles, pour les routines
    // de positionnement
    disp_init_gridinfo();

    skins_init();
    skins_load();

    // icons manager init (must be done after skins init)
    disp_init_iconsmgr();

    screen_create();

    if (test_mode == TRUE)
    {
        uint8_t icons[3] = {118, 120, 123};
        
        homebar_create();
        homepage_create(NULL);
        pageicon_create(icons, 3);
    }
    
    TIMING_START
    ngwEnd(global_w_ctx);
    TIMING_END("ngwEnd")
}


/*-----------------------------------------------------------------------------
  display event task utility
  ---------------------------------------------------------------------------*/
static void display_log_msg(msg_t msg)
{
    msg_opcode_t opcode = msg_opcode(msg);

    LOGI("received 0x%04x %s", opcode, opcode2name(opcode));
}


/*-----------------------------------------------------------------------------
  DISPLAY EVENT TASK (all models)

  this task has few purposes:
  - manage display during init
  - manage display during link failure, flashing, etc. (local management)
  ---------------------------------------------------------------------------*/
static void dispevt_task_entry(void)
{
#if defined(DISPLAY)
    TIMING_VARIABLES
#endif

    thread_set_tid(THREAD_ID_dispevt);
	
    while(screen_refresh_task_exit_request == FALSE)
    {
        msg_t msg;
        int res;

        res = msgQ_recv_nowait(QUEUE_ID_display, msg);
        if (0 == res)
        {
            ngwBegin(global_w_ctx);

            switch(msg_opcode(msg)) {               
                case MSG_request_thread_exit:
                {
                    screen_refresh_task_exit_request = TRUE;
                    break;
                }
                
                case MSG_request_screen_upg:
                {
                    key_disp_infor_t **p_disp_head = msgL_data(msg);
                    
                    //if not create, create it, else update key info one by noe.
                    if (homepage_init_flag != TRUE)
                    {
                        homepage_create(*p_disp_head);
                    }
                    else
                    {
                        int i;

                        for (i = 0 ; i < ICON_NUM ; i++)
                        {
                            key_disp_infor_t *curr = NULL;
                            curr = get_key_disp_info_by_index(p_disp_head, i);
                            if (curr == NULL)
                            {
                                update_default_key_info(i);
                            }
                            else
                                update_key_info(curr);
                        }
                    }
                    destroy_key_disp_list_info(p_disp_head);
                    break;
                }
                
                case MSG_request_keyInfo_upg:
                {
                    key_disp_infor_t **p_disp_item = msgL_data(msg);
                    
                    //if not create, create it, else update key info one by noe.
                    if (homepage_init_flag == TRUE)
                    {
                        //LOGD("MSG_request_keyInfo_upg: curr = 0x%x\n", curr);//test
                        //update key info on screen (icon, label, led)
                        if ((p_disp_item != NULL) || (*p_disp_item != NULL))
                        {
                            update_key_info(*p_disp_item);                      
                        }
                    }
                    destroy_key_disp_info(p_disp_item);
                    break;
                }                   
                
                case MSG_request_pageicon_upg:
                {
                    int i;
                    uint8_t icons[MAX_PAGES_CFG];
                    uint8_t pages = 0;                 
                    uint8_t *p_page_status = NULL;
                    
                    p_page_status = (uint8_t *)msgL_data(msg);                  
                    for (i = 0; i < MAX_PAGES_CFG; i++, p_page_status++)
                    {
                        if (*p_page_status == PAGE_ON) 
                            icons[i] = pages_base_icons[i] + 2;//every icon has three status: on/off/highlight
                        else if (*p_page_status == PAGE_OFF)
                            icons[i] = pages_base_icons[i]  + 1;
                        else if (*p_page_status == PAGE_HIG)
                            icons[i] = pages_base_icons[i];
                        else
                            break;

                        pages++;
                    }
#if 0
                    printf("MSG_request_pageicon_upg: pages = %d, pageicon_init_flag = %d", pages, pageicon_init_flag);
                    for (i = 0; i < pages; i++)
                    {
                        printf("icons[%d] = %d", i, icons[i]);
                    }
                    printf("\n");
#endif
                    if (pageicon_init_flag != TRUE)
                    {
                        pageicon_create(icons, pages);
                        homebar_create();
                    }
                    else
                        pageicon_update(icons, pages);

                    break;
                }
                
                case MSG_request_screensaver:
                {
                    uint8_t on_off = (uint8_t)(msgS_data(msg));
    
                    //LOGD("screensaver on_off = 0x%x", (on_off & 0xF0));
                    if ((on_off & 0xF0) > 0)//screan save on
                    {
                        screensaver_enter();
                    }
                    else//screan save off
                    {
                        screensaver_leave();
                        screensaver_destroy_fbox();                    
                    }
                        
                    break;
                }
                
                case MSG_request_skin_reload:
                {
                    uint8_t skin_id = (uint8_t)(msgS_data(msg));
    
                    //LOGD("skin_reload skin_id = %d", skin_id);
                    skins_reload();
                    break;
                }
                
                default:
                {
                    display_log_msg(msg);
                    break;
                }
            }

            msg_release(msg);

            TIMING_START
            ngwEnd(global_w_ctx);
            TIMING_END("ngwEnd")
        }
        else if (-2 == res) break; // queue destroyed
    }

    thread_set_status(THREAD_ID_dispevt, THREAD_IS_CLOSED);
    pthread_exit(NULL);
}

/*-----------------------------------------------------------------------------
  DISPLAY TASK initialization
  ---------------------------------------------------------------------------*/
/*
  ATTENTION: pour UA B/C, la fonction disp_init() ne peut etre appelee
  au niveau de la tache background car prise de semaphore interdite.
  La fonction disp_init doit etre appelee dans l'init d'une des taches
  suivantes.
  Pour UA A, la fonction complete init_tskdisp() ne peut non plus etre
  appelee au niveau de la tache background suite a l'init du driver LCD A.
  La fonction init_tskdisp est dorenavant appelee lors de l'init la
  tache manager pour les produits UA B/C et A
*/
void init_tskdisp()
{    
#if defined(DISPLAY)
    /* avant toute chose, il faut initialiser Nexgen: */
    initNexGen();

    /* puis récupérer un contexte pour travailler */
    global_w_ctx = disp_createContext("global_w_ctx");

    // mise en route de la tache NexGen (ngwRun)
    aom_task_create(THREAD_ID_display, display_task_entry, TRUE);

    fl_screen2refresh = FALSE;

#endif

    disp_init();

    aom_msgQ_create(QUEUE_ID_display);
    aom_task_create(THREAD_ID_dispevt, dispevt_task_entry, TRUE);
    
    LOGI("tskdisp: queue and task(s) created");

#if defined(DISPLAY) && defined(NGW_VISUAL_STATE)
    dcontentMustShot   = FALSE;
    dcontentShotRunning= FALSE;
    dcontentEndValue   = NULL ;
    dcontentSpyId      = NULL ;
#endif
}
