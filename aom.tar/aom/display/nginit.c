/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
  
#include <stdio.h>
#include <unistd.h>

/* Alcatel */
#include "stdinc.h"
#include "log.h"
#include "primitive.h"
#include "os_wrapper.h"
#include "ticks.h"

#include "display.h"
#include "disp_priv.h"
#include "screensaver.h"

#if defined(DISPLAY)

#include <ngos.h>
#include <ngshell.h>
#include <nggui.h>
#include <ngfonts.h>
#include <ngvfs.h>
#include <nggraph/bmfm2.h>
#include <nggraph.h>
#include <ngwdb.h>

#include <ngwalc.h>

#include <ngdecode/zlib.h>

#if defined(HOST)
#include "ng_x11.h"
#else
#include "ng_lnx.h"
#endif


static NGGcolor const ngwPalette12bppColors[12] = {
  NGG_COLOR_WHITE,   // NGWC_xF
  NGG_COLOR_BLACK,   // NGWC_xD  NGWC_MOTIF_3DLIGHT
  NGG_COLOR_GRAY_xC, // NGWC_xC  scroll or progress bar background
  NGG_COLOR_WHITE,   // NGWC_xB  NGWC_MOTIF_3DBACKGROUND
  NGG_COLOR_GRAY_xC, // NGWC_x6  NGWC_MOTIF_3DSHADOW
  NGG_COLOR_GRAY_x8, // NGWC_x4  NGWC_FOCUS
  NGG_COLOR_BLACK,   // NGWC_x0

  NGG_COLOR_WHITE  , // ALC_MOTIF_BACKGROUND
  NGG_COLOR_BLACK  , // ALC_MOTIF_BORDER_0
  NGG_COLOR_GRAY_x8, // ALC_MOTIF_BORDER_1
  NGG_COLOR_GRAY_xC, // ALC_MOTIF_BORDER_2
  NGG_COLOR_WHITE    // ALC_MOTIF_BORDER_3
};

NGWpalette const ngwPalette12bpp = { 12, ngwPalette12bppColors };

static NGGcolor const ngwPalette2bppColors[12] = {
  NGG_COLOR_WHITE,   // NGWC_xF
  NGG_COLOR_BLACK,   // NGWC_xD  NGWC_MOTIF_3DLIGHT
  NGG_COLOR_GRAY_xC, // NGWC_xC  scroll or progress bar background
  NGG_COLOR_WHITE,   // NGWC_xB  NGWC_MOTIF_3DBACKGROUND
  NGG_COLOR_GRAY_xC, // NGWC_x6  NGWC_MOTIF_3DSHADOW
  NGG_COLOR_GRAY_x8, // NGWC_x4  NGWC_FOCUS
  NGG_COLOR_BLACK,   // NGWC_x0

  NGG_COLOR_WHITE  , // ALC_MOTIF_BACKGROUND
  NGG_COLOR_BLACK  , // ALC_MOTIF_BORDER_0
  NGG_COLOR_GRAY_x8, // ALC_MOTIF_BORDER_1
  NGG_COLOR_GRAY_xC, // ALC_MOTIF_BORDER_2
  NGG_COLOR_WHITE    // ALC_MOTIF_BORDER_3
};

NGWpalette const ngwPalette2bpp = { 12, ngwPalette2bppColors };

static NGGcolor const ngwPalette1bppColors[12] = {
  NGG_COLOR_WHITE,   //
  NGG_COLOR_WHITE,   // NGWC_MOTIF_3DLIGHT
  NGG_COLOR_WHITE,   // scroll or progress bar background
  NGG_COLOR_BLACK,   // NGWC_MOTIF_3DBACKGROUND
  NGG_COLOR_BLACK,   // NGWC_MOTIF_3DSHADOW
  NGG_COLOR_BLACK,   // NGWC_FOCUS
  NGG_COLOR_BLACK,   //

  NGG_COLOR_WHITE  , // ALC_MOTIF_BACKGROUND
  NGG_COLOR_BLACK  , // ALC_MOTIF_BORDER_0
  NGG_COLOR_BLACK  , // ALC_MOTIF_BORDER_1
  NGG_COLOR_BLACK  , // ALC_MOTIF_BORDER_2
  NGG_COLOR_WHITE    // ALC_MOTIF_BORDER_3
};

NGWpalette const ngwPalette1bpp = { 12, ngwPalette1bppColors };

/* en forcant ces palettes dans le driver ET dans le decodeur PNG, on
 * garantit que les couleurs sont bien traduites
 */
const NGGcolor grisNoe_palette[4] = {0xffffffff,0xffaaaaaa,0xff555555,0xff000000};
const NGGcolor blackNoe_palette[2] = {0xff000000, 0xffffffff};

// le 4 est necessaire car on compile avec 2BPP sous linux
const NGGcolor bwNoe_palette[4] = {
0x00000000,0x00ffffff,0x00ffffff,0x00ffffff};

const NGGsize SIZE= {480, 854};

NGGsize disp_size; // en pixels

/*---------------------------------------------------------------------------*/
/*                                NexGenOS                                   */
/*---------------------------------------------------------------------------*/

/* Video driver */
static NGOSmutex            vid_lock;
static  VIDEO_DATA_TYPE     vid_data;

#define GRAPH_CLIP_MAX      64
static NGGregion            os2_vidcliplist[GRAPH_CLIP_MAX];

//#if defined(HOST)
//uint16_t *lcd_D_getOffScreenBuffer(void)
//{
//    return vid_data.xvd_vid.vid_fb.surf_data;
//}
//
//uint8_t *lcd_C_getOffScreenBuffer(void)
//{
//    return vid_data.xvd_vid.vid_fb.surf_data;
//}
//
//uint8_t *lcd_B_getOffScreenBuffer(void)
//{
//    return vid_data.xvd_vid.vid_fb.surf_data;
//}
//#endif

/*---------------------------------------------------------------------------*/
/*                               VFS                                         */
/*---------------------------------------------------------------------------*/

#define VFS_IOCB_MAX    8

static NGvfsdata vfs_data;
static NGvfscb   vfs_iocb[VFS_IOCB_MAX];
static NGOSmutex vfs_lock;

#define FS_DRIVER                                     \
                                                      \
  NG_CFG( NG_CFG_MOD_ADD,           &ngFsysDrv_VFS),  \
  NG_CFG( NG_CFG_MOD_DATA,          &vfs_data),       \
  NG_CFG( NG_CFG_MOD_MUTEX,         &vfs_lock),       \
  NG_CFG( NG_CFG_MOD_IOCB_TABLE,    &vfs_iocb),       \
  NG_CFG( NG_CFG_MOD_IOCB_MAX,      VFS_IOCB_MAX),    \
  NG_CFG( NG_CFG_MOD_MOUNTP,        FONT_PATH),       \
  NG_CFG( NG_CFG_VFS_IMAGE,         NULL),


/*---------------------------------------------------------------------------*/
/*                               FONT MANAGER                                */
/*---------------------------------------------------------------------------*/
NGGbmfontdata2         fm_data;

/*
   fm_buf:
*/
// stockage des bitmaps calculee par le font manager pour le driver video:

static NGubyte fm_buf[5120 + (1024 * 4)];
NGubyte fm_heap[FONT_HEAP_SIZE];

#define FONT_PATH      "/ngf"

static NGOSmutex       fm_lock;
static NGOSmutex       fm_heap_lock;

#define FONT_MANAGER_DRIVER                                       \
                                                                  \
   NG_CFG( NG_CFG_MOD_ADD,                      &nggBMFontDrv2),  \
   NG_CFG( NG_CFG_MOD_DATA,                     &fm_data),        \
   NG_CFG( NGG_FONTO_LOCK,                      &fm_lock),        \
   NG_CFG( NGG_FONTO_ALIAS_LIST,                NULL),            \
   NG_CFG( NGG_BMFONT2O_FONTPATH,               FONT_PATH),       \
   NG_CFG( NGG_BMFONT2O_MEMHEAP,                fm_heap),         \
   NG_CFG( NGG_BMFONT2O_MEMHEAP_LEN,            sizeof(fm_heap)), \
   NG_CFG( NGG_BMFONT2O_HEAP_MUTEX,             &fm_heap_lock),   \
   NG_CFG( NGG_BMFONT2O_ALLOW_SUBSTITUTION,     1),               \
   NG_CFG( NGG_BMFONT2O_ALLOW_DEFAULT_GLYPH,    1),


/*---------------------------------------------------------------------------*/
/*                               NexGenCOREGUI                               */
/*---------------------------------------------------------------------------*/
// nombre de connexions <-> nombre de contextes crees (+1 si wm)
#define GUIO_IOCB_MAX    1
// @20040114@tag2@nbe+
#define GUIO_WINDOW_MAX  32
// @20040114@tag2@nbe-
#define GUIO_EVENT_MAX   512
#define GUIO_CLIP_MAX    512
#define GUIO_TIMER_MAX   32

static NGGguidata        gui_data;
static NGGguicb          gui_cb_table    [GUIO_IOCB_MAX  ];
static NGGrawwindow      gui_rawwin_table[GUIO_WINDOW_MAX];
static NGGrawevent       gui_event_table [GUIO_EVENT_MAX ];
static NGGregion         gui_guicliplist [GUIO_CLIP_MAX  ];

static NGOSsem           gui_cb_semtable[GUIO_IOCB_MAX];
static NGOSmutex         gui_lock;
static NGOSievent        gui_inp_ev;
static NGOStask          gui_inp_task;
static NGubyte           gui_inp_stk[GUIO_INPUT_STK_SIZE];

static NGGguitimer       guitimer_table[GUIO_TIMER_MAX ];

/* Mouse driver */
static NGmsedata         mse_data;
static NGtimer           steady_timer;

/* Timer Module */
static NGtimerdata       timer_data;
static NGOSmutex         timer_lock;
static NGOSsem           timer_sem;
static NGOStask          timer_task;
static NGubyte           timer_stk[TIMERO_STK_SIZE];


#define COMMON_VID_PART                                         \
                                                                \
  NG_CFG( NGG_VIDO_CLIPLIST,             os2_vidcliplist),      \
  NG_CFG( NGG_VIDO_NB_MAX_CLIP,          sizeof(os2_vidcliplist) / sizeof(os2_vidcliplist[0])), \
  NG_CFG( NGG_VIDO_FONT_MANAGER,         &fm_data),             \
  NG_CFG( NGG_VIDO_FMBUF,                fm_buf),               \
  NG_CFG( NGG_VIDO_SIZE_FMBUF,           sizeof(fm_buf)),


#define COMMON_PART                                             \
  /* NexGenCOREGUI : Timer Module */                            \
  NG_CFG( NG_CFG_MOD_ADD,                &ngTimerDrv ),         \
  NG_CFG( NG_CFG_MOD_DATA,               &timer_data),          \
  NG_CFG( NG_TIMERO_DELTA,               10),                   \
  NG_CFG( NG_TIMERO_LOCK,                &timer_lock),          \
  NG_CFG( NG_TIMERO_TASK,                &timer_task),          \
  NG_CFG( NG_TIMERO_TASK_PRIO,           TIMERO_TASK_PRIO),     \
  NG_CFG( NG_TIMERO_STACK,               &timer_stk),           \
  NG_CFG( NG_TIMERO_STACKSIZE,           TIMERO_STK_SIZE),      \
  NG_CFG( NG_TIMERO_SEM,                 &timer_sem),           \
                                                                \
  /* NexGenCOREGUI */                                           \
  NG_CFG( NG_CFG_MOD_ADD,                &nggGuiDrv),           \
  NG_CFG( NG_CFG_MOD_DATA,               &gui_data),            \
  NG_CFG( NGG_GUIO_IOCB_TABLE,           &gui_cb_table),        \
  NG_CFG( NGG_GUIO_IOCB_MAX,             sizeof(gui_cb_table) / sizeof(gui_cb_table[0])), \
  NG_CFG( NGG_GUIO_WINDOW_TABLE,         gui_rawwin_table),     \
  NG_CFG( NGG_GUIO_WINDOW_MAX ,          sizeof(gui_rawwin_table) / sizeof(gui_rawwin_table[0])), \
  NG_CFG( NGG_GUIO_CLIPLIST_TABLE,       gui_guicliplist),      \
  NG_CFG( NGG_GUIO_CLIPLIST_MAX,         sizeof(gui_guicliplist) / sizeof(gui_guicliplist[0])), \
  NG_CFG( NGG_GUIO_EVENT_TABLE,          gui_event_table),      \
  NG_CFG( NGG_GUIO_EVENT_MAX,            sizeof(gui_event_table) / sizeof(gui_event_table[0])), \
  NG_CFG( NGG_GUIO_VIDEO,                &vid_data),            \
                                                                \
  NG_CFG( NGG_GUIO_LOCK,                 &gui_lock),            \
  NG_CFG( NGG_GUIO_IOCB_SEMTABLE,        &gui_cb_semtable),     \
  NG_CFG( NGG_GUIO_INPUT_EVENT,          &gui_inp_ev),          \
  NG_CFG( NGG_GUIO_INPUT_TASK,           &gui_inp_task),        \
  NG_CFG( NGG_GUIO_INPUT_TASK_PRIO,      GUIO_INPUT_TASK_PRIO), \
  NG_CFG( NGG_GUIO_INPUT_STACK,          gui_inp_stk),          \
  NG_CFG( NGG_GUIO_INPUT_STACK_SIZE,     sizeof(gui_inp_stk)),  \
                                                                \
  NG_CFG( NGG_GUIO_TIMER,                &timer_data),          \
  NG_CFG( NGG_GUIO_TIMER_TABLE,          guitimer_table),       \
  NG_CFG( NGG_GUIO_TIMER_TABLE_MAX,      sizeof(guitimer_table) / sizeof(guitimer_table[0])),

/*---------------------------------------------------------------------------*/
/*                        NexGen Main Configuration                          */
/*---------------------------------------------------------------------------*/

static NGcfgent osconfig[] = {
  FS_DRIVER
  FONT_MANAGER_DRIVER
  VIDEO_DRIVER
  COMMON_VID_PART
  COMMON_PART
  {NG_CFG_END}
};

static void noePanic(void *os_panic_data, const char *file, int line, const char *format, NGva_list ap)
{
    static char  panicStr[1000];
    char        *p = panicStr;

    p += sprintf(p, "ngPanic():");
    p += vsprintf(p, format, ap);

    // syslog instead of reset...
    LOGE("%s", panicStr);
}


void initNexGen(void)
{
    int            err;
    NGcfgent      *p_osconfig;
    size_t         s_osconfig;

    /* Modules initialisation */
    disp_size = SIZE;
    p_osconfig= &osconfig[0];
    s_osconfig=sizeof(osconfig);

    memset (fm_heap, TEST_PATTERN_NEXGEN_HEAP, sizeof (fm_heap));
    memset (fm_buf,  TEST_PATTERN_NEXGEN_HEAP, sizeof (fm_buf));

    disp_fontlist_init();

    {
        int i, nbItems;
        nbItems = s_osconfig / sizeof(NGcfgent);

        LOGD("osconfig has %d items", nbItems);

        for(i = 0; i < nbItems ; i++)
        {
            if (p_osconfig[i].cfg_option == NG_CFG_VFS_IMAGE)
            {
                LOGD("there are fonts in osconfig item %d", i);
                p_osconfig[i].cfg_arg= (NGcfgarg)&disp_vfs_fonts;
                break;
            }
        }
    }

    if ((err = ngInit(p_osconfig)) != NG_EOK)
    {
        LOGE("NexGen: can't initialize, error=%04x\n", err);
        aom_task_delay(UNIT_TIME_1s);
    }

    ngPanicSetCallback( noePanic, NULL);
}

#endif /* defined(DISPLAY) */
