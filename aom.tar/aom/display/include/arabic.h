/*--------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         arabic.h

   DATED:          2009/12/7

   AUTHOR:         Qiaos

   DESCRIPTION:    Arabic characters mapping and reverse

   HISTORY:

     - creation   2009/12/7
       For Arabic requirement.

     - 2016/09/13 Shilong han
       crqms00204663 :[NOE3G R100][Hebrew]Hebrew name call log with
       'name+date+time+icon' is wrongly format

     - 2018/04/13 bertin
       CR3GEENOE-1049 [OXE] Hebrew: No configuration changes are possible on the
       device when password is required.

-----------------------------------------------------------------------------*/
#ifndef __ARABIC_H__
#define __ARABIC_H__

#include "stdinc.h"

#ifdef w_char
#  undef w_char
#endif
#define w_char unsigned short

#ifndef TRUE
#  define TRUE 1
#endif
#ifndef FALSE
#  define FALSE 0
#endif

#define MAX_ARABIC_LINE_LENGTH 1024
enum POS_STADUS
{
    INITIAL=0,
    MEDIAL,
    FINAL,
    ISOLATED,
    UNDEFINED
};

/*Case 1*/
enum ARABIC_NORMAL_CHAR
{
    AB_0621 = 0,    //0x0621
    AB_0622,
    AB_0623,
    AB_0624,
    AB_0625,
    AB_0626,
    AB_0627,
    AB_0628,
    AB_0629,
    AB_062A,
    AB_062B,
    AB_062C,
    AB_062D,
    AB_062E,
    AB_062F,
    AB_0630,
    AB_0631,
    AB_0632,
    AB_0633,
    AB_0634,
    AB_0635,
    AB_0636,
    AB_0637,
    AB_0638,
    AB_0639,
    AB_063A,
    AB_0641,
    AB_0642,
    AB_0643,
    AB_0644,
    AB_0645,
    AB_0646,
    AB_0647,
    AB_0648,
    AB_0649,
    AB_064A,
    AB_IILEGAL = 0xffff
};


/*This struct stores the arabic char map table in CASE 1*/
typedef struct arabic_normal_map_type
{
    w_char w_isolated;
    w_char w_final;
    w_char w_initial;
    w_char w_medial;
} arabic_normal_map_type;


/*Case 2*/
/*Case 2 should include space, tatweel, and lam*/
enum ARABIC_CASE2_CHAR
{
    ABS_0622 = 0,
    ABS_0623,
    ABS_0625,
    ABS_0627,
    ABS_064b,
    ABS_064c,
    ABS_064d,
    ABS_064e,
    ABS_064f,
    ABS_0650,
    ABS_0651,
    ABS_0652,
    ABS_IILEGAL = 0xffff

};


/*This struct stores the arabic char map table in CASE 1*/
typedef struct arabic_case2_map_type
{
    w_char w_space;
    w_char w_tatweel;
    w_char w_lam_isolated;
    w_char w_lam_final;
}arabic_case2_map_type;

enum arabic_case2_symbol
{
    AB_SPACE = 0,
    AB_TATWEEL,
    AB_LAM_ISOLATED,
    AB_LAM_FINAL
};

/*External functions declaration*/
extern int isArabicOrHebraize(w_char c);
extern int isControlSymbol(w_char c);
extern int Arabic_Convert_Api(const char* input_ptr, char *output_ptr, int input_length, int *output_length);
extern int isarabic(w_char c);

//CR3GEENOE-1049+
extern bool_t language_is_arabic_or_hebrew();
#if 0
extern bool_t string_contains_arabic_or_hebrew_char(const char *str);
#endif
//CR3GEENOE-1049-

extern bool_t  disp_i_arabic_transformation(char * in_str, char **out_str);
//crqms00202831 Anne +
extern char *reverse_arrow_latin_in_hebrewctx(char *line, int length);
extern char *exchange_datetime_name_arabic(char *line, int length, bool_t exchangeName); //crqms00204663 shilong
//crqms00202831 Anne -

/*Point array*/
typedef struct group_pos_t
{
    char* start;
    int length;
    int reverse_flag; /*0:Need not reverse 1: Need reverse, 3: symbol*/
} group_pos_t;

#endif
