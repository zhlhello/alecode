/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         timevt.h
 
   DATED:          2003/07/04
 
   AUTHOR:         N. Bertin
 
   DESCRIPTION:    timevt interface

   SccsId=         @(#)timevt.h	1.3  03/11/25

   HISTORY: 

      - creation   2003/07/04

-----------------------------------------------------------------------------*/
#ifndef _TIMEVT_H_
#define _TIMEVT_H_



/*-----------------------------------------------------------------------------
  maximum number of callbacks registered

   1 idletimer    (CS)
   2 idletimer    (PS)
   3 screensaver
   4 backlight
   5 terminal     (telnet)
   6 popupbox     max 4
   7 popupbox
   8 popupbox
   9 popupbox
   9 dialogbox    max 8
  10 dialogbox
  11 dialogbox
  12 dialogbox
  13 dialogbox
  14 dialogbox
  15 dialogbox
  16 dialogbox
  17-18 add 2 callback for aomvbox timeout management(crms00146973)
  ---------------------------------------------------------------------------*/

#define MAX_TIMEVT_CALLBACKS_DEFAULT     18

#ifdef FEATURE_IME
//add 2 callback for IME
#define MAX_TIMEVT_CALLBACKS_IME          2
#else
#define MAX_TIMEVT_CALLBACKS_IME          0
#endif

#ifdef FEATURE_THALES
//add 2 callback for Thales
#define MAX_TIMEVT_CALLBACKS_THALES       2
#else
#define MAX_TIMEVT_CALLBACKS_THALES       0
#endif

#ifdef KEYBOARD_MINIKBD
//add 1 callback for minikeyboard support
#define MAX_TIMEVT_CALLBACKS_MINIKBD      1
#else
#define MAX_TIMEVT_CALLBACKS_MINIKBD      0
#endif

#define MAX_TIMEVT_CALLBACKS   (\
                                  MAX_TIMEVT_CALLBACKS_DEFAULT  + \
                                  MAX_TIMEVT_CALLBACKS_THALES   + \
                                  MAX_TIMEVT_CALLBACKS_IME      + \
                                  MAX_TIMEVT_CALLBACKS_MINIKBD    \
                               )

/*-----------------------------------------------------------------------------
  timevt callbacks type definition
  ---------------------------------------------------------------------------*/
typedef void (*timevt_callback_t)(void *data);


#ifdef __cplusplus
extern "C" {
#endif


/*-----------------------------------------------------------------------------
  timevt restart (initial value is reloaded)
  ---------------------------------------------------------------------------*/
extern void timevt_restart(int id, uint32_t timeout);



/*-----------------------------------------------------------------------------
  the specified callback is registered to the timevt only if an empty room
  is found (MAX_TIMEVT_CALLBACKS)
  ---------------------------------------------------------------------------*/
extern int timevt_register(timevt_callback_t f, void *data, uint32_t timeout);



/*-----------------------------------------------------------------------------
  the specified callback is unregistered from the timevt only if it is found
  in the callbacks list
  ---------------------------------------------------------------------------*/
extern void timevt_unregister(int id);



/*-----------------------------------------------------------------------------
  timevt timer initialization
  ---------------------------------------------------------------------------*/
extern void init_timevt(void);

#ifdef __cplusplus
}
#endif


#endif /* _TIMEVT_H_ */
