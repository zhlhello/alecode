/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

#ifndef _PRIMITIVE_H_
#define _PRIMITIVE_H_

#include "msgdefs.h"

/*------------------------------------------------------------------
 * Macro and Type definitions
 *------------------------------------------------------------------*/

/*!
 *  \brief This is a primitive structure.
 *
 * primitive structure
 *   1) primitive code
 *   2) source component
 *   3) short message without payload
 *   4) payload length
 *   5) payload
 *
 * NOTE: payload is depend on the primtive type (eCode)
 *       some of the payload structures are defined below
 */
typedef struct
{
    msg_opcode_t primitiveCode;  //!< Message Opcode
    uint16_t     src_component;  //!< Thread (Task) Id
    uint16_t     shortmsg;  	 //!< Short message without payload
    
    uint32_t    payload_length; //!< payload byte length
    void*       payload;        //!< payload pointer

} S_PRIMITIVE;


#endif // _PRIMITIVE_H_

