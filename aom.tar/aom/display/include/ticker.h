/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         ticker.h
 
   DATED:          2003/04/29
 
   AUTHOR:         N. Bertin
 
   DESCRIPTION:    ticker interface

   SccsId=         @(#)ticker.h	1.7  04/06/11

   HISTORY: 

      - creation   2003/04/29

-----------------------------------------------------------------------------*/
#ifndef _TICKER_H_
#define _TICKER_H_


/*-----------------------------------------------------------------------------
  ticker timeout = 250ms
  registered callbacks are called every TICKER_TIMEOUT ms
  ---------------------------------------------------------------------------*/
#define TICKER_TIMEOUT         (UNIT_TIME_10ms * 25)


/*-----------------------------------------------------------------------------
  maximum number of callbacks registered

   1 leds
   2 timevt
   3 date
   4 timerbox
   5 aom
   6 icon
   7 headset_presence
   8 drvlcd_A

  ---------------------------------------------------------------------------*/
#define MAX_TICKER_CALLBACKS   8


// XTSce27667+
/*-----------------------------------------------------------------------------
  valeur proposee pour indiquer le fait de ne pas etre enregistre

  homogene a un ticker_id, peut etre retournee par ticker_register.
  ---------------------------------------------------------------------------*/
#define TICKER_NOT_REGISTERED     (-1)

// XTSce27667-


/*-----------------------------------------------------------------------------
  ticker callbacks type definition
  ---------------------------------------------------------------------------*/
typedef void (*ticker_callback_t)(uint32_t ms, uint32_t tck, void *data);



/*-----------------------------------------------------------------------------
  the specified callback is registered to the ticker only if an empty room
  is found (MAX_TICKER_CALLBACKS)

  else TICKER_NOT_REGISTERED will be returned
  ---------------------------------------------------------------------------*/
extern int ticker_register(ticker_callback_t f, void *data);



/*-----------------------------------------------------------------------------
  the specified callback is unregistered from the ticker only if it is found
  in the callbacks list
  ---------------------------------------------------------------------------*/
extern void ticker_unregister(int id);



/*-----------------------------------------------------------------------------
  ticker timer initialization
  ---------------------------------------------------------------------------*/
extern void init_ticker(void);



#endif /* _TICKER_H_ */
