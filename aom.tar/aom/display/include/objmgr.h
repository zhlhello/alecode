/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         objmgr.h
 
   DATED:          2003/05/27
 
   AUTHOR:         Team
 
   DESCRIPTION:    objects manager interface

   SccsId=         @(#)objmgr.h	1.12  04/08/20

   HISTORY: 

      - 2003/05/27 creation   

      - 2004/08/19 mge XTSce34156
        Ajout objmgr_rotateChildren() pour le cycling

-----------------------------------------------------------------------------*/
#ifndef _OBJMGR_H_
#define _OBJMGR_H_

#include "noep/proto_defs.h"
#include "noep/class_data.h"
#include "noep/class_defs.h"
/*-----------------------------------------------------------------------------
  object manager data structure
  ---------------------------------------------------------------------------*/
typedef struct s_objmgr_item objmgr_item_t;

struct s_objmgr_item
{
    objmgr_item_t *next;
    objmgr_item_t *prev;
    objmgr_item_t *fils;
    objmgr_item_t *pere;

    uint32_t       objtype; // class opcode (C_defs_t)
    uint32_t       evt_dst; // CTX_CS or CTX_PS 
    void          *objdata;
    void          *objpriv;
};


/*-----------------------------------------------------------------------------
  specific values for objtype field
  ---------------------------------------------------------------------------*/
#define OBJTYPE_DISP_INTERNAL   0xfffffffe
#define CTX_UND                              0xffff
/*=============================================================================
   la liste!
 *===========================================================================*/

extern objmgr_item_t *objList;



#define OBJTEXT_UTF8_BUFFER_SIZE  1024

#endif /* _OBJMGR_H_ */
