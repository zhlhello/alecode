
/*
 * This file was automatically generated
 * please do not edit
 *
 * date: Fri Jul  1 11:27:28 2005
 */
#ifndef _FONT_DEFAULT_D_H_
#define _FONT_DEFAULT_D_H_

#define FONT_DEFAULT_D_SIZE    1646
#define FONT_DEFAULT_D_CTIME   1118913875UL
#define FONT_DEFAULT_D_ASCTIME "Thu Jun 16 11:24:35 2005"

extern const unsigned char font_default_D[FONT_DEFAULT_D_SIZE];

#endif /* _FONT_DEFAULT_D_H_ */
