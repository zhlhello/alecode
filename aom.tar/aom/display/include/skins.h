/*-----------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         skins.h

   AUTHOR:         N. Bertin

   DESCRIPTION:    skins and skinsinfo interfaces

   HISTORY:

    - 2003/10/30  creation

    - 2016/06/08 bertin
      API change: skinid uint32_t to int32_t

    - 2016/06/23 bertin
      updated skininfo to use meaningful names for rgbtext- instead of indexes

    - 2016/06/30 bertin
      added support to (re-)load a skinsinfo file (skins reload)

    - 2016/10/17 bertin
      moved definition of ID_SKIN_CUST from i_skinsinfo.c to skins.h

    - 2018/02/09 bertin
      "Release" skin

-----------------------------------------------------------------------------*/
#ifndef _SKINS_H_
#define _SKINS_H_


/*-----------------------------------------------------------------------------
  S K I N S  I N F O
  ---------------------------------------------------------------------------*/
#define MAX_SKINSBASE     (1)
#define MAX_SKINSCUST     (1)
#define MAX_SKINS         (MAX_SKINSBASE+MAX_SKINSCUST)
#define MAX_ICONSSET      (MAX_SKINSBASE)

#define INVALID_BASESKIN  (-1)
#define INVALID_ICONSSET  (-1)

#define ID_CURR_SKIN      (-1)
#define ID_SKIN_CUST      (MAX_SKINS-1)
#define ID_SKIN_DEFAULT   (1)

typedef enum {
    ID_RGBTEXT_HOMEBAR                  = 0,
    ID_RGBTEXT_TABS                     = 1,
    ID_RGBTEXT_TABS_SEL                 = 2,
    ID_RGBTEXT_LISTS                    = 3,
    ID_RGBTEXT_LABELS                   = 4,
    ID_RGBTEXT_INPUTBOX                 = 5,
    ID_RGBTEXT_TIMERBOX                 = 6,
    ID_RGBTEXT_SMARTADDON               = 7,
    ID_RGBTEXT_HIGHLIGHTED_ITEMS        = 8,
    ID_RGBTEXT_HIGHLIGHTED_ITEMS_LABEL  = 9,
    ID_RGBTEXT_CURSOR                   = 10,
    MAX_RGBTEXT                            ,
    ID_INVALID
} rgbtext_t;

/*-----------------------------------------------------------------------------
  load all skins information files
  ---------------------------------------------------------------------------*/
extern void skinsinfo_init();

/*-----------------------------------------------------------------------------
  load specified skin information file
  ---------------------------------------------------------------------------*/
extern void skinsinfo_load(int32_t id);

/*-----------------------------------------------------------------------------
  returns skinsinfo validity
  ---------------------------------------------------------------------------*/
extern bool_t skinsinfo_is_valid(int32_t id);

/*-----------------------------------------------------------------------------
  returns TRUE if cust skin
  ---------------------------------------------------------------------------*/
extern bool_t skinsinfo_is_custskin(int32_t id);

/*-----------------------------------------------------------------------------
  getter: skin name
  ---------------------------------------------------------------------------*/
extern const char *skinsinfo_get_skinname(int32_t id);

/*-----------------------------------------------------------------------------
  getter: base skin identifier
  ---------------------------------------------------------------------------*/
extern int32_t skinsinfo_get_baseskin(int32_t id);

/*-----------------------------------------------------------------------------
  getter: skin icons set
  ---------------------------------------------------------------------------*/
extern int32_t skinsinfo_get_iconsset(int32_t id);

/*-----------------------------------------------------------------------------
  getter: text color
  ---------------------------------------------------------------------------*/
int32_t skinsinfo_get_rgbtext(int32_t id, rgbtext_t rgbtext);

/*-----------------------------------------------------------------------------
  getter: text color name
  ---------------------------------------------------------------------------*/
char *skinsinfo_get_rgbtext_name(rgbtext_t rgbtext);

/*-----------------------------------------------------------------------------
  getter: has images for slideshow (screensaver)
  ---------------------------------------------------------------------------*/
extern bool_t skinsinfo_has_slideshow(int32_t id);


/*-----------------------------------------------------------------------------
  S K I N S
  ---------------------------------------------------------------------------*/
extern void skins_reload(void);


#endif /* _SKINS_H_ */