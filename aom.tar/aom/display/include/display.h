/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/26 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

#ifndef _DISPLAY_H_
#define _DISPLAY_H_ 1

#if defined(DISPLAY)

//
// cet include semble etre suffisant pour la compilation des fichiers utilisant
// la pile NexGen
//
#include "ngwdb.h"
#include "ngdebug.h"

#undef ngwEnd
#undef ngwBegin

#define DISPLAY_TRACE_BEGIN_END_CALLS    TRACE_DRAW_REQUESTS // trace or not begin/end calls
#define DISPLAY_USE_NGWSYNCLAYOUT        1 // use or not ngwSyncLayout instead of ngwSync
#define DISPLAY_BEGIN_MAX_WAIT           1
#define DISPLAY_NOEP_TASK_IS_IDLE        1

#if (DISPLAY_TRACE_BEGIN_END_CALLS == 1)
#  define __TRC_BEG() LOGI("gfx[beg]:")
#  define __TRC_END() LOGI("gfx[end]:")
#else
#  define __TRC_BEG()
#  define __TRC_END()
#endif

#if (DISPLAY_USE_NGWSYNCLAYOUT == 0)
#  define ngwSyncLayout(ctx) ngwSync(ctx)
#endif

#define ngwBegin(ctx) { \
    NGW_LOCK(ctx); \
    __TRC_BEG(); \
}

#define ngwEnd(ctx) { \
    ngwSync(ctx);       \
    __TRC_END(); \
    NGW_UNLOCK(ctx); \
}

#if (DISPLAY_BEGIN_MAX_WAIT == 1)
#  if (TRACE_DRAW_REQUESTS == 1)
#    define __TRC_BEGIN_MAX_WAIT(dt) LOGI("gfx[maxwait]: us=%ld", dt)
#  else
#    define __TRC_BEGIN_MAX_WAIT(dt)
#  endif
#  include <time.h>
#  define ngwBeginMaxWait(ctx, max) {                                           \
    unsigned long   _st, _et, _dt;                                              \
    struct timespec _ts;                                                        \
                                                                                \
    __TRC_BEG();                                                                \
                                                                                \
    clock_gettime(CLOCK_MONOTONIC_RAW, &_ts);                                   \
    _st = (_ts.tv_sec * 1000000) + (_ts.tv_nsec / 1000);                        \
                                                                                \
    NGW_LOCK(ctx);                                                              \
                                                                                \
    clock_gettime(CLOCK_MONOTONIC_RAW, &_ts);                                   \
    _et = (_ts.tv_sec * 1000000) + (_ts.tv_nsec / 1000);                        \
    _dt = (_et - _st);                                                          \
                                                                                \
    if (_dt >= max)                                                             \
    {                                                                           \
        __TRC_BEGIN_MAX_WAIT(_dt);                                              \
        NGW_UNLOCK(global_w_ctx);                                               \
        return;                                                                 \
    }                                                                           \
}
#else
#  define ngwBeginMaxWait(ctx, wait) ngwBegin(ctx)
#endif


/*-----------------------------------------------------------------------------
  quelques variables globales
  ---------------------------------------------------------------------------*/
extern NGWctx      *global_w_ctx;


/*-----------------------------------------------------------------------------
  window creation
  ---------------------------------------------------------------------------*/
extern NGWinstance *disp_w_window(const char *comment);

#endif


/*-----------------------------------------------------------------------------
  DISPLAY TASK initialization and shutdown
  ---------------------------------------------------------------------------*/
extern void init_tskdisp(void);

/*-----------------------------------------------------------------------------
  NexGen startup
  ---------------------------------------------------------------------------*/
extern void initNexGen(void);

#endif /* _DISPLAY_H_ */

/* Display timing defines */

#if defined(DISPLAY_TIMING)

#define TIMING_VARIABLES uint32_t _time1,_time2;
#define TIMING_START _time1 = get_milliseconds ();

#define TIMING_END(label)                           \
  _time2 = get_milliseconds ();                     \
  if (_time2 > _time1)                              \
    printf ("%s - %d\n", label, (_time2 - _time1));

#else

#define TIMING_VARIABLES
#define TIMING_START
#define TIMING_END(label)

#endif //DISPLAY_TIMING

