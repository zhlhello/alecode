/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

#ifndef _ROFS_R_H_
#define _ROFS_R_H_

#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
  T Y P E D E F S  A N D  D E F I N E S
  ---------------------------------------------------------------------------*/

typedef enum {
    ROFS_APPDATA = 0,
    ROFS_APPCUST = 1,
    ROFS_APPL10N = 2,
    MAX_ROFS
} rofs_id_t;

#define _MAX_FILENAME_LEN_  256

typedef struct
{
    FILE  *fp;
    char   file_name[_MAX_FILENAME_LEN_];
    char  *faddr_mem;
    int    file_size;
} FILE_t;


typedef enum {
    ROFS_RSC_BOOTIMAGE = 0,
    ROFS_RSC_IMAGE,
    ROFS_RSC_SKIN,
    ROFS_RSC_SKININFO,
    ROFS_RSC_ICON,
    ROFS_RSC_FONT,
    ROFS_RSC_DICT,
    ROFS_RSC_AUDIO,
} rofs_rsc_t;


/*-----------------------------------------------------------------------------
  Create path to file
  ---------------------------------------------------------------------------*/
extern char *rofs_make_path(char *dest, rofs_rsc_t rsc_type, const char* filename, bool_t custo);

/*-----------------------------------------------------------------------------
  Open file
  ---------------------------------------------------------------------------*/
extern FILE_t *rofs_open(rofs_rsc_t rsc_type, const char *filename);

/*-----------------------------------------------------------------------------
  Close file
  ---------------------------------------------------------------------------*/
extern int rofs_close(FILE_t *file);

/*-----------------------------------------------------------------------------
  Return file size
  ---------------------------------------------------------------------------*/
extern int rofs_fsize(FILE_t *file);

/*-----------------------------------------------------------------------------
  Read file content and return a pointer to internal allocated memory.
  This memory is deallocated when file is closed (rofs_close)
  ---------------------------------------------------------------------------*/
extern const unsigned char *rofs_faddr(FILE_t *file);

/*-----------------------------------------------------------------------------
  Read file content into the provided memory.
  ---------------------------------------------------------------------------*/
extern int rofs_fread(FILE_t *file, char *dstptr, int dstlen);

/*-----------------------------------------------------------------------------
  Iterate the specified directory and callback when a file matching the given
  prefix is found
  ---------------------------------------------------------------------------*/
extern int rofs_list(rofs_rsc_t rsc_type, const char *prefix,
    void (*cb_onMatch)(const char *prefix, const char *filename)
);

/*-----------------------------------------------------------------------------
  Initialization
  ---------------------------------------------------------------------------*/
extern void init_rofs();

/*-----------------------------------------------------------------------------
  Cleanup
  ---------------------------------------------------------------------------*/
extern void term_rofs();

/*-----------------------------------------------------------------------------
  Return TRUE if the given ROFS exists
  ---------------------------------------------------------------------------*/
extern bool_t rofs_is_present(rofs_id_t rofs_id);


/*-----------------------------------------------------------------------------
  O L D  S T U F F S
  ---------------------------------------------------------------------------*/
// TODO: for compatibility with existing source code
extern bool_t __rofs_check__(const char *p_binary);

// TODO: for compatibility with existing source code
extern void rofs_invalidate(rofs_id_t rofs_id);

#ifdef __cplusplus
}
#endif

#endif	//_ROFS_R_H_
