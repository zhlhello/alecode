/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#ifndef _I_ICON_H_
#define _I_ICON_H_

#include "objmgr.h"
// XTSce23932+
/*-----------------------------------------------------------------------------
  Les identifiants des icones NOE ont le bit de poid fort a 1
  ---------------------------------------------------------------------------*/
#define ICON_NOE                       0x8000

// XTSce23932-

/*-----------------------------------------------------------------------------
  to be completed
  ---------------------------------------------------------------------------*/
extern void disp_i_iconCreate(registerItem *item,
                              uint16_t       icon,
                              NGWinstance   *inst,
                              int            prop,
                              int            idx );

/*-----------------------------------------------------------------------------
  to be completed
  ---------------------------------------------------------------------------*/
extern void disp_i_iconBlinkFlush(registerItem *item);

extern void disp_i_iconErase(registerItem *item,
                             NGWinstance   *inst,
                             int            prop,
                             int            idx );

/*-----------------------------------------------------------------------------
  retourne les dimensions d'une icone

  iconid dans [0x8000 .. 0x8???] ou dans [0 .. 0x7fff]
  ---------------------------------------------------------------------------*/
extern void disp_i_iconSize(uint16_t iconid, NGGsize *size);

/*-----------------------------------------------------------------------------
  return iconid from widget or icon pointer
  XTSce32049 function added
  ---------------------------------------------------------------------------*/
extern uint16_t disp_i_iconLookup(NGWinstance* inst, NGGimage *iconpt, int item_number);

/*-----------------------------------------------------------------------------
  charge une icone
  ---------------------------------------------------------------------------*/
extern NGGimage *load_icon(uint16_t iconid);
/*-----------------------------------------------------------------------------
  OnSkinsReload event support
  ---------------------------------------------------------------------------*/
extern void icons_reload();

extern void disp_init_iconsmgr(void);

#endif /* _I_ICON_H_ */
