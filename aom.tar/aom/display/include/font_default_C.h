
/*
 * This file was automatically generated
 * please do not edit
 *
 * date: Fri Jul  1 11:27:10 2005
 */
#ifndef _FONT_DEFAULT_C_H_
#define _FONT_DEFAULT_C_H_

#define FONT_DEFAULT_C_SIZE    1046
#define FONT_DEFAULT_C_CTIME   1118913883UL
#define FONT_DEFAULT_C_ASCTIME "Thu Jun 16 11:24:43 2005"

extern const unsigned char font_default_C[FONT_DEFAULT_C_SIZE];

#endif /* _FONT_DEFAULT_C_H_ */
