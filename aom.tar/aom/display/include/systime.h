#ifndef _SYSTIME_H_
#define _SYSTIME_H_


#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------

   FUNCTION
         get_milliseconds

   DESCRIPTION
         return the number of milliseconds since terminal is up.

   INPUT
         NONE

   OUTPUT
         uint32_t,

 ----------------------------------------------------------------------------*/
extern uint32_t get_milliseconds(void);

#ifdef __cplusplus
}
#endif


#endif /* _SYSTIME_H_ */
