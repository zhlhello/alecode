/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/

#ifndef _CLASS_CODE_H_
#define _CLASS_CODE_H_


#define OPCODE_C_context                0
#define OPCODE_C_terminal               1
#define OPCODE_C_keyboard               2
#define OPCODE_C_audioconfig            3
#define OPCODE_C_security               4
#define OPCODE_C_leds                   5
#define OPCODE_C_screen                 6
#define OPCODE_C_date                   7
#define OPCODE_C_AOMV                   8
#define OPCODE_C_bluetooth              9
#define OPCODE_C_locappl               10
// free 11
#define OPCODE_C_callstate             12


#define OPCODE_C_framebox             128
#define OPCODE_C_tabbox               129
#define OPCODE_C_listbox              130
#define OPCODE_C_actionlistbox        131
#define OPCODE_C_textbox              132
#define OPCODE_C_actionbox            133
#define OPCODE_C_inputbox             134
#define OPCODE_C_checkbox             135
#define OPCODE_C_datebox              136
#define OPCODE_C_timerbox             137
#define OPCODE_C_popupbox             138
#define OPCODE_C_dialogbox            139
#define OPCODE_C_sliderbar            140
#define OPCODE_C_progressbar          141
#define OPCODE_C_imagebox             142
#define OPCODE_C_iconbox              143
#define OPCODE_C_AOMVbox              144
#define OPCODE_C_telephonicbox        145
#define OPCODE_C_keyboard_context     146
#define OPCODE_C_AOMEL                147
#define OPCODE_C_AOM10                148
#define OPCODE_C_AOM40                149
#define OPCODE_C_idletimer            150
#define OPCODE_C_telephonicboxitem    151
#define OPCODE_C_bluetooth_device     152
#define OPCODE_C_headerbox            153
// XTSce72250+
#define OPCODE_C_ime_context          154
// XTSce72250-

#endif /* _CLASS_CODE_H_ */
