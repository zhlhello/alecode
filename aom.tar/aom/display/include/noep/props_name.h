/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         props_name.h
 
   DATED:          2003/05/27
 
   AUTHOR:         N. Bertin
 
   DESCRIPTION:    property names

   SccsId=         @(#)props_name.h	1.2  03/06/20

   HISTORY: 

      - creation   2003/05/27

-----------------------------------------------------------------------------*/
#ifndef _PROPS_NAME_H_
#define _PROPS_NAME_H_


/*-----------------------------------------------------------------------------
  property opcode -> property name
  ---------------------------------------------------------------------------*/
extern char *P_get_name(uint8_t P);


#endif /* _PROPS_NAME_H_ */
