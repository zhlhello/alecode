/*-----------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         props_code.h

   DATED:          2003/06/04

   AUTHOR:         N. Bertin

   DESCRIPTION:    properties opcodes

   HISTORY:

      - creation   2003/06/04
      - 2004/02/05 XTSce19852 ajout attribut serialnum

      - 2004/03/09 nbe
        Ajout des proprietes suivantes: hardversion, softversion, flash_size,
        sdram_size et reset_cause.

      - 09/03/04 nbe
        sdram_size devient ram_size et flash_size devient rom_size. Sur UA, on
        supprime la version soft et la cause de reset, mais on ajoute ram_size.

      - 2004/06/04 mge
        Ajout propriete cycling_time

      - 2004/08/12 malain
        Ajout proprietes OPCODE_P_A_code et OPCODE_P_A_data

      - 2004/08/20 samuelg XTSce31116
        Ajout propriete OPCODE_P_B_inputborder

      - 2004/08/25 samuelg XTSce32664
        Ajout propriete OPCODE_P_B_disablelongpress

      - 2004/08/25 XTSce18929 mge
        supression OPCODE_P_B_hoffset / OPCODE_P_B_hoffset (protocole R2)

      - 2004/01/31 XTSce18929 mge
        Modifs R3 : supression OPCODE_P_B_bth_beep
                    ajout OPCODE_P_B_bth_ringing

      - 2005/03/04 vbr
        add "URI" (imagebox) and "fetch_timeout" (terminal) property opcodes
        ("PRS direct link")

      - 2005/04/08 cde
        Add properties list_type, frame_type

      - 2005/04/20 cyasar
        Add properties qos_ticket, delay_max_handset, delay_max_handsfree,
        delay_tx, delay_rx

      - 2005/05/27 nbe
        add properties use_customisation, custversion, L10Nversion and
        ringings_count (all are in terminal object)

      - 2005/06/02 nbe
        - 'use_customisation' opcode was already used in R3.0 (mask_subst)
        - added MIPT properties

      - 2005/08/29 - F de Bov�e
        - XTSce59363: Add page_active property to AOMVBOX

      - 2005/09/15 - N. MAZET - P. GUERRI
	    - XTSce59936: textbox : write to a position

      - 2006/02/16 phg
	    - DEV IME XTSce72250: Add ime_lock property

      - 2006/05/03 agu
        XTSce72249 : EAP-TLS feature dev: add security related properties

      - 2006/10/12 gulefevr
        XTSce86902 Remove arp_spoofing property from terminal object

      - 2006/11/08 misulyan
        R6.0: add binary_suffix &  binary_count  properties into terminal object

      - 2007/09/24 misulyan
        R7.0 Modifications -  add SIPCversion into terminal object

      - 2016/04/07 David Wang
        crqms00189982 [8018]: In Dial by name search results the right soft key function is not inline with other NOE3G Phones

      - 2016/06/12 Anne li
        crqms00198263 :[NOE3G IP]Hebrew IME support for OXO  R11.0

      - 2016/11/18 bertin
        user menu interaction with call server

      - 2016/11/11 David Wang
        crqms00206913 [Hebrew]when 8018 language is in English IME list should not be displayed

-----------------------------------------------------------------------------*/
#ifndef _PROPS_CODE_H_
#define _PROPS_CODE_H_

//
// basic properties
//

#define OPCODE_P_B_objectid                       0
#define OPCODE_P_B_ownership                      1
#define OPCODE_P_B_reset_mode                     2
#define OPCODE_P_B_mtu                            3
#define OPCODE_P_B_negative_ack                   4
#define OPCODE_P_B_type                           5
#define OPCODE_P_B_help_timeout                   6
#define OPCODE_P_B_longpress                      7
#define OPCODE_P_B_count                          8
#define OPCODE_P_B_eventmode                      9
#define OPCODE_P_B_numpad_ownership              10
#define OPCODE_P_B_navigator_ownership           11
#define OPCODE_P_B_telephony_ownership           12
#define OPCODE_P_B_progkeys_ownership            13
#define OPCODE_P_B_alphakeys_ownership           14
#define OPCODE_P_B_numpad_eventmode              15
#define OPCODE_P_B_onoff                         16
#define OPCODE_P_B_bpp                           17
#define OPCODE_P_B_w                             18
#define OPCODE_P_B_h                             19
#define OPCODE_P_B_contrast                      20
#define OPCODE_P_B_clearscreen                   21
#define OPCODE_P_B_system_id                     22  // OXE = 0, OXO = 1
#define OPCODE_P_B_advanced_mode                 23  // STANDARD = 0, ADVANCED = 1 //David/crqms00189982
#define OPCODE_P_B_year                          24
#define OPCODE_P_B_month                         25
#define OPCODE_P_B_day                           26
#define OPCODE_P_B_m                             27
#define OPCODE_P_B_s                             28
#define OPCODE_P_B_enable                        29
#define OPCODE_P_B_address                       30
#define OPCODE_P_B_disable                       31  // bertin: locappl
//#define OPCODE_P_B_protocol                      32
#define OPCODE_P_B_name                          33
//#define OPCODE_P_B_checked                       34
//#define OPCODE_P_B_unchecked                     35
#define OPCODE_P_B_anchorid                      36
#define OPCODE_P_B_grid                          37
#define OPCODE_P_B_x                             38
#define OPCODE_P_B_y                             39
#define OPCODE_P_B_visible                       40
#define OPCODE_P_B_border                        41
#define OPCODE_P_B_fontid                        42
#define OPCODE_P_B_active                        43
#define OPCODE_P_B_halign                        44
#define OPCODE_P_B_valign                        45
#define OPCODE_P_B_size                          46
#define OPCODE_P_B_mode                          47
#define OPCODE_P_B_showevent                     48
#define OPCODE_P_B_showactive                    49
#define OPCODE_P_B_action_active                 50
#define OPCODE_P_B_action_count                  51
//#define OPCODE_P_B_foreground                    52
//#define OPCODE_P_B_background                    53
#define OPCODE_P_B_icon                          54
#define OPCODE_P_B_label                         55
#define OPCODE_P_B_value                         56
#define OPCODE_P_B_password                      57
#define OPCODE_P_B_cursor                        58
#define OPCODE_P_B_mask                          59
#define OPCODE_P_B_qos_ticket                    60
#define OPCODE_P_B_focus                         61
#define OPCODE_P_B_state                         62
#define OPCODE_P_B_format                        63
#define OPCODE_P_B_incdec                        64
#define OPCODE_P_B_value_notify                  65
#define OPCODE_P_B_timeout                       66
#define OPCODE_P_B_min                           67
#define OPCODE_P_B_max                           68
#define OPCODE_P_B_data                          69
#define OPCODE_P_B_custversion                   70
#define OPCODE_P_B_L10Nversion                   71
#define OPCODE_P_B_append                        72
#define OPCODE_P_B_shortpress                    73
#define OPCODE_P_B_autorepeat                    74
#define OPCODE_P_B_repetition                    75
#define OPCODE_P_B_vsplit                        76
#define OPCODE_P_B_accesskey                     77
#define OPCODE_P_B_realcount                     78
#define OPCODE_P_B_start                         79
#define OPCODE_P_B_modal                         80
#define OPCODE_P_B_session_timeout               81
#define OPCODE_P_B_softkeys_ownership            82
#define OPCODE_P_B_ringings_count                83
#define OPCODE_P_B_cod                           84
#define OPCODE_P_B_bonded                        85
#define OPCODE_P_B_link_key                      86
#define OPCODE_P_B_pin                           87
#define OPCODE_P_B_term_type                     88
#define OPCODE_P_B_link_type                     89
#define OPCODE_P_B_circular                      90
#define OPCODE_P_B_autospread                    91
#define OPCODE_P_B_backlight_timeout             92
#define OPCODE_P_B_screensaver_timeout           93
#define OPCODE_P_B_cycling                       94
#define OPCODE_P_B_CS_idle_state                 95
#define OPCODE_P_B_PS_idle_state                 96
#define OPCODE_P_B_bonded_devices                97
#define OPCODE_P_B_serialnum                     98
#define OPCODE_P_B_hardversion                   99
#define OPCODE_P_B_softversion                  100
#define OPCODE_P_B_rom_size                     101
#define OPCODE_P_B_ram_size                     102
#define OPCODE_P_B_reset_cause                  103
#define OPCODE_P_B_cycling_time                 104
//#define OPCODE_P_B_arp_spoofing                 105

#define OPCODE_P_B_focused_cursor_index         105 //crqms00198263 Anne

#define OPCODE_P_B_inputborder                  106
#define OPCODE_P_B_disablelongpress             107
#define OPCODE_P_B_all_icons_off                108
#define OPCODE_P_B_all_labels_off               109
#define OPCODE_P_B_widgets_size                 110
#define OPCODE_P_B_list_type                    111
#define OPCODE_P_B_frame_type                   112
#define OPCODE_P_B_bth_ringing                  113
#define OPCODE_P_B_URI                          114
#define OPCODE_P_B_fetch_timeout                115
#define OPCODE_P_B_mask_subst                   116
#define OPCODE_P_B_use_customisation            117

//
// mipt
//
#define OPCODE_P_B_ADTTS_request                118
#define OPCODE_P_B_AP_mac_notify                119

// XTSce59363 +
#define OPCODE_P_B_page_active                  120
// XTSce59363 -

//XTSce59936+
#define OPCODE_P_B_overwrite                    121
//XTSce59936-

//XTSce72250+
#define OPCODE_P_B_ime_lock                     122
//XTSce72250-

//security
#define OPCODE_P_B_method                       123
#define OPCODE_P_B_login                        124

//R6.0
#define OPCODE_P_B_binary_suffix                125
#define OPCODE_P_B_binary_count                 126

//R7.0
#define OPCODE_P_B_SIPCversion                  127


//
// array properties
//
#define OPCODE_P_A_dflt                         128
#define OPCODE_P_A_shift                        129
#define OPCODE_P_A_alt                          130
#define OPCODE_P_A_key_ownership                131
#define OPCODE_P_A_key_eventmode                132
#define OPCODE_P_A_value                        133
#define OPCODE_P_A_mode                         134
#define OPCODE_P_A_color                        135
#define OPCODE_P_A_type                         136
#define OPCODE_P_A_icon                         137
#define OPCODE_P_A_label                        138
#define OPCODE_P_A_ownership                    139
#define OPCODE_P_A_enable                       140
#define OPCODE_P_A_state                        141
#define OPCODE_P_A_name                         142
#define OPCODE_P_A_number                       143
#define OPCODE_P_A_action_icon                  144
#define OPCODE_P_A_action_label                 145
#define OPCODE_P_A_action_value                 146
#define OPCODE_P_A_today                        147
#define OPCODE_P_A_tomorrow                     148
#define OPCODE_P_A_action_key                   149
#define OPCODE_P_A_code                         150
#define OPCODE_P_A_data                         151
#define OPCODE_P_A_delay_max_handset            152
#define OPCODE_P_A_delay_max_handsfree          153
#define OPCODE_P_A_delay_tx                     154
#define OPCODE_P_A_delay_rx                     155
#define OPCODE_P_A_pem_data                     156
#define OPCODE_P_A_serial_number                157
#define OPCODE_P_A_owner_name                   158
#define OPCODE_P_A_issuer_name                  159
#define OPCODE_P_A_end_date                     160

//crqms00198263 Anne +
#define OPCODE_P_A_keychar                      161
#define OPCODE_P_A_hebrew_IME_flag              162
#define OPCODE_P_A_R2L_flag                     163
//crqms00198263 Anne -

#endif /* _PROPS_CODE_H */
