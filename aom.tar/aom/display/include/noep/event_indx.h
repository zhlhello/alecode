/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         event_indx.h
 
   DATED:          2003/05/27
 
   AUTHOR:         N. Bertin
 
   DESCRIPTION:    event indexes

   SccsId=         @(#)event_indx.h	1.1  03/05/27

   HISTORY: 

      - creation   2003/05/27

-----------------------------------------------------------------------------*/
#ifndef _EVENT_INDX_H_
#define _EVENT_INDX_H_



/*-----------------------------------------------------------------------------
  initialize event/index table
  ---------------------------------------------------------------------------*/
extern void init_E_indx(void);



/*-----------------------------------------------------------------------------
  event opcode -> event index
  ---------------------------------------------------------------------------*/
extern uint8_t E_get_indx(uint8_t E);



#endif /* _EVENT_INDX_H_ */
