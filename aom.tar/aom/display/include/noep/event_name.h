/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         event_name.h
 
   DATED:          2003/05/27
 
   AUTHOR:         N. Bertin
 
   DESCRIPTION:    event name

   SccsId=         @(#)event_name.h	1.1  03/05/27

   HISTORY: 

      - creation   2003/05/27

-----------------------------------------------------------------------------*/
#ifndef _EVENT_NAME_H_
#define _EVENT_NAME_H_


/*-----------------------------------------------------------------------------
  event index -> event name
  ---------------------------------------------------------------------------*/
extern char *E_get_name(uint8_t Eindx);


#endif /* _EVENT_NAME_H_ */
