/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#ifndef _CLASS_DATA_H_
#define _CLASS_DATA_H_


typedef struct
{
	uint16_t objectid;
} C_object_t;


typedef struct
{
	uint16_t objectid;
	uint16_t anchorid;
#if defined(DISPLAY)
	uint8_t  grid;
	uint8_t  x;
	uint8_t  y;
	uint8_t  w;
	uint8_t  h;
#endif
	bool_t   visible;
#if defined(DISPLAY)
	int16_t  cycling_time;
#endif
} C_widget_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    ownership;
} C_context_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    reset_mode;
	uint16_t   mtu;
	bool_t     negative_ack;
	bool_t     CS_idle_state;
	bool_t     PS_idle_state;
	uint16_t   session_timeout;
	uint8_t    link_type;
	uint8_t    term_type;
	char      *serialnum;
	uint32_t   serialnum_size;
	char      *hardversion;
	uint32_t   hardversion_size;
	char      *softversion;
	uint32_t   softversion_size;
	uint32_t   rom_size;
	uint32_t   ram_size;
	uint32_t   reset_cause;
	uint16_t   fetch_timeout;
	bool_t     use_customisation;
	char      *custversion;
	uint32_t   custversion_size;
	char      *L10Nversion;
	uint32_t   L10Nversion_size;
	uint8_t    ringings_count;
	bool_t     ime_lock;
	char      *binary_suffix;
	uint32_t   binary_suffix_size;
	uint8_t    binary_count;
	char      *SIPCversion;
	uint32_t   SIPCversion_size;
	uint8_t    system_id;
} C_terminal_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    type;
	uint16_t   help_timeout;
	uint16_t   longpress;
	uint16_t   shortpress;
	uint16_t   autorepeat;
	uint16_t   repetition;
	uint16_t   count;
} C_keyboard_t;


typedef struct
{
	uint16_t   objectid;
	bool_t     enable;
	bool_t     qos_ticket;

	struct s_audioconfig_items_delay_max_handset
	{
	uint32_t   delay_max_handset;
	} items_delay_max_handset[MAX_TYPE_DELAY_POSSIBLE];

	struct s_audioconfig_items_delay_max_handsfree
	{
	uint32_t   delay_max_handsfree;
	} items_delay_max_handsfree[MAX_TYPE_DELAY_POSSIBLE];

	struct s_audioconfig_items_delay_tx
	{
	uint32_t   delay_tx;
	} items_delay_tx[MAX_TYPE_DELAY_WANTED];

	struct s_audioconfig_items_delay_rx
	{
	uint32_t   delay_rx;
	} items_delay_rx[MAX_TYPE_DELAY_WANTED];
} C_audioconfig_t;


typedef struct
{
	uint16_t   objectid;
	bool_t     onoff;
	uint8_t    count;

	struct s_leds_items
	{
	uint8_t    mode;
	uint8_t    color;
	} items[MAX_LEDS];
} C_leds_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    type;
	uint8_t    bpp;
	uint8_t    contrast;
	bool_t     clearscreen;
	uint32_t   backlight_timeout;
	uint32_t   screensaver_timeout;
	uint8_t    widgets_size;

	struct s_screen_items
	{
	uint16_t   code;
	char      *data;
	uint32_t   data_size;
	} items[MAX_SCREEN_CHAR];
} C_screen_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   year;
	uint8_t    month;
	uint8_t    day;
	uint8_t    h;
	uint8_t    m;
	uint8_t    s;

	struct s_date_items
	{
	char      *today;
	char      *tomorrow;
	} items[2];
} C_date_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    count;
	bool_t     all_icons_off;

	struct s_AOMV_items
	{
	uint8_t    type;
	uint16_t   icon;
	char      *label;
	char      *value;
	uint8_t    ownership;
	bool_t     enable;
	} items[MAX_AOMV_KEYS];
} C_AOMV_t;


typedef struct
{
	uint16_t   objectid;
	bool_t     enable;
	uint8_t    count;

	struct s_callstate_items
	{
	uint8_t    state;
	char      *name;
	char      *number;
	} items[MAX_CALLSTATE_ITEMS];
} C_callstate_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    method;
	char      *login;

	struct s_security_certificate
	{
	char      *pem_data;
	char      *serial_number;
	char      *owner_name;
	char      *issuer_name;
	char      *end_date;
	} certificate[MAX_CERT];
} C_security_t;


typedef struct
{
	uint16_t   objectid;
	char      *address;
	char      *name;
	uint8_t    state;
	bool_t     bth_ringing;
	bool_t     bonded_devices;
} C_bluetooth_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    enable;
	uint8_t    disable;
} C_locappl_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    frame_type;
	uint8_t    border;
	uint8_t    vsplit;
	bool_t     autospread;
	bool_t     cycling;
} C_framebox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    active;
	uint8_t    count;
	uint8_t    advanced_mode;

	struct s_tabbox_items
	{
	uint16_t   icon;
	char      *label;
	char      *value;
	} items[MAX_TABS];
} C_tabbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint16_t   icon;
	char      *label;
} C_headerbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint8_t    mode;
	uint8_t    active;
	bool_t     showevent;
	bool_t     showactive;
	bool_t     circular;
	uint8_t    realcount;
	uint8_t    start;
	uint8_t    count;
	uint8_t    list_type;
	uint8_t    border;
	bool_t     disablelongpress;
	uint8_t    advanced_mode;

	struct s_listbox_items
	{
	uint16_t   icon;
	char      *label;
	char      *value;
	uint8_t    ownership;
	} items[MAX_LISTBOX_ITEMS];
} C_listbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    active;
	uint8_t    count;
	uint8_t    border;
	uint8_t    mode;
	int32_t    timeout;

	struct s_actionlistbox_items
	{
	char      *label;
	char      *value;
	uint8_t    ownership;
	} items[MAX_ACTIONLIST_ITEMS];
} C_actionlistbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint16_t   icon;
	char      *label;
	char      *append;
	uint8_t    mode;
	uint16_t   cursor;
	char      *overwrite;
} C_textbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint16_t   icon;
	char      *label;
	char      *value;
	uint8_t    ownership;
} C_actionbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint16_t   icon;
	char      *label;
	char      *value;
	bool_t     enable;
	bool_t     password;
	uint8_t    border;
	uint8_t    size;
	char      *mask;
	bool_t     focus;
	bool_t     inputborder;
	uint16_t   mask_subst;
	uint16_t   count;
	uint16_t   cursor;
	char      *append;
	uint16_t   focused_cursor_index;

	struct s_inputbox_inputvalue
	{
	uint32_t   keychar;
	bool_t     hebrew_IME_flag;
	bool_t     R2L_flag;
	} inputvalue[MAX_KEY_VALUE_INPUTBOX];
} C_inputbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint16_t   icon;
	char      *label;
	bool_t     enable;
	bool_t     state;
} C_checkbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	char      *format;
} C_datebox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint16_t   icon;
	char      *label;
	uint8_t    state;
	uint8_t    incdec;
	char      *format;
	uint8_t    mode;
	int32_t    value;
	uint32_t   value_notify;
} C_timerbox_t;


typedef struct
{
	uint16_t   objectid;
	uint32_t   value_notify;
} C_idletimer_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	bool_t     modal;
	uint8_t    mode;
	uint32_t   timeout;
	uint8_t    border;
} C_popupbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint8_t    border;
	bool_t     modal;
	uint8_t    mode;
	int32_t    timeout;
	uint16_t   icon;
	char      *label;
	uint8_t    count;

	struct s_dialogbox_items
	{
	uint16_t   action_icon;
	char      *action_label;
	char      *action_value;
	} items[MAX_DIALOGBOX_ITEMS];
} C_dialogbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint16_t   icon;
	char      *label;
	int32_t    value;
	int32_t    min;
	int32_t    max;
	uint8_t    incdec;
	uint8_t    border;
} C_sliderbar_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    fontid;
	uint8_t    halign;
	uint8_t    valign;
	uint16_t   icon;
	char      *label;
	uint8_t    value;
	uint8_t    value_notify;
} C_progressbar_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    format;
	uint32_t   size;
	char      *data;
	uint32_t   data_size;
	char      *append;
	uint32_t   append_size;
	char      *URI;
} C_imagebox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint16_t   icon;
} C_iconbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	uint8_t    page_active;
	uint8_t    count;
	uint32_t   timeout;
} C_AOMVbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint8_t    grid;
	uint8_t    x;
	uint8_t    y;
	uint8_t    w;
	uint8_t    h;
	bool_t     visible;
	uint16_t   cycling_time;
	bool_t     enable;
	uint8_t    vsplit;
	uint32_t   timeout;
} C_telephonicbox_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	uint16_t   icon;
	uint8_t    accesskey;
	bool_t     focus;
	char      *label;
} C_telephonicboxitem_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    ownership;
	uint8_t    eventmode;
	uint8_t    numpad_ownership;
	uint8_t    navigator_ownership;
	uint8_t    telephony_ownership;
	uint8_t    progkeys_ownership;
	uint8_t    softkeys_ownership;
	uint8_t    alphakeys_ownership;
	uint8_t    numpad_eventmode;
	uint8_t    count;

	struct s_keyboard_context_items
	{
	uint8_t    key_ownership;
	uint8_t    key_eventmode;
	} items[MAX_KEYS];
} C_keyboard_context_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    address;
	bool_t     all_icons_off;
	bool_t     all_labels_off;
	uint8_t    contrast;
	uint8_t    eventmode;
	uint8_t    count;

	struct s_AOMEL_items
	{
	uint8_t    type;
	uint16_t   icon;
	bool_t     b_refresh;
	char      *label;
	uint32_t   value;
	uint8_t    ownership;
	} items[MAX_AOMEL_KEYS];
} C_AOMEL_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    address;
	bool_t     all_icons_off;
	uint8_t    contrast;
	uint8_t    eventmode;
	uint8_t    count;

	struct s_AOM10_items
	{
	uint8_t    type;
	uint16_t   icon;
	bool_t     b_refresh;
	uint32_t   value;
	uint8_t    ownership;
	} items[MAX_AOM10_KEYS];
} C_AOM10_t;


typedef struct
{
	uint16_t   objectid;
	uint8_t    address;
	bool_t     all_icons_off;
	uint8_t    contrast;
	uint8_t    eventmode;
	uint8_t    count;

	struct s_AOM40_items
	{
	uint8_t    type;
	uint16_t   icon;
	bool_t     b_refresh;
	uint32_t   value;
	uint8_t    ownership;
	} items[MAX_AOM40_KEYS];
} C_AOM40_t;


typedef struct
{
	uint16_t   objectid;
	uint16_t   anchorid;
	char      *address;
	char      *name;
	uint32_t   cod;
	bool_t     enable;
	bool_t     bonded;
	uint8_t    type;
	char      *pin;
} C_bluetooth_device_t;


typedef struct
{
	uint16_t   objectid;
	bool_t     enable;
	bool_t     visible;
	uint8_t    type;
	int32_t    timeout;
	int32_t    session_timeout;

	struct s_ime_context_items_mode
	{
	bool_t     mode;
	} items_mode[MAX_IME_MODE];

	struct s_ime_context_items
	{
	char      *name;
	bool_t     state;
	bool_t     enable;
	} items[MAX_PLUGINS];
} C_ime_context_t;



#endif /* _CLASS_DATA_H_ */
