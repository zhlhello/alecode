/*-----------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         proto_defs.h

   DATED:          2003/05/27

   AUTHOR:         N. Bertin

   DESCRIPTION:    protocol definitions (min/max/etc)

   SccsId=         @(#)proto_defs.h	1.31  04/09/09

   HISTORY:

      - creation   2003/05/27
      - 2004/01/07 label dialogbox  128 ->  512
                   label textbox   1000 -> 1024
      - 2003/01/12 ajout BACKLIGHT_TIMEOUT et SCREENSAVER_TIMEOUT
                   @20040114@tag0@nbe
      - 2004/02/09 modif MAX_VALUE_INPUTBOX: 128 -> 250
      - 2004/02/17 A. ESSELIN : MTU handling (DEV ua_mtu)

      - 2004/08/12 malain
                   define and set MAX_SCREEN_CHAR to the specified
                   value (NOE A)

      - 2004/08/26 mge XTSce35160
                   Modif MIN_CYCLING_TIME 1 -> 0
      - 2005/04/20 cyasar
                   video lip synchronisation: definition of

      - 2005/08/20 Philippe GUERRI
        XTSce59362 : InputBox: Limitation of number of characters to be entered

      - 2006/02/16 phg
                   DEV IME XTSce72250

      - 2006/05/03 agu
        XTSce72249 : EAP-TLS feature dev: add security related definition

      - 2008/01/16 crms00100397: define correct value for AOM_MAX_PAGE_ACTIVE
      - 2009/04/17 genshenl
        crms00146973: add define value for AOM_MAX_TIMEOUT

      - 2016/06/12 Anne li
        crqms00198263 :[NOE3G IP]Hebrew IME support for OXO  R11.0

      - 2017/05/09 bertin
        Local management (vol+/vol-) of contrast/brightness when phone is idle
-----------------------------------------------------------------------------*/
#ifndef _PROTO_DEFS_H_
#define _PROTO_DEFS_H_

#define MIN_DYN_OID              0x0080
#define MAX_DYN_OID              0xffff

#define MIN_MTU                      16
#define MAX_MTU                    1024
#define DEF_MTU                    1024

#define MIN_CONTRAST                  0
#define MAX_CONTRAST                 15
#define LOCAL_CONTRAST_MNGT         255

#define MIN_KEYS_LOGICAL             32 // see protocol spec (NOE A)
#define MAX_KEYS_LOGICAL             73 // see protocol spec (NOE C)
#define MAX_KEYS                     81 // see keys.h (NOE A + NOE B + NOE C)
#define MAX_PROGKEYS                  6

#define MIN_LEDS_LOGICAL              6 // see protocol spec (NOE B & NOE C)
#define MAX_LEDS_LOGICAL              9 // see protocol spec (NOE A)
#define MAX_LEDS                     32 // WARNING: must be greater than MAX_LEDS_COUNT in ledid.h from platform.
                                        // it's the maximum number of leds we allow the system to drive
#define MAX_SCREEN_W                160
#define MAX_SCREEN_H                100
#define MAX_AOMV_KEYS                72
#define MAX_AOMV_KEYS_OXO            40
#define MAX_AOMEL_KEYS               14
#define MAX_AOM10_KEYS               10
#define MAX_AOM40_KEYS               40
#if (MAX_AOMV_KEYS >= MAX_AOMEL_KEYS)
#define MAX_AOM_KEYS      MAX_AOMV_KEYS
#else
#define MAX_AOM_KEYS     MAX_AOMEL_KEYS
#endif

#define AOM_MAX_PAGE_ACTIVE          18 // 72/4 for NOE B

//crms00146973 genshenl+
#define AOM_MAX_TIMEOUT              3456000 //86400*40=40 days
//crms00146973 genshenl-

#define MAX_SCREEN_CHAR              20 // NOE A


#if defined(UA_PHONE)
#define MAX_CALLSTATE_ITEMS          82 //140
#else //(IP_PHONE)
#define MAX_CALLSTATE_ITEMS         120 //140
#endif

#define MAX_TABS                     16
#define MAX_LISTBOX_ITEMS            32
#define MAX_ACTIONLIST_ITEMS         16
#define MAX_DIALOGBOX_ITEMS           4
#define MAX_CERT                      1

#define MAX_X_GRID_TYPE1              9
#define MAX_X_GRID_TYPE2              MAX_X_GRID_TYPE1

#define MAX_Y_GRID_TYPE1              5
#define MAX_Y_GRID_TYPE2              9

#define MAX_W_GRID_TYPE1              (MAX_X_GRID_TYPE1+1)
#define MAX_W_GRID_TYPE2              (MAX_X_GRID_TYPE2+1)

#define MAX_H_GRID_TYPE1              (MAX_Y_GRID_TYPE1+1)
#define MAX_H_GRID_TYPE2              (MAX_Y_GRID_TYPE2+1)

#define COLOR_WHITE                   0
#define COLOR_LIGHTGREY               1
#define COLOR_GREY                    2
#define COLOR_BLACK                   3
#define COLOR_TRANSPARENT           255

#define AOM_MIN_ADDR                  0
#define AOM_MAX_ADDR                  7

#define AOM_MIN_CONTRAST              0
#define AOM_MAX_CONTRAST             15
#define AOM_DEFAULT_CONTRAST          8

#define MIN_SESSION_TIMEOUT           0
#define MAX_SESSION_TIMEOUT        1440 // seconds

#define BACKLIGHT_TIMEOUT           300 //  5 minutes
#define SCREENSAVER_TIMEOUT       14400 //  4 hours

#define MAX_LABEL_AOMV              128
#define MAX_NAME_CALLSTATE          128
#define MAX_NUMBER_CALLSTATE        128
#define MAX_LABEL_TABBOX             32
#define MAX_LABEL_HEADERBOX          64
#define MAX_LABEL_LISTBOX           250 // l'appli memo met un label d'inputbox dans une liste
#define MAX_LABEL_TEXTBOX          1024
#define MAX_LABEL_ACTIONBOX         128
#define MAX_LABEL_INPUTBOX          128
#define MAX_LABEL_CHECKBOX          128
#define MAX_LABEL_TIMERBOX          128
#define MAX_LABEL_DIALOGBOX         512
#define MAX_LABEL_DIALOGBOX_ACTION  128
#define MAX_LABEL_SLIDERBAR         128
#define MAX_LABEL_PROGRESSBAR       128
#define MAX_LABEL_TELEPHONICBOX     128
#define MAX_LABEL_AOMEL             80      //XTSce65600

#define MAX_VALUE_AOMV              128
#define MAX_VALUE_TABBOX            128
#define MAX_VALUE_LISTBOX           128
#define MAX_VALUE_ACTIONBOX         128

// max number of bytes for value = 3 (chinese UTF8 coding) X 128 (max number of characters)
#define MAX_KEY_VALUE_INPUTBOX      128 //crqms00198263 Anne
#define MAX_VALUE_INPUTBOX          384
#define MAX_VALUE_DIALOGBOX_ACTION  128

#define MAX_CYCLING_TIME           3600
#define MIN_CYCLING_TIME              0
#define DEFAULT_CYCLING_TIME         10

#define MAX_TYPE_DELAY_POSSIBLE       3
#define MAX_TYPE_DELAY_WANTED         2

#define MAX_PLUGINS                   8
#define MAX_IME_LANGUAGES_DICT        10

#define MAX_IME_MODE                  3
#define IME_MODE_CLOSE_ON_VALIDATION  0
#define IME_MODE_DIAL_BY_NAME         1
#define IME_MODE_REMOTEOPEN           2

#define MAX_NAME_IME_METHOD           32

#endif /* _PROTO_DEFS_H_ */
