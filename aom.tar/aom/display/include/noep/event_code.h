/*-----------------------------------------------------------------------------

   COMPONENT:      NOE

   MODULE:         event_code.h

   DATED:          2003/06/04

   AUTHOR:         N. Bertin

   DESCRIPTION:    events opcodes

   HISTORY:

      - creation   2003/06/04

      - 2004/06/03 nbe
        ajout opcode EVT_LOCAL_APPLICATION

      - 2004/06/04 nbe
        gestion des warnings: EVT_WARNING_CREATE/EVT_WARNING_SET_PROPERTY

      - 2004/07/21 phg
        Add new widget ActionListbox

      - 2004/07/30 nbe & malain
        add OPCODE_EVT_CHAR_NOT_FOUND

      - 2004/08/12 malain
        add OPCODE_EVT_CHAR_BAD_LENGTH

      - 2005/01/10 gulefevr
        Add of OPCODE_EVT_BT_BATTERY

      - 2005/04/20 cyasar
        Add of OPCODE_EVT_QOS_TICKET

      - 2005/07/19 nbe
        mipt: added OPCODE_EVT_ADTTS_RESPONSE & OPCODE_EVT_AP_MAC

      - 2006/02/16 phg
        DEV IME XTSce72250: added OPCODE_EVT_IME_LIST/OPCODE_EVT_IME_CHANGE/OPCODE_EVT_IME_OPEN/OPCODE_EVT_IME_REMOTEOPEN

      - 2007/06/05 mbr
        XTSce93285 Serviceability improvements

-----------------------------------------------------------------------------*/
#ifndef _EVENT_CODE_H_
#define _EVENT_CODE_H_


#define OPCODE_EVT_CONTEXT_SWITCH            0
#define OPCODE_EVT_RESET                     1
#define OPCODE_EVT_KEY_PRESS                 2
#define OPCODE_EVT_KEY_RELEASE               3
#define OPCODE_EVT_KEY_SHORTPRESS            4
#define OPCODE_EVT_KEY_LONGPRESS             5
#define OPCODE_EVT_ONHOOK                    6
#define OPCODE_EVT_OFFHOOK                   7
#define OPCODE_EVT_HELP                      8
#define OPCODE_EVT_WIDGETS_GC                9
#define OPCODE_EVT_ERROR_PROTOCOL           10
#define OPCODE_EVT_ERROR_CREATE             11
#define OPCODE_EVT_ERROR_DELETE             12
#define OPCODE_EVT_ERROR_SET_PROPERTY       13
#define OPCODE_EVT_ERROR_GET_PROPERTY       14
#define OPCODE_EVT_SUCCESS_CREATE           15
#define OPCODE_EVT_SUCCESS_DELETE           16
#define OPCODE_EVT_SUCCESS_SET_PROPERTY     17
#define OPCODE_EVT_ERROR_INSERT_ITEM        18
#define OPCODE_EVT_ERROR_DELETE_ITEM        19
#define OPCODE_EVT_SUCCESS_INSERT_ITEM      20
#define OPCODE_EVT_DEVICE_PRESENCE          21
#define OPCODE_EVT_KEY_LINE                 22
#define OPCODE_EVT_SUCCESS_DELETE_ITEM      23
#define OPCODE_EVT_BT_BONDING_RESULT        24
#define OPCODE_EVT_BT_KEY_SHORTPRESS        25
#define OPCODE_EVT_BT_KEY_LONGPRESS         26
#define OPCODE_EVT_BT_KEY_VERYLONGPRESS     27
#define OPCODE_EVT_LOCAL_APPLICATION        28
#define OPCODE_EVT_WARNING_CREATE           29
#define OPCODE_EVT_WARNING_SET_PROPERTY     30
#define OPCODE_EVT_ARP_SPOOFING             31
#define OPCODE_EVT_CHAR_NOT_FOUND           32
#define OPCODE_EVT_CHAR_BAD_LENGTH          33
#define OPCODE_EVT_QOS_TICKET               34
#define OPCODE_EVT_UA3_ERROR                35


#define OPCODE_EVT_TABBOX                  128
#define OPCODE_EVT_LISTBOX                 129
#define OPCODE_EVT_LISTBOX_FIRST           130
#define OPCODE_EVT_LISTBOX_LAST            131
#define OPCODE_EVT_ACTIONLISTBOX           132
#define OPCODE_EVT_ACTIONBOX               133
#define OPCODE_EVT_INPUTBOX                134
#define OPCODE_EVT_INPUTBOX_FOCUS_LOST     135
#define OPCODE_EVT_CHECKBOX                136
#define OPCODE_EVT_TIMERBOX                137
#define OPCODE_EVT_POPUPBOX_TIMEOUT        138
#define OPCODE_EVT_DIALOGBOX               139
#define OPCODE_EVT_SLIDERBAR               140
#define OPCODE_EVT_PROGRESSBAR             141
#define OPCODE_EVT_AOMVBOX                 142
#define OPCODE_EVT_TELEPHONICBOX_FOCUS     143
#define OPCODE_EVT_AOM_INSERTED            144
#define OPCODE_EVT_AOM_REMOVED             145
#define OPCODE_EVT_AOM_KEY_PRESS           146
#define OPCODE_EVT_IDLETIMER               147
#define OPCODE_EVT_GET_PROPERTY_RESULT     148
#define OPCODE_EVT_AOM_KEY_RELEASE         149
#define OPCODE_EVT_POPUPBOX_DISMISSED      150
#define OPCODE_EVT_DIALOGBOX_TIMEOUT       151
#define OPCODE_EVT_DIALOGBOX_DISMISSED     152
#define OPCODE_EVT_BT_BONDED_DEVICE        153
#define OPCODE_EVT_BT_INQUIRY_RESULT       154
#define OPCODE_EVT_BT_NAME_DISCOVERY       155
// XTSce72250+
#define OPCODE_EVT_IME_REMOTEOPEN          156
// XTSce72250-
// 157
#define OPCODE_EVT_BT_BATTERY              158

// XTSce72250+
#define OPCODE_EVT_IME_LIST                159
#define OPCODE_EVT_IME_CHANGE              160
#define OPCODE_EVT_IME_OPEN                161
// XTSce72250-

#define OPCODE_EVT_TELEPHONICBOX_EVENT     162
#define OPCODE_EVT_ACTLISTBOX_TIMEOUT      163
#define OPCODE_EVT_ACTLISTBOX_DISMISSED    164

//
// mipt
//
#define OPCODE_EVT_ADTTS_RESPONSE          165
#define OPCODE_EVT_AP_MAC                  166


#endif /* _EVENT_CODE_H_ */
