//
// props_defs.h (genprops_defs.c)
//
// expat version: expat_2.0.1
// specs version: R3.0
// specs date   : 2004/12/14
//
//
#ifndef _PROPS_DEFS_H_
#define _PROPS_DEFS_H_

#include "props_code.h"

#define C_context_P_count                        2
#define C_terminal_P_count                      25
#define C_keyboard_P_count                       8
#define C_audioconfig_P_count                    7
#define C_leds_P_count                           5
#define C_screen_P_count                        18
#define C_date_P_count                           9
#define C_AOMV_P_count                           9
#define C_callstate_P_count                      6
#define C_security_P_count                       8
#define C_bluetooth_P_count                      6
#define C_locappl_P_count                        3
#define C_framebox_P_count                      14
#define C_tabbox_P_count                        16
#define C_headerbox_P_count                     12
#define C_listbox_P_count                       28
#define C_actionlistbox_P_count                 18
#define C_textbox_P_count                       18
#define C_actionbox_P_count                     14
#define C_inputbox_P_count                      30
#define C_checkbox_P_count                      16
#define C_datebox_P_count                       13
#define C_timerbox_P_count                      20
#define C_idletimer_P_count                      2
#define C_popupbox_P_count                      13
#define C_dialogbox_P_count                     22
#define C_sliderbar_P_count                     19
#define C_progressbar_P_count                   16
#define C_imagebox_P_count                      14
#define C_iconbox_P_count                       10
#define C_AOMVbox_P_count                       12
#define C_telephonicbox_P_count                 12
#define C_telephonicboxitem_P_count              6
#define C_keyboard_context_P_count              13
#define C_AOMEL_P_count                         12
#define C_AOM10_P_count                         10
#define C_AOM40_P_count                         10
#define C_bluetooth_device_P_count               9
#define C_ime_context_P_count                   10

typedef enum
{
    P_B_objectid                      = OPCODE_P_B_objectid,
    P_B_ownership                     = OPCODE_P_B_ownership,
    P_B_reset_mode                    = OPCODE_P_B_reset_mode,
    P_B_mtu                           = OPCODE_P_B_mtu,
    P_B_negative_ack                  = OPCODE_P_B_negative_ack,
    P_B_CS_idle_state                 = OPCODE_P_B_CS_idle_state,
    P_B_PS_idle_state                 = OPCODE_P_B_PS_idle_state,
    P_B_session_timeout               = OPCODE_P_B_session_timeout,
    P_B_link_type                     = OPCODE_P_B_link_type,
    P_B_term_type                     = OPCODE_P_B_term_type,
    P_B_serialnum                     = OPCODE_P_B_serialnum,
    P_B_hardversion                   = OPCODE_P_B_hardversion,
    P_B_softversion                   = OPCODE_P_B_softversion,
    P_B_rom_size                      = OPCODE_P_B_rom_size,
    P_B_ram_size                      = OPCODE_P_B_ram_size,
    P_B_reset_cause                   = OPCODE_P_B_reset_cause,
    P_B_fetch_timeout                 = OPCODE_P_B_fetch_timeout,
    P_B_use_customisation             = OPCODE_P_B_use_customisation,
    P_B_custversion                   = OPCODE_P_B_custversion,
    P_B_L10Nversion                   = OPCODE_P_B_L10Nversion,
    P_B_ringings_count                = OPCODE_P_B_ringings_count,
    P_B_ime_lock                      = OPCODE_P_B_ime_lock,
    P_B_binary_suffix                 = OPCODE_P_B_binary_suffix,
    P_B_binary_count                  = OPCODE_P_B_binary_count,
    P_B_SIPCversion                   = OPCODE_P_B_SIPCversion,
    P_B_system_id                     = OPCODE_P_B_system_id,
    P_B_type                          = OPCODE_P_B_type,
    P_B_help_timeout                  = OPCODE_P_B_help_timeout,
    P_B_longpress                     = OPCODE_P_B_longpress,
    P_B_shortpress                    = OPCODE_P_B_shortpress,
    P_B_autorepeat                    = OPCODE_P_B_autorepeat,
    P_B_repetition                    = OPCODE_P_B_repetition,
    P_B_count                         = OPCODE_P_B_count,
    P_B_enable                        = OPCODE_P_B_enable,
    P_B_qos_ticket                    = OPCODE_P_B_qos_ticket,
    P_B_onoff                         = OPCODE_P_B_onoff,
    P_B_anchorid                      = OPCODE_P_B_anchorid,
    P_B_grid                          = OPCODE_P_B_grid,
    P_B_x                             = OPCODE_P_B_x,
    P_B_y                             = OPCODE_P_B_y,
    P_B_w                             = OPCODE_P_B_w,
    P_B_h                             = OPCODE_P_B_h,
    P_B_visible                       = OPCODE_P_B_visible,
    P_B_cycling_time                  = OPCODE_P_B_cycling_time,
    P_B_bpp                           = OPCODE_P_B_bpp,
    P_B_contrast                      = OPCODE_P_B_contrast,
    P_B_clearscreen                   = OPCODE_P_B_clearscreen,
    P_B_backlight_timeout             = OPCODE_P_B_backlight_timeout,
    P_B_screensaver_timeout           = OPCODE_P_B_screensaver_timeout,
    P_B_widgets_size                  = OPCODE_P_B_widgets_size,
    P_B_year                          = OPCODE_P_B_year,
    P_B_month                         = OPCODE_P_B_month,
    P_B_day                           = OPCODE_P_B_day,
    P_B_m                             = OPCODE_P_B_m,
    P_B_s                             = OPCODE_P_B_s,
    P_B_all_icons_off                 = OPCODE_P_B_all_icons_off,
    P_B_method                        = OPCODE_P_B_method,
    P_B_login                         = OPCODE_P_B_login,
    P_B_address                       = OPCODE_P_B_address,
    P_B_name                          = OPCODE_P_B_name,
    P_B_state                         = OPCODE_P_B_state,
    P_B_bth_ringing                   = OPCODE_P_B_bth_ringing,
    P_B_bonded_devices                = OPCODE_P_B_bonded_devices,
    P_B_disable                       = OPCODE_P_B_disable,
    P_B_frame_type                    = OPCODE_P_B_frame_type,
    P_B_border                        = OPCODE_P_B_border,
    P_B_vsplit                        = OPCODE_P_B_vsplit,
    P_B_autospread                    = OPCODE_P_B_autospread,
    P_B_cycling                       = OPCODE_P_B_cycling,
    P_B_fontid                        = OPCODE_P_B_fontid,
    P_B_active                        = OPCODE_P_B_active,
    P_B_advanced_mode                 = OPCODE_P_B_advanced_mode,
    P_B_icon                          = OPCODE_P_B_icon,
    P_B_label                         = OPCODE_P_B_label,
    P_B_halign                        = OPCODE_P_B_halign,
    P_B_valign                        = OPCODE_P_B_valign,
    P_B_mode                          = OPCODE_P_B_mode,
    P_B_showevent                     = OPCODE_P_B_showevent,
    P_B_showactive                    = OPCODE_P_B_showactive,
    P_B_circular                      = OPCODE_P_B_circular,
    P_B_realcount                     = OPCODE_P_B_realcount,
    P_B_start                         = OPCODE_P_B_start,
    P_B_list_type                     = OPCODE_P_B_list_type,
    P_B_disablelongpress              = OPCODE_P_B_disablelongpress,
    P_B_timeout                       = OPCODE_P_B_timeout,
    P_B_append                        = OPCODE_P_B_append,
    P_B_cursor                        = OPCODE_P_B_cursor,
    P_B_overwrite                     = OPCODE_P_B_overwrite,
    P_B_value                         = OPCODE_P_B_value,
    P_B_password                      = OPCODE_P_B_password,
    P_B_size                          = OPCODE_P_B_size,
    P_B_mask                          = OPCODE_P_B_mask,
    P_B_focus                         = OPCODE_P_B_focus,
    P_B_inputborder                   = OPCODE_P_B_inputborder,
    P_B_mask_subst                    = OPCODE_P_B_mask_subst,
    P_B_focused_cursor_index          = OPCODE_P_B_focused_cursor_index,
    P_B_format                        = OPCODE_P_B_format,
    P_B_incdec                        = OPCODE_P_B_incdec,
    P_B_value_notify                  = OPCODE_P_B_value_notify,
    P_B_modal                         = OPCODE_P_B_modal,
    P_B_min                           = OPCODE_P_B_min,
    P_B_max                           = OPCODE_P_B_max,
    P_B_data                          = OPCODE_P_B_data,
    P_B_URI                           = OPCODE_P_B_URI,
    P_B_page_active                   = OPCODE_P_B_page_active,
    P_B_accesskey                     = OPCODE_P_B_accesskey,
    P_B_eventmode                     = OPCODE_P_B_eventmode,
    P_B_numpad_ownership              = OPCODE_P_B_numpad_ownership,
    P_B_navigator_ownership           = OPCODE_P_B_navigator_ownership,
    P_B_telephony_ownership           = OPCODE_P_B_telephony_ownership,
    P_B_progkeys_ownership            = OPCODE_P_B_progkeys_ownership,
    P_B_softkeys_ownership            = OPCODE_P_B_softkeys_ownership,
    P_B_alphakeys_ownership           = OPCODE_P_B_alphakeys_ownership,
    P_B_numpad_eventmode              = OPCODE_P_B_numpad_eventmode,
    P_B_all_labels_off                = OPCODE_P_B_all_labels_off,
    P_B_cod                           = OPCODE_P_B_cod,
    P_B_bonded                        = OPCODE_P_B_bonded,
    P_B_pin                           = OPCODE_P_B_pin,
    P_A_delay_max_handset             = OPCODE_P_A_delay_max_handset,
    P_A_delay_max_handsfree           = OPCODE_P_A_delay_max_handsfree,
    P_A_delay_tx                      = OPCODE_P_A_delay_tx,
    P_A_delay_rx                      = OPCODE_P_A_delay_rx,
    P_A_mode                          = OPCODE_P_A_mode,
    P_A_color                         = OPCODE_P_A_color,
    P_A_code                          = OPCODE_P_A_code,
    P_A_data                          = OPCODE_P_A_data,
    P_A_today                         = OPCODE_P_A_today,
    P_A_tomorrow                      = OPCODE_P_A_tomorrow,
    P_A_type                          = OPCODE_P_A_type,
    P_A_icon                          = OPCODE_P_A_icon,
    P_A_label                         = OPCODE_P_A_label,
    P_A_value                         = OPCODE_P_A_value,
    P_A_ownership                     = OPCODE_P_A_ownership,
    P_A_enable                        = OPCODE_P_A_enable,
    P_A_state                         = OPCODE_P_A_state,
    P_A_name                          = OPCODE_P_A_name,
    P_A_number                        = OPCODE_P_A_number,
    P_A_pem_data                      = OPCODE_P_A_pem_data,
    P_A_serial_number                 = OPCODE_P_A_serial_number,
    P_A_owner_name                    = OPCODE_P_A_owner_name,
    P_A_issuer_name                   = OPCODE_P_A_issuer_name,
    P_A_end_date                      = OPCODE_P_A_end_date,
    P_A_keychar                       = OPCODE_P_A_keychar,
    P_A_hebrew_IME_flag               = OPCODE_P_A_hebrew_IME_flag,
    P_A_R2L_flag                      = OPCODE_P_A_R2L_flag,
    P_A_action_icon                   = OPCODE_P_A_action_icon,
    P_A_action_label                  = OPCODE_P_A_action_label,
    P_A_action_value                  = OPCODE_P_A_action_value,
    P_A_key_ownership                 = OPCODE_P_A_key_ownership,
    P_A_key_eventmode                 = OPCODE_P_A_key_eventmode
} P_defs_t;


#define P_BASIC         0
#define P_ARRAY         128
#define P_INVALID       255
#define P_INVALID_INDEX 255


#define P_MAX_COUNT     256
#define P_CUR_COUNT     150


#define BASIC_COUNT     118
#define ARRAY_COUNT     32


#if (BASIC_COUNT >= P_ARRAY)
#  error "protocol error (BASIC_COUNT >= P_ARRAY)"
#endif

#if (P_CUR_COUNT > P_MAX_COUNT)
#  error "protocol error (P_CUR_COUNT > P_MAX_COUNT)"
#endif

#endif /* _PROPS_DEFS_H_ */
