/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/23 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#ifndef _CLASS_DEFS_H_
#define _CLASS_DEFS_H_

#include "class_code.h"

typedef enum
{
	C_context                     = OPCODE_C_context,
	C_terminal                    = OPCODE_C_terminal,
	C_keyboard                    = OPCODE_C_keyboard,
	C_audioconfig                 = OPCODE_C_audioconfig,
	C_leds                        = OPCODE_C_leds,
	C_screen                      = OPCODE_C_screen,
	C_date                        = OPCODE_C_date,
	C_AOMV                        = OPCODE_C_AOMV,
	C_callstate                   = OPCODE_C_callstate,
	C_security                    = OPCODE_C_security,
	C_bluetooth                   = OPCODE_C_bluetooth,
	C_locappl                     = OPCODE_C_locappl,
	C_framebox                    = OPCODE_C_framebox,
	C_tabbox                      = OPCODE_C_tabbox,
	C_headerbox                   = OPCODE_C_headerbox,
	C_listbox                     = OPCODE_C_listbox,
	C_actionlistbox               = OPCODE_C_actionlistbox,
	C_textbox                     = OPCODE_C_textbox,
	C_actionbox                   = OPCODE_C_actionbox,
	C_inputbox                    = OPCODE_C_inputbox,
	C_checkbox                    = OPCODE_C_checkbox,
	C_datebox                     = OPCODE_C_datebox,
	C_timerbox                    = OPCODE_C_timerbox,
	C_idletimer                   = OPCODE_C_idletimer,
	C_popupbox                    = OPCODE_C_popupbox,
	C_dialogbox                   = OPCODE_C_dialogbox,
	C_sliderbar                   = OPCODE_C_sliderbar,
	C_progressbar                 = OPCODE_C_progressbar,
	C_imagebox                    = OPCODE_C_imagebox,
	C_iconbox                     = OPCODE_C_iconbox,
	C_AOMVbox                     = OPCODE_C_AOMVbox,
	C_telephonicbox               = OPCODE_C_telephonicbox,
	C_telephonicboxitem           = OPCODE_C_telephonicboxitem,
	C_keyboard_context            = OPCODE_C_keyboard_context,
	C_AOMEL                       = OPCODE_C_AOMEL,
	C_AOM10                       = OPCODE_C_AOM10,
	C_AOM40                       = OPCODE_C_AOM40,
	C_bluetooth_device            = OPCODE_C_bluetooth_device,
	C_ime_context                 = OPCODE_C_ime_context
} C_defs_t;


#define C_STATIC    0
#define C_DYNAMIC   128
#define C_INVALID   255


#define C_MAX_COUNT 256
#define C_CUR_COUNT 39


#if (C_CUR_COUNT > C_MAX_COUNT)
#  error "protocol error (C_CUR_COUNT > C_MAX_COUNT)"
#endif

#endif /* _CLASS_DEFS_H_ */
