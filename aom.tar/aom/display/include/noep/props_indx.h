/*-----------------------------------------------------------------------------
 
   COMPONENT:      NOE
 
   MODULE:         props_indx.h
 
   DATED:          2003/05/27
 
   AUTHOR:         N. Bertin
 
   DESCRIPTION:    property indexes

   SccsId=         @(#)props_indx.h	1.1  03/05/27

   HISTORY: 

      - creation   2003/05/27

-----------------------------------------------------------------------------*/
#ifndef _PROPS_INDX_H_
#define _PROPS_INDX_H_


/*-----------------------------------------------------------------------------
  initialize property opcode/index table
  ---------------------------------------------------------------------------*/
extern void init_P_indx(void);


/*-----------------------------------------------------------------------------
  property opcode -> property index
  ---------------------------------------------------------------------------*/
extern uint8_t P_get_indx(uint8_t P);


#endif /* _PROPS_INDX_H_ */
