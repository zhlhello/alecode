//
// enum_defs.h (genenums_defs.c)
//
// expat version: expat_2.0.1
// specs version: R3.0
// specs date   : 2004/12/14
//
//
#ifndef _ENUM_DEFS_H_
#define _ENUM_DEFS_H_


typedef enum
{
	CTX_CONTEXT,
	CTX_CS,
	CTX_PS,
	MAX_ENUM_ownership
} enum_ownership_t;


typedef enum
{
	RESET_MODE_UPDATE_NONE,
	MAX_ENUM_reset_mode
} enum_reset_mode_t;


typedef enum
{
	UA_LINK,
	IP_LINK,
	MAX_ENUM_LINK_TYPE
} enum_LINK_TYPE_t;


typedef enum
{
	OXE,
	OXO,
	MAX_ENUM_system_id
} enum_system_id_t;


typedef enum
{
	KEYBOARD_TYPE_AZERTY,
	KEYBOARD_TYPE_QWERTY,
	KEYBOARD_TYPE_QWERTZ,
	KEYBOARD_TYPE_NORDIC,
	MAX_ENUM_keyboard_type
} enum_keyboard_type_t;


typedef enum
{
	LED_MODE_OFF,
	LED_MODE_ON,
	LED_MODE_FASTBLINK,
	LED_MODE_SLOWBLINK,
	MAX_ENUM_led_mode
} enum_led_mode_t;


typedef enum
{
	LED_COLOR_GREEN,
	LED_COLOR_YELLOW,
	LED_COLOR_ORANGE,
	MAX_ENUM_led_color
} enum_led_color_t;


typedef enum
{
	GRID_TYPE1,
	GRID_TYPE2,
	MAX_ENUM_grid_type
} enum_grid_type_t;


typedef enum
{
	SCREEN_PIXEL,
	SCREEN_CHARACTER,
	MAX_ENUM_screen_mode
} enum_screen_mode_t;


typedef enum
{
	SCREEN_BPP1,
	SCREEN_BPP2,
	SCREEN_BPP12,
	SCREEN_BPP32,
	MAX_ENUM_screen_bpp
} enum_screen_bpp_t;


typedef enum
{
	SMALL_WIDGET,
	LARGE_WIDGET,
	MAX_ENUM_widgets_size
} enum_widgets_size_t;


typedef enum
{
	CALLSTATE_IDLE,
	CALLSTATE_ACTIVE,
	MAX_ENUM_callstate
} enum_callstate_t;


typedef enum
{
	SECURITY_METHOD_TLS,
	SECURITY_METHOD_MD5,
	SECURITY_METHOD_BOTH,
	SECURITY_METHOD_NONE,
	MAX_ENUM_security_method
} enum_security_method_t;


typedef enum
{
	BT_STATE_NORMAL,
	BT_STATE_INQUIRY,
	BT_STATE_PAIRING,
	BT_STATE_REMOVING,
	MAX_ENUM_bt_state
} enum_bt_state_t;


typedef enum
{
	F_STANDARD,
	F_ENLARGED,
	F_REDUCED,
	F_ENLARGED_APPLI,
	MAX_ENUM_nframe_type
} enum_nframe_type_t;


typedef enum
{
	FONT_REGULAR,
	FONT_BOLD,
	FONT_EXTRABOLD,
	FONT_DOWNLOAD1,
	FONT_DOWNLOAD2,
	FONT_DOWNLOAD3,
	MAX_ENUM_fontid
} enum_fontid_t;


typedef enum
{
	STANDARD,
	ADVANCED,
	MAX_ENUM_advanced_mode
} enum_advanced_mode_t;


typedef enum
{
	H_LEFT,
	H_CENTER,
	H_RIGHT,
	MAX_ENUM_halign
} enum_halign_t;


typedef enum
{
	V_UP,
	V_CENTER,
	V_DOWN,
	MAX_ENUM_valign
} enum_valign_t;


typedef enum
{
	COLUMN_1,
	COLUMN_2,
	MAX_ENUM_ncolumns
} enum_ncolumns_t;


typedef enum
{
	L_STANDARD,
	L_REDUCED,
	MAX_ENUM_nlist_type
} enum_nlist_type_t;


typedef enum
{
	TEXTSCROLL_DISABLED,
	TEXTSCROOL_LEFT2RIGHT,
	TEXTSCROLL_RIGHT2LEFT,
	TEXTSCROLL_BOUNCE,
	TEXTSCROLL_VERTICAL,
	MAX_ENUM_textscrolling
} enum_textscrolling_t;


typedef enum
{
	TIMER_START,
	TIMER_STOP,
	MAX_ENUM_timer_state
} enum_timer_state_t;


typedef enum
{
	TIMER_INCR,
	TIMER_DECR,
	MAX_ENUM_timer_incdec
} enum_timer_incdec_t;


typedef enum
{
	TIMER_AUTORELOAD,
	TIMER_ONESHOT,
	MAX_ENUM_timer_mode
} enum_timer_mode_t;


typedef enum
{
	MODE_DONT_CLOSE,
	MODE_CLOSE,
	MODE_DELETE,
	MAX_ENUM_close_mode
} enum_close_mode_t;


typedef enum
{
	IMAGE_FORMAT_PNG,
	IMAGE_FORMAT_JPEG,
	IMAGE_FORMAT_NGG,
	MAX_ENUM_image_format
} enum_image_format_t;


typedef enum
{
	ACCESSKEY_LEFT,
	ACCESSKEY_RIGHT,
	ACCESSKEY_UNSPECIFIED,
	MAX_ENUM_accesskey
} enum_accesskey_t;


typedef enum
{
	EVT_MODE1,
	EVT_MODE2,
	EVT_MODE3,
	MAX_ENUM_keyboard_eventmode
} enum_keyboard_eventmode_t;


typedef enum
{
	BTH_TYPE_HANDSET,
	BTH_TYPE_HEADSET,
	BTH_TYPE_HANDSFREE,
	BTH_TYPE_LOUDSPEAKER,
	BTH_TYPE_SMARTPHONE,
	BTH_TYPE_BLE,
	BTH_TYPE_OTHER,
	MAX_ENUM_bth_type
} enum_bth_type_t;


typedef enum
{
	PROT_IME_TYPE_LATIN,
	PROT_IME_TYPE_CYRILLIC,
	PROT_IME_TYPE_PINYIN,
	PROT_IME_TYPE_JAMO,
	PROT_IME_TYPE_STROKE,
	PROT_IME_TYPE_ZHUYIN,
	PROT_IME_TYPE_ROMAJI,
	PROT_IME_TYPE_HEBREW,
	MAX_ENUM_ime_type
} enum_ime_type_t;


typedef enum
{
	RJ9_PLUG,
	BT_HANDSET_LINK,
	BT_HEADSET_LINK,
	JACK_PLUG,
	MAX_ENUM_device_link
} enum_device_link_t;


typedef enum
{
	BATTERY_LOW,
	BATTERY_MEDIUM,
	BATTERY_HIGH,
	MAX_ENUM_battery_level
} enum_battery_level_t;


typedef enum
{
	PROG_KEY1,
	MAX_ENUM_prog_key
} enum_prog_key_t;


typedef enum
{
	BTH_BONDING_SUCCESS,
	BTH_BAD_PIN,
	BTH_BONDING_REFUSED,
	MAX_ENUM_bonding_reason
} enum_bonding_reason_t;


#endif /* _ENUMS_DEFS_H_ */
