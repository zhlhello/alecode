/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/11/29 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#ifndef _SCREENSAVER_H_
#define _SCREENSAVER_H_


#ifdef __cplusplus
extern "C" {
#endif

/*-----------------------------------------------------------------------------
  retourne TRUE si le screensaver est actif
  ---------------------------------------------------------------------------*/
extern bool_t screensaver_is_active(void);


/*-----------------------------------------------------------------------------
  activation du screensaver
  ---------------------------------------------------------------------------*/
extern void screensaver_enter(void);


/*-----------------------------------------------------------------------------
  desactivation du screensaver
  ---------------------------------------------------------------------------*/
extern void screensaver_leave(void);

// XTSce87476+
/*-----------------------------------------------------------------------------
  destruction des frameboxes background et moving
  ---------------------------------------------------------------------------*/
extern void screensaver_destroy_fbox(void);
// XTSce87476-

#ifdef __cplusplus
}
#endif

#endif
