/*!------------------------------------------------------------------\n
    Copyright 1997-2012 Alcatel-Lucent. All Rights Reserved          \n
  ------------------------------------------------------------------ \n
    Module :        noemmi                                           \n
    Project :       ICTouch                                          \n
  ------------------------------------------------------------------ \n
  \file     stdinc.h
  \ingroup  OSWrapper
  \date     06/04/2012
  \author   Gary YU
  \brief    standard data type header file
  \feature  crms00xxxxxx
  \version  1.0

   History :                                                         \n
   create  : 06/04/2012                                              \n
 */

#ifndef _STDINC_H_
#define _STDINC_H_

#include "mem_wrapper.h"


//TODO: Change It as the Build Automatical Operation to Tag Version Number
#define _NOE_IN_VHE_MODULE_VERSION_	\
	"1.07.1"


/*! Creates a type name for uint8_t     */ 
typedef unsigned char   uint8_t;

/*! Creates a type name for uint16_t    */ 
typedef unsigned short  uint16_t;

/*! Creates a type name for uint32_t    */ 
typedef unsigned int    uint32_t;

/*! Creates a type name for int32_t    */ 
typedef int         	int32_t;

/*! Creates a type name for int8_t    */ 
typedef signed char     int8_t;

/*! Creates a type name for int16_t    */ 
typedef short  int16_t;

/*! Creates a type name for bool_t      */ 
typedef uint8_t         bool_t;

#ifndef NULL
#  define NULL  0L
#endif

/*!
 * \def FALSE
 *      Define FALSE as 0
 */
#ifndef FALSE
#define FALSE   0
#endif

/*!
 * \def TRUE
 *      Define TRUE as 1
 */
#ifndef TRUE
#define TRUE    1
#endif


/*!
 * \def ON
 *      Define ON as 1
 */
#ifndef ON
#  define ON    TRUE
#endif

/*!
 * \def OFF
 *      Define OFF as 0
 */
#ifndef OFF
#  define OFF   FALSE
#endif

#ifndef ICT_HOST
    typedef unsigned int     size_t;
#endif

#endif /* _STDINC_H_ */
