/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/09/26 jerryzh
    Take from NOE for AoM project.

  -----------------------------------------------------------------------------*/
#ifndef _I_SKINS_H_
#define _I_SKINS_H_

extern NGGimage *ngwAlcSkin_sbar_big     [];
extern NGGimage *ngwAlcSkin_sbar_small   [];
extern NGGimage *ngwAlcSkin_pbar         [];
extern NGGimage *ngwAlcSkin_slider       [];
extern NGGimage *ngwAlcSkin_cardct       [];
extern NGGimage *ngwAlcSkin_tnoe         [];
extern NGGimage *ngwAlcSkin_hdbox        [];
extern NGGimage *ngwAlcSkin_input        [];

extern NGGimage *ngwAlcSkin_pinb_border0 [];
extern NGGimage *ngwAlcSkin_pinb_border1 [];

extern NGGimage *ngwAlcSkin_pinb_border2 [];

extern NGGimage *ngwAlcSkin_pinb_border4 [];
extern NGGimage *ngwAlcSkin_pinb_border5 [];

extern NGGimage *ngwAlcSkin_pinb_border8 [];

// XTSce72250+
#if defined(FEATURE_IME)
extern NGGimage *ngwAlcSkin_ime          [];
#endif /* FEATURE_IME */
// XTSce72250-
extern NGGimage *ngwAlcSkin_appbutton    [];

/*-----------------------------------------------------------------------------
  skins init/load/unload
  ---------------------------------------------------------------------------*/
extern void skins_init  (void);
extern void skins_load  (void);
extern void skins_unload(void);

/*-----------------------------------------------------------------------------
  images defs + getter
  ---------------------------------------------------------------------------*/
typedef enum
{
    IMG_HOMEBAR_BACKGROUND,
    IMG_TABS_BACKGROUND,
    IMG_FRAMEBOX_BACKGROUND,
    IMG_SCREEN_BACKGROUND,
    IMG_SCREENSAVER_BACKGROUND,
    IMG_TNOE_POPUP,
#if defined(FEATURE_SMARTADDON)
    IMG_SMARTADDON_BACKGROUND,
#endif
    IMG_INVALID_ID
} skin_image_id_t;

extern NGGimage *skins_get_image(skin_image_id_t id);

/*-----------------------------------------------------------------------------
skins reload event (check w_screen.c)
  ---------------------------------------------------------------------------*/
typedef void (*skins_on_reload_cb_t)(void);
extern void skins_on_reload_set_callback(skins_on_reload_cb_t cb);

#endif /* _I_SKINS_H_ */
