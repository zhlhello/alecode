#include "hidmsg.h"
#include "log.h"
#include "os_wrapper.h"

/***********************************************************
 param:
    key_ind:   the key index
    icon_id:    icon id
    led_stat:  led status, on/off/blink/fast/blink
    label: content/size of the label, it should be allocated memory at heap, label content(size) can be NULL(0) if no label display. 
*/
key_disp_infor_t* init_key_disp_info(keyInd_t key_index, iconInd_t icon_id, ledSt_t led_stat, label_t* label)
{
    key_disp_infor_t* disp_item = NULL;
    
    disp_item = (key_disp_infor_t* ) pw_malloc(sizeof(key_disp_infor_t));

    if (disp_item != NULL)
    {
        disp_item->key_index = key_index;
        disp_item->icon_id = icon_id;
        disp_item->led_stat = led_stat;

        //struct copy,  label.content share the same memory
        if (label != NULL)
            disp_item->label = *label;
        else
        {
            disp_item->label.content = NULL;
            disp_item->label.size = 0;
        }
        disp_item->next = NULL;
    }

    return disp_item;
}

bool_t destroy_key_disp_info(key_disp_infor_t** disp_item)
{
    if ((disp_item == NULL) || (*disp_item == NULL))
        return FALSE;
    
    if ((*disp_item)->label.content != NULL)
        pw_free((*disp_item)->label.content);

    pw_free(*disp_item);

    return TRUE;
}

bool_t destroy_key_disp_list_info(key_disp_infor_t** disp_header)
{
    if ((disp_header == NULL) || (*disp_header == NULL))
        return FALSE;

    key_disp_infor_t *header, *next;
    
    header = *disp_header;
    while (header != NULL)
    {
        next = header->next;
        destroy_key_disp_info(&header);

        header = next;
    }
    *disp_header = NULL;
}

bool_t insert_key_disp_info(key_disp_infor_t** disp_header, key_disp_infor_t* disp_item)
{
    if ((disp_header == NULL) || (disp_item == NULL))
        return FALSE;

    LOGD("disp_header = 0x%x, *disp_header = 0x%x, disp_item = 0x%x", disp_header, *disp_header, disp_item);
    if (*disp_header == NULL)
    {
        *disp_header = disp_item;
        return TRUE;
    }
    
    key_disp_infor_t* head = *disp_header;
    key_disp_infor_t* curr = head;
    key_disp_infor_t* next = NULL;
    key_disp_infor_t* temp = NULL;    

    if (disp_item->key_index < head->key_index)
    {
        head = disp_item;
        head->next = curr;

        *disp_header = head;

        return TRUE;
    }
    else if (disp_item->key_index == head->key_index)
    {
        //same key index, head item will be replaced by disp_item.
        LOGD("same key index, update PK%d infor\n", disp_item->key_index);
        
        disp_item->next = head->next;
        *disp_header = disp_item;

        destroy_key_disp_info(&head);
        return TRUE;
    }
    
    while ((curr->key_index < disp_item->key_index) && (curr->next != NULL))
    {
        next = curr->next;
        temp = curr;
        curr = next;
    }
    
    if (curr->key_index < disp_item->key_index)//insert at end
    {
        curr->next = disp_item;
        disp_item->next = NULL;  
    }
    else if (curr->key_index == disp_item->key_index)
    {
        //same key index, curr item will be replaced by disp_item.
        LOGD("same key index, update PK%d infor\n", disp_item->key_index);
        
        temp->next = disp_item;
        disp_item->next = curr->next;

        pw_free(curr);
        return TRUE;
    }
    else//insert at middle
    {
        temp->next = disp_item;
        disp_item->next = curr;
    }

   
    return TRUE;
}

key_disp_infor_t* get_key_disp_info_by_index(key_disp_infor_t** disp_header, uint8_t key_index)
{
    if ((disp_header == NULL) || (*disp_header == NULL))
        return NULL;

    key_disp_infor_t* head = *disp_header;
    key_disp_infor_t* curr = head;
    key_disp_infor_t* next = NULL;

    if (head->key_index == key_index)
    {
        return head;
    }

    next = curr->next;
    while ((next != NULL) && (next->key_index != key_index))
    {
        curr = next;
        next = curr->next;
    }

    if (next != NULL)//found, return the item
    {
        return next;
    }

    return NULL;
}

void print_key_disp_info(key_disp_infor_t* disp_header)
{
    key_disp_infor_t *curr, *next;

    curr = disp_header;

    while(curr != NULL)
    {
        LOGD("index = %d, icon_id = %d, led_stat = %d, label = %s, label_size = %d, next = 0x%x\n", 
            curr->key_index, curr->icon_id, curr->led_stat, curr->label.content? curr->label.content : "null", curr->label.size, curr->next);
        
        next = curr->next;
        curr = next;
    }
}

char *hidmsg2str(hidmsg_t msg)
{
    switch (msg)
    {
        //msg from slave to master
        case HID_MSG_SLAVE:                     return "HID_MSG_SLAVE";
        case HID_MSG_KEY:                         return "HID_MSG_KEY";
        case HID_MSG_INFO_VER:                return "HID_MSG_INFO_VER";
        case HID_MSG_INFO_PCMS:              return "HID_MSG_INFO_PCMS";
        case HID_MSG_INFO_SN:                  return "HID_MSG_INFO_SN";
        case HID_MSG_INFO_ICONS_MD5:    return "HID_MSG_INFO_ICONS_MD5";

        //msg from master to slave
        case HID_MSG_MASTER:              return "HID_MSG_MASTER";
        case HID_MSG_RESET:                return "HID_MSG_RESET";
        case HID_MSG_SCREENINFO:       return "HID_MSG_SCREENINFO";
        case HID_MSG_SCREENINFO_DONE:       return "HID_MSG_SCREENINFO_DONE";
        case HID_MSG_KEYINFO:             return "HID_MSG_KEYINFO"; 
        case HID_MSG_PAGEICON:          return "HID_MSG_PAGEICON";
        case HID_MSG_UPG:                    return "HID_MSG_UPG";
        case HID_MSG_CMD:                   return "HID_MSG_CMD";
        case HID_MSG_SCREENSAVER:    return "HID_MSG_SCREENSAVER";
        case HID_MSG_LOGLEVEL:           return "HID_MSG_LOGLEVEL";
        case HID_MSG_BACKLIGHT_LEVEL: return "HID_MSG_BACKLIGHT_LEVEL";
        case HID_MSG_SKIN_RELOAD:        return "HID_MSG_SKIN_RELOAD";
        case HID_MSG_INFO_REQUEST:      return "HID_MSG_INFO_REQUEST";
        case HID_MSG_MAX:
        default:
            return "HID_MSG_UNKOWN";
    }
    return "HID_MSG_UNKOWN";
}
