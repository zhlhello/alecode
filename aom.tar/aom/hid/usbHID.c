/*-----------------------------------------------------------------------------

  HISTORY:

  - 2019/07/12 jerryzh
    Creation for AOM project.

  -----------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <linux/input.h>
#include <fcntl.h>

#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <limits.h>

#include "log.h"
#include "common.h"
#include "os_wrapper.h"
#include "usbHID.h"
#include "hidmsg.h"
#include "keydrv.h"
#include "leddrv.h"

static int hid_fd = -1;
const char* hid_dev_name = "/dev/hidg0";

#define HID_MAX_PACKET_SIZE 64
#define HID_BUFFER_SIZE          64

typedef struct 
{
    char null_array[HID_MAX_PACKET_SIZE];
}buffer_offset_size_t;

static uint8_t hid_rcv_msg[HID_BUFFER_SIZE+1];
static uint8_t hid_snd_msg[HID_BUFFER_SIZE];

extern char A_version[33];
extern char A_pcms[33];
extern char A_sn[33];
extern char A_icons_md5[33];

extern void misc_task_entry (void *data);

static uint32_t hid_msg_prepare(uint8_t msg[], int size, const hid_msg_header *p_header, const uint8_t *p_body)
{
    uint16_t msg_len;
    uint8_t * p = NULL;
    
    if ( (p_header == NULL) || (p_body == NULL) )
    {
        LOGE("msg is NULL");
        return -1;
    }
    
    msg_len = sizeof(hid_msg_header) + p_header->body_len;

    if (msg_len > size)
    {
        LOGE("msg_len = %d, buffer_size = %d", msg_len, size);
        return -1;
    }
    
    memset(msg, 0, size);
    p = msg;
    memcpy(p, p_header, sizeof(hid_msg_header));

    p += sizeof(hid_msg_header);
    memcpy(p, p_body, p_header->body_len);

    return msg_len;
}

/***********************************************************
screen msg format:
        {msg header} + {msg body}
    screen header msg format: 
        hidmsg_t msg_type;
        uint16_t body_len;

    screen body msg format:
          2Byte      2Byte       1Byte          1Byte
       { [KEY + SecLen + <SubLength + OpCode + state> + <SubLength + OpCode + state> + <SubLength + OpCode + state>] + [...] + [...] + ... }

        SubOpcode:
                        1Byte          1Byte          2Byte
            icon: SubLength + OP_ICON_SET + ind

                        1Byte          1Byte          1Byte
            led: SubLength + OP_LED_SET +  state

                        1Byte          1Byte          xByte
            label: SubLength + OP_LABEL_SET + string
************************************************************/
static key_disp_infor_t * handle_msg_homepage(const uint8_t msg[], int totalLengh)
{
    uint8_t *p = msg;
    int len = totalLengh;
    key_disp_infor_t *key_header = NULL;
    key_disp_infor_t* disp_item = NULL;
          
    while (len >0)
    {
        uint16_t sec_len = 0;
        keyInd_t key_index = 0xffff;
        iconInd_t icon_id = ICON_NO;
        ledSt_t led_stat = LED_NOP;
        label_t label = {NULL, 0};
        
        if (len > (SEC_LENGHT_SIZE + KEY_IND_SIZE))
        {
            memcpy(&key_index, p, KEY_IND_SIZE);
            p += KEY_IND_SIZE;
            len -= KEY_IND_SIZE;
            
            memcpy(&sec_len, p, SEC_LENGHT_SIZE);
            p += SEC_LENGHT_SIZE;
            len -= SEC_LENGHT_SIZE;
                
            while (sec_len > (SUB_LENGHT_SIZE + SUB_OPCODE_SIZE))
            {
                uint8_t sub_len;
                uint8_t sub_OpCode;
                
                memcpy(&sub_len, p, SUB_LENGHT_SIZE);
                p += SUB_LENGHT_SIZE;
                len -= SUB_LENGHT_SIZE;
                sec_len -= SUB_LENGHT_SIZE;
                
                // get op state or value
                if (sub_len >0)
                {
                    memcpy(&sub_OpCode, p, SUB_OPCODE_SIZE);
                    p += SUB_OPCODE_SIZE;
                    len -= SUB_OPCODE_SIZE;
                    sec_len -= SUB_OPCODE_SIZE;
                    sub_len -= SUB_OPCODE_SIZE;//sub_len is not contain sub opcode length now!
                    
                    switch (sub_OpCode)
                    {
                        case OP_ICON_SET:
                        {
                            if (sub_len == ICON_IND_SIZE)
                            {
                                memcpy(&icon_id, p, ICON_IND_SIZE);
                                p += ICON_IND_SIZE;
                                len -= ICON_IND_SIZE;
                                sec_len -= ICON_IND_SIZE;
                            }
                            else
                            {
                                LOGE("OP_ICON_SET: sub_len = %d\n", sub_len);
                            }
                            break;
                        }
                        case OP_LED_SET:
                        {
                            if (sub_len == LED_STAT_SIZE)
                            {
                                memcpy(&led_stat, p, LED_STAT_SIZE);
                                if (LED_STATE_VALIDATE(led_stat) != TRUE)
                                    led_stat = LED_NOP;
                                
                                p += LED_STAT_SIZE;
                                len -= LED_STAT_SIZE;
                                sec_len -= LED_STAT_SIZE;
                            }
                            else
                            {
                                LOGE("OP_LED_SET: sub_len = %d\n", sub_len);
                            }
                            break;
                        }
                        case OP_LABEL_SET:
                        {
                            if (sub_len > 0)
                            {
                                label.content= (uint8_t *)pw_malloc(sub_len);
                                LOGD("label = 0x%x, size = %d\n", label.content, sub_len);//test
                                if (label.content != NULL)
                                {
                                    pw_memcpy(label.content, p, (sub_len-1));
                                    label.size = sub_len;
                                }
                                p += sub_len;
                                len -= sub_len;
                                sec_len -= sub_len;
                            }
                            else
                            {
                                LOGE("OP_LABEL_SET: sub_len = %d\n", sub_len);
                            }
                            break;
                        }
                        default:
                            LOGE("Unsupport OpCode: 0x%x\n", sub_OpCode);
                            break;
                    }  
                }
            }
        }
        
        LOGD("key_index = %d, icon_id = %d, led_stat = %d, label = %s\n", key_index, icon_id, led_stat, label);
        if (KEY_INDEX_VALIDATE(key_index) == TRUE)
        {
            disp_item = init_key_disp_info(key_index, icon_id, led_stat, &label);
            LOGD("disp_item: 0x%x\n", disp_item);//test
            print_key_disp_info(disp_item);
            insert_key_disp_info(&key_header, disp_item);
        }
    }

    //printf("key_header: 0x%x\n", key_header);
    return key_header;
}
/***********************************************************
 hidMSG format:
       1Byte       4Byte     
    MSGTYEP + Length + Body
************************************************************/
static bool_t hid_msg_parse(const uint8_t msg[], int totalLengh)
{
    uint8_t *p = msg;
    hid_msg_header m_header;
    int len = totalLengh;
    int header_size = sizeof(hid_msg_header);
    static key_disp_infor_t * head = NULL;

    // check msg lengh, it should not smaller than header size
    if (len < header_size)
    {
        LOGE("hid_msg_parse: Invalid msg total length");
        return FALSE;
    }

    // get msg header
    memcpy(&m_header, p, header_size);
    p += header_size;
    len -= header_size;

    //check msg body length
    //LOGD("len: %d; body_len: %d\n", len, m_header.body_len);
    if (len != m_header.body_len)
    {
        LOGE("hid_msg_parse: Invalid msg body length");
        return FALSE;    
    }

    LOGD("hid_msg_parse: msg_type = %s\n", hidmsg2str(m_header.msg_type));
    switch (m_header.msg_type)
    {
        case HID_MSG_SCREENINFO_DONE:
        case HID_MSG_SCREENINFO:
        case HID_MSG_KEYINFO:
        {     
            msg_t msg_s;
            key_disp_infor_t * screen_key_info = handle_msg_homepage(p, len);

            //LOGD("head = 0x%x, &head = 0x%x, screen_key_info = 0x%x, p_screen_key_info = 0x%x, size = %x\n", head, &head, screen_key_info, &screen_key_info, sizeof(key_disp_infor_t **));//test
		 
            //extern void print_key_disp_info(key_disp_infor_t* disp_header);
            //print_key_disp_info(screen_key_info);//test

            if (screen_key_info != NULL)
            {
                //LOGD("label = 0x%x, size = %d\n", screen_key_info->label.content, screen_key_info->label.size);
                if (m_header.msg_type == HID_MSG_SCREENINFO)
                {
                    insert_key_disp_info(&head, screen_key_info);
                }
                else if (m_header.msg_type == HID_MSG_SCREENINFO_DONE)
                {
                    insert_key_disp_info(&head, screen_key_info);
                    msg_s = msgL_allocate(MSG_request_screen_upg,
                                              STD_MEM, THREAD_ID_hidRd,
                                              sizeof(key_disp_infor_t**),
                                              (void *)&head);
                    aom_msgQ_send(QUEUE_ID_display, msg_s);
                    head = NULL;
                }                      
                else
                {
                    msg_s = msgL_allocate(MSG_request_keyInfo_upg,
                                              STD_MEM, THREAD_ID_hidRd,
                                              sizeof(key_disp_infor_t**),
                                              (void *)&screen_key_info);
                    aom_msgQ_send(QUEUE_ID_display, msg_s);
                }               
            }
            
            break;               
        }
	 
        case HID_MSG_PAGEICON:
        {
            uint8_t page_status[MAX_PAGES_CFG];
            msg_t msg_s;
            
            //LOGD("len = %d, MAX_PAGES_CFG = %d", len, MAX_PAGES_CFG);
            if (len == MAX_PAGES_CFG)
            {
                memset(page_status, 0, MAX_PAGES_CFG);
                pw_memcpy(page_status, p, MAX_PAGES_CFG);

                msg_s = msgL_allocate(MSG_request_pageicon_upg, 
                                         STD_MEM, THREAD_ID_hidRd,
                                         sizeof(page_status),
                                         (void *)page_status);       
                aom_msgQ_send(QUEUE_ID_display, msg_s);                
            }
            
            break;
        }

        case HID_MSG_SCREENSAVER:
        {
            uint8_t on_off;
            msg_t msg_s;
            
            if (len == sizeof(uint8_t))
            {
                pw_memcpy((void *)&on_off, p, sizeof(uint8_t));

                //LOGD("send screen on_off = 0x%x to display task", on_off);
                msgS_allocate(msg_s, MSG_request_screensaver, on_off, THREAD_ID_hidRd);
                aom_msgQ_send(QUEUE_ID_display, msg_s);
            }
            
            break;
        }
            
        case HID_MSG_RESET:
        case HID_MSG_UPG:
        {
            aom_task_create_ex(THREAD_ID_misc, misc_task_entry, NULL, (void *)(m_header.msg_type));
            break;
        }
        case HID_MSG_LOGLEVEL:
        {
            LogPriority l;
            pw_memcpy((void *)&l, p, sizeof(LogPriority));
            
            SetLogLevel(l);
            break;
        }
        
        case HID_MSG_BACKLIGHT_LEVEL:
        {
            uint8_t l;
            pw_memcpy((void *)&l, p, sizeof(uint8_t));

            LOGD("backlight level = %d", l);
            set_backlight_level(l);
            break;
        }

        case HID_MSG_SKIN_RELOAD:
        {
            uint8_t skin_id;     
            msg_t msg_s;
            
            if (len == sizeof(uint8_t))
            {
                pw_memcpy((void *)&skin_id, p, sizeof(uint8_t));

                //request remount "/userdata" folder
                aom_task_create_ex(THREAD_ID_misc, misc_task_entry, NULL, (void *)(m_header.msg_type));
            }            
            break;
        }

        case HID_MSG_INFO_REQUEST:
        {
            msg_t msg_s;
            
            //send to hid write thread
            msgS_allocate(msg_s, MSG_request_id_info, 0xff, THREAD_ID_keydrv);
            aom_msgQ_send(QUEUE_ID_hidWt, msg_s);
        }
        break;
        
        default:
            LOGE("hid_msg_parse: unsupported msg type: %d\n", m_header.msg_type);
            break;
    }
    
    return TRUE;
}

static int init_HID (void)
{
    if (hid_fd > 0)
        return hid_fd;
    
    if ((hid_fd = open(hid_dev_name, O_RDWR, 0666)) < 0)
    {
        LOGE("init_HID: can not open hid device");
        return -1;
    }
    return hid_fd;
}

static int hid_write( int fd, void* buffer, int buffer_size)
{
    int res = 0;
    int write_size = 0;
    int writting_count = buffer_size / HID_MAX_PACKET_SIZE;
    int remainding_size = buffer_size % HID_MAX_PACKET_SIZE;
    buffer_offset_size_t* buffer_offset = (buffer_offset_size_t*)buffer;
	
    if(buffer == NULL)
    {
        LOGE("buffer is NULL\n");
        return FALSE;
    }
 
    while(writting_count--)
    {
        res = write(fd, buffer_offset, HID_MAX_PACKET_SIZE);

        if(res < 0)
        {
            LOGE("hid_write meet errro!");
            return write_size;
        }
        write_size += res; 
        buffer_offset++;
    }
 
    res = write(fd, buffer_offset, remainding_size);
    if(res < 0)
    {
        LOGE("hid_write meet errro!");
        return write_size;
    }
        
    write_size += res;
    
    return write_size;
}

static int aom_hid_write (void* buffer, int buffer_size)
{
    int wt_size = 0;
	
    if(buffer == NULL)
    {
        LOGE("aom_hid_write::buffer is NULL\n");
        return -1;
    }

    if (hid_fd < 0 )
    {
         LOGE("aom_hid_write: hid fd is not opened\n");
         return -1;
    }
    
    wt_size = hid_write(hid_fd, buffer, buffer_size);
    if(wt_size != buffer_size)
    {
        LOGE("aom_hid_write: write data meet error\n");
        return -1;
    }
  
    return wt_size;
}

static int aom_hid_uninit (void)
{
    if (hid_fd > 0)
    {
        close(hid_fd);
        hid_fd = 0;
    }
}

//read event from "/dev/hidg0"
//Event dir: host --> device
static void HID_Rd_task_entry (void)
{
    int ret, rd_len, i;
    
    struct timeval tv;    
    fd_set fdset;

    int goOn = 1;
    while (goOn)
    {
        FD_ZERO(&fdset);
        FD_SET(hid_fd, &fdset);

        tv.tv_sec = 10;
        tv.tv_usec = 0;
        
        ret = select(hid_fd + 1, &fdset, NULL, NULL, &tv);
    
        if (ret == -1 && errno == EINTR)
        {
            LOGE("HID_Rd_task_entry: no data read from hid, continue\n");
            continue;
        }

        if (ret < 0) 
        {   
            LOGE("HID_Rd_task_entry: read hid data failed, close fd (%d)\n", hid_fd);
            close(hid_fd);
            hid_fd = -1;
            exit(1);
        }

        if (FD_ISSET(hid_fd, &fdset))
        {
            memset(hid_rcv_msg, 0, HID_MAX_PACKET_SIZE+1);
            rd_len = read(hid_fd, hid_rcv_msg, HID_MAX_PACKET_SIZE);

            if ((rd_len >0) || (rd_len <= HID_MAX_PACKET_SIZE))
            {
#if 0
                {
                    int i;
                    for (i = 0; i < rd_len; i++)
                    {
                        printf("0x%2x ", *(hid_rcv_msg + i));
                    }
                    printf("\n");
                }
#endif
                hid_msg_parse(hid_rcv_msg, rd_len);
            }
        }
    } // *** while(goOn) end ***
}

//write event to "/dev/hidg0"
//Event dir: device --> host
static void HID_Wt_task_entry (void)
{
    int ret = 0;
    msg_t        msg;   
    hid_msg_header hid_msg_h;
        
    int goOn = 1;
    while (goOn)
    {
        if (0 != aom_msgQ_recv (QUEUE_ID_hidWt, &msg))
        {
            break; // For Thread Exit on Exception
        }

        switch (msg_opcode (msg))
        {
            case MSG_event_drv_keyb:
            {
                hid_msg_body_key hid_msg_body;
                int hid_msg_len, wt_size;
                
                hid_msg_h.msg_type = HID_MSG_KEY;
                hid_msg_h.body_len = sizeof(hid_msg_body_key);
            
                hid_msg_body.key = (uint8_t)(msgS_data(msg));
                hid_msg_len = hid_msg_prepare(hid_snd_msg, HID_BUFFER_SIZE, &hid_msg_h, &hid_msg_body);

                LOGE("hid_msg_body.key = 0x%x, hid_msg_len = %d\n", hid_msg_body.key, hid_msg_len);
                if (hid_msg_len > 0)
                {
                    wt_size = aom_hid_write(hid_snd_msg, hid_msg_len);

                    LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                    
                    if (wt_size != hid_msg_len)
                    {
                        LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                    }
                }
                
                break;
            }

          /**
            ===============
            "/etc/version"
            VersionSoft="2.10.00"
            ===============
            ===============
            "/fab/Release"
            PCMS=xxxxxxx
            SerialNumber=xxxxxxx
            ===============
            ===============
            "/data/cust/display/icons/icons.md5sum"
            ICONS_MD5=xxxxxxxx
            ===============   
          */
            case MSG_request_id_info:
            {                            
                int hid_msg_len, wt_size;

                // send version information
                if (strlen(A_version) > 0)
                {
                    hid_msg_h.msg_type = HID_MSG_INFO_VER;
                    hid_msg_h.body_len = strlen(A_version);
            
                    hid_msg_len = hid_msg_prepare(hid_snd_msg, HID_BUFFER_SIZE, &hid_msg_h, (uint8_t *)A_version);

                    LOGE("id version = %s, body_len = %d, hid_msg_len = %d\n", A_version, strlen(A_version), hid_msg_len);
                    if (hid_msg_len > 0)
                    {
                        wt_size = aom_hid_write(hid_snd_msg, hid_msg_len);

                        LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                    
                        if (wt_size != hid_msg_len)
                        {
                            LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                        }
                    }
                }
                
                // send PCMS information
                if (strlen(A_pcms) > 0)
                {
                    hid_msg_h.msg_type = HID_MSG_INFO_PCMS;
                    hid_msg_h.body_len = strlen(A_pcms);
            
                    hid_msg_len = hid_msg_prepare(hid_snd_msg, HID_BUFFER_SIZE, &hid_msg_h, (uint8_t *)A_pcms);

                    LOGE("id pcms = %s, body_len = %d, hid_msg_len = %d\n", A_pcms, strlen(A_pcms), hid_msg_len);
                    if (hid_msg_len > 0)
                    {
                        wt_size = aom_hid_write(hid_snd_msg, hid_msg_len);

                        LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                    
                        if (wt_size != hid_msg_len)
                        {
                            LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                        }
                    }
                }
                
                // send sn information
                if (strlen(A_sn) > 0)
                {
                    hid_msg_h.msg_type = HID_MSG_INFO_SN;
                    hid_msg_h.body_len = strlen(A_sn);
            
                    hid_msg_len = hid_msg_prepare(hid_snd_msg, HID_BUFFER_SIZE, &hid_msg_h, (uint8_t *)A_sn);

                    LOGE("id sn = %s, body_len = %d, hid_msg_len = %d\n", A_sn, strlen(A_sn), hid_msg_len);
                    if (hid_msg_len > 0)
                    {
                        wt_size = aom_hid_write(hid_snd_msg, hid_msg_len);

                        LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                    
                        if (wt_size != hid_msg_len)
                        {
                            LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                        }
                    }
                }
                
                // send icons_md5 information
                if (strlen(A_icons_md5) > 0)
                {
                    hid_msg_h.msg_type = HID_MSG_INFO_ICONS_MD5;
                    hid_msg_h.body_len = strlen(A_icons_md5);
            
                    hid_msg_len = hid_msg_prepare(hid_snd_msg, HID_BUFFER_SIZE, &hid_msg_h, (uint8_t *)A_icons_md5);

                    LOGE("id icons_md5 = %s, body_len = %d, hid_msg_len = %d\n", A_icons_md5, strlen(A_icons_md5), hid_msg_len);
                    if (hid_msg_len > 0)
                    {
                        wt_size = aom_hid_write(hid_snd_msg, hid_msg_len);

                        LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                    
                        if (wt_size != hid_msg_len)
                        {
                            LOGE("hid_msg_len = %d, wt_size = %d\n", hid_msg_len, wt_size);
                        }
                    }
                }                
                break;
            }          
        }
    } // *** while(goOn) end ***
}

void init_tskHID(void)
{
    init_HID();

    //create HID event read task
    aom_task_create(THREAD_ID_hidRd, HID_Rd_task_entry, NULL);

    //create HID event write task
    aom_msgQ_create(QUEUE_ID_hidWt);
    aom_task_create(THREAD_ID_hidWt, HID_Wt_task_entry, NULL);   
}

