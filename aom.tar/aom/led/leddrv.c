#include <stdio.h>  
  
#include <stdlib.h>  
  
#include <string.h>  
#include <unistd.h>  
#include <fcntl.h>   //define O_WRONLY and O_RDONLY  

#include "log.h"

#include "leddrv.h"

int maxLed = 23;//default for lcd version is 23, paper is 20
char *blink_time_normal = "500";
char *blink_time_fast = "250";

#define LEDPWM_INTERFACE                          "/sys/class/leds/LEDPWM%d/brightness"
#define TRIGGER_INTERFACCE                       "/sys/class/leds/PKLED%d/trigger"
#define BRIGHTNESS_INTERFACE                   "/sys/class/leds/PKLED%d/brightness"
#define DELAYON_INTERFACE                        "/sys/class/leds/PKLED%d/delay_on"
#define DELAYOFF_INTERFACE                      "/sys/class/leds/PKLED%d/delay_off"

/*-----------------------------------------------------------------------------
    led driver intialization function: 
        @max_led: led maximal number
        
    PWM1&PWM2 is circuit switch for all leds.
  ---------------------------------------------------------------------------*/
void init_drvled(int max_led)
{
    int i;
    //set maximal led number on the board
    maxLed = max_led;
    
    //set  PWM1&PWM2 on
    FILE * fp = NULL;
    char path[128] = {0};

    //two PWM to contral left and right side led on the board
    for (i = 1; i <= 2; i++)
    {
        sprintf(path, LEDPWM_INTERFACE, i);
        fp =fopen(path, "w");  
        if (fp == NULL)  
        {
            LOGE("open '%s' failed\n", path);
            return;
        }
        fprintf(fp, "%s", "50");
        fclose(fp);
        fp = NULL;
    }
}

/*-----------------------------------------------------------------------------
    led onoff contral function: 
        @ledId: led number
        @onoff: state to be set
        
    sysClass interfact write sequece:
        step1: set trigger interface to 'none'
        step2: set brightness interface to 0/1
  ---------------------------------------------------------------------------*/
void drvled_onoff(int ledId, bool_t onoff)
{
    FILE * fp = NULL;
    char path[128] = {0};

    //check ledId
    if (ledId >= maxLed)
    {
        LOGE("ledId exceed maxLed\n");
        return;
    }
    
    //set trigger to 'none'
    sprintf(path, TRIGGER_INTERFACCE, ledId);
    fp =fopen(path, "w");  
    if (fp == NULL)  
    {
        LOGE("open '%s' failed\n", path);
        return;
    }
    fprintf(fp, "%s", "none");
    fclose(fp);
    fp = NULL;
    
    //set state
    sprintf(path, BRIGHTNESS_INTERFACE, ledId);
    fp =fopen(path, "w");  
    if (fp == NULL)  
    {
        LOGE("open '%s' failed\n", path);
        return;
    }
    fprintf(fp, "%s", onoff ? "1" : "0");
    fclose(fp);
    fp = NULL; 
}

/*-----------------------------------------------------------------------------
    led blink contral function: 
        @ledId: led number
        @fast: fast or normal blink
        
    sysClass interfact write sequece:
        step1: set trigger interface to 'timer'
        step2: set delay_on& delay_off value
  ---------------------------------------------------------------------------*/
void drvled_blink(int ledId, bool_t fast)
{
    FILE * fp = NULL;
    char path[128] = {0};

    //check ledId
    if (ledId >= maxLed)
    {
        LOGE("ledId exceed maxLed\n");
        return;
    }
    
    //set trigger to 'timer'
    sprintf(path, TRIGGER_INTERFACCE, ledId);
    fp =fopen(path, "w");  
    if (fp == NULL)  
    {
        LOGE("open '%s' failed\n", path);
        return;
    }
    fprintf(fp, "%s", "timer");
    fclose(fp);
    fp = NULL;
    
    //set delay_on value
    sprintf(path, DELAYON_INTERFACE, ledId);
    fp =fopen(path,"w");  
    if (fp == NULL)  
    {
        LOGE("open '%s' failed\n", path);
        return;
    }
    fprintf(fp, "%s", fast ? blink_time_fast : blink_time_normal);
    fclose(fp);
    fp = NULL; 

    //set delay_off value
    sprintf(path, DELAYOFF_INTERFACE, ledId);
    fp =fopen(path,"w");  
    if (fp == NULL)  
    {
        LOGE("open '%s' failed\n", path);
        return;
    }
    fprintf(fp, "%s", fast ? blink_time_fast : blink_time_normal);
    fclose(fp);
    fp = NULL;     
}
